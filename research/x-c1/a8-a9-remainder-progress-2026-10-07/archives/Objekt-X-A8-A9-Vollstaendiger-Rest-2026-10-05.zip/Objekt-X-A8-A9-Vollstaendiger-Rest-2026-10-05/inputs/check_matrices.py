from pathlib import Path
from fractions import Fraction as F
import json

def bound(a,sign):
    assert len(a)==4 and all(len(r)==4 for r in a)
    for i in range(4):
        for j in range(4):
            assert len(a[i][j])==2 and F(a[i][j][0])<=F(a[i][j][1])
            assert a[i][j]==a[j][i]
    mid=[[sum(map(F,x))/2 for x in row] for row in a]
    for i in range(4):mid[i][i]+=sign*sum((F(v[1])-F(v[0]))/2 for v in a[i])
    return mid

def pivots(a):
    a=[r[:] for r in a];ds=[]
    for k in range(4):
        pivot=a[k][k]
        assert pivot>0, ('nonpositive pivot',k,pivot)
        ds.append(str(pivot))
        for i in range(k+1,4):
            for j in range(k+1,4):a[i][j]-=a[i][k]*a[k][j]/pivot
    return ds

def check():
    root=Path(__file__).resolve().parent
    data=json.loads((root/'MATRICES.json').read_bytes());records=[]
    assert {(r['bits'],r['parity']) for r in data['blocks']}=={(b,p) for b in (3072,4096) for p in ('even','odd')}
    assert len(data['blocks'])==4
    for r in data['blocks']:
        K=bound(r['K_lower'],-1);G=bound(r['Gamma_upper'],1)
        W=bound(r['reference_gram_upper'],1)
        expected=F('1/250000000000') if r['parity']=='even' else F('3/100000000000')
        eta=F(r['eta']);assert eta==expected
        ref=pivots(bound(r['reference_gram_lower'],-1))
        ds=pivots([[K[i][j]-G[i][j]-eta*W[i][j] for j in range(4)] for i in range(4)])
        records.append({'bits':r['bits'],'parity':r['parity'],'eta':str(eta),'reference_positive_pivots':ref,'schur_positive_pivots':ds})
    print(json.dumps({'status':'PASS_FINAL_MATRICES_ONLY','checks':records,'full_operator_replay':False,'external_review':'OPEN'},indent=2))
if __name__=='__main__':
    assert __debug__
    check()
