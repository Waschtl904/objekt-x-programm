"""Exact negative controls for the new acceptance and adaptive cover logic."""
from pathlib import Path
from fractions import Fraction as F
import copy
import json
import tempfile
from angle_model import HERE, load_model, width_upper, evaluate, cache_fixed_functionals
from adaptive_gate import classify, score, volume


def main():
    with tempfile.TemporaryDirectory(prefix='adaptive-angle-controls-') as name:
        model, v, variables, split, _ = load_model(Path(name))
        # An unchanged prior PSD/physical-metric test suite runs separately.
        assert width_upper(v, F(0)) == 0
        assert width_upper(v, F(1, 2)) == 90
        assert width_upper(v, F(1)) == 180
        assert F('11.478') < width_upper(v, F(1, 100)) < F('11.479')
        assert 8 < width_upper(v, F(1, 200)) < 9
        assert width_upper(v, F('0.00759612349')) < 10
        assert width_upper(v, F('0.00759612350')) > 10
        # Exercise the reciprocal angle chart that the earlier wrapper lacked.
        assert F('119.99') < width_upper(v, F(3, 4)) < F('120.01')
        assert F('168.52') < width_upper(v, F(99, 100)) < F('168.53')

        def leaf(width, **extras):
            return {'evaluation': {'status': 'UNRESOLVED', 'width_upper': F(width), **extras}}
        assert classify([leaf(10)]) == 'UNRESOLVED'
        assert classify([leaf(F(999, 100))]) == 'GREEN'
        assert classify([leaf(12, within_target_corridor=True)]) == 'UNRESOLVED'
        assert classify([leaf(0), leaf(180)]) == 'UNRESOLVED'
        try:
            classify([{'evaluation': {'status': 'EXCLUDED'}}])
        except AssertionError:
            pass
        else:
            raise AssertionError('vacuous GREEN accepted')
        try:
            classify([leaf(180)], {'both_points_fully_certified_in_new_family': False, 'angle_lower': '11'})
        except AssertionError:
            pass
        else:
            raise AssertionError('surviving boxes treated as feasible points')
        try:
            classify([leaf(180)], {'both_points_fully_certified_in_new_family': True, 'angle_lower': '10'})
        except AssertionError:
            pass
        else:
            raise AssertionError('non-strict separation accepted')
        assert classify([leaf(180)], {'both_points_fully_certified_in_new_family': True, 'angle_lower': '11'}) == 'NEW_STRUCTURAL_OPEN'
        root = model.root_box()
        for key in variables:
            left, right = split(root, key)
            assert volume(left, root) + volume(right, root) == 1
            assert left[key][0] == root[key][0] and left[key][1] == right[key][0] and right[key][1] == root[key][1]
            assert all(left[k] == right[k] == root[k] for k in variables if k != key)
        wide = {'status': 'UNRESOLVED', 'width_upper': F(180)}
        narrow = {'status': 'WITHIN_TARGET', 'width_upper': F(8)}
        excluded = {'status': 'EXCLUDED', 'width_upper': None}
        assert score([excluded, wide], F(1, 8), 3) > score([wide, wide], F(1), 0)
        assert score([narrow, narrow], F(1, 8), 3) > score([wide, wide], F(1), 0)
        assert score([wide, wide], F(1), 3) > score([wide, wide], F(1, 2), 0)

        # Cache control on additional boxes outside the ten pilot comparisons.
        original = copy.copy(model)
        cache_fixed_functionals(model, v)
        boxes = [root]
        for index, key in enumerate(variables):
            boxes.append(split(boxes[-1], key)[index % 2])
        for box in boxes:
            assert evaluate(model, v, box) == evaluate(original, v, box)
        # The cache key must change when fixed left-block data change.
        changed = copy.copy(model)
        changed.y = [row[:] for row in model.y]
        a, b = changed.y[0][0]
        changed.y[0][0] = (a, (a+b)/2)
        changed.prepare()
        plain = copy.copy(changed)
        plain.v = v
        assert evaluate(changed, v, changed.root_box()) == evaluate(plain, v, plain.root_box())
    print('PASS: strict ten-degree gate, reciprocal angle chart, no vacuous GREEN, no existence from boxes, exact partition, sensitivity ranking, and cached/uncached identity.')


if __name__ == '__main__':
    main()
