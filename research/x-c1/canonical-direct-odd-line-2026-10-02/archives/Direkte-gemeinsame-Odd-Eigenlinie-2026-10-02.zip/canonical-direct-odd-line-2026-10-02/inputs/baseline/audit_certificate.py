"""Check cover, all decisions and numerical receipts independently of the search."""
from pathlib import Path
from fractions import Fraction as F
import argparse
import copy
import hashlib
import json
import tempfile
from angle_model import HERE, load_model, evaluate, cache_fixed_functionals


def pairs(box):
    return {k: tuple(map(F, x)) for k, x in box.items()}


def check_structure(data, parameters):
    root = pairs(data['root_box'])
    assert list(root) == parameters['variables']
    assert data['parameters_sha256'] == hashlib.sha256((HERE / 'parameters.json').read_bytes()).hexdigest()
    assert data['source_bindings_sha256'] == hashlib.sha256((HERE / 'SOURCE_BINDINGS.json').read_bytes()).hexdigest()
    assert data['main'] == parameters['main']
    nodes = {n['id']: n for n in data['nodes']}
    assert len(nodes) == len(data['nodes']) == data['node_count'] <= parameters['max_tree_nodes']
    assert 'r' in nodes and nodes['r']['depth'] == 0 and pairs(nodes['r']['box']) == root
    leaves, splits, evaluated = [], [], {}

    def bind(box, receipt):
        key = tuple(box[k] for k in root)
        if key in evaluated:
            assert evaluated[key] == receipt
        evaluated[key] = receipt
        if receipt['status'] == 'EXCLUDED':
            assert receipt['width_upper'] is None and receipt['reasons']
            assert all(F(r['upper']) < 0 for r in receipt['reasons'])
        else:
            width = F(receipt['width_upper'])
            assert 0 <= width <= 180
            assert receipt['status'] == ('WITHIN_TARGET' if width < 10 else 'UNRESOLVED')
            assert not receipt['reasons']

    def children(box, axis):
        lo, hi = box[axis]
        middle = (lo + hi)/2
        left, right = dict(box), dict(box)
        left[axis], right[axis] = (lo, middle), (middle, hi)
        return left, right

    def audit_options(box, options):
        assert list(options) == list(root)
        scores = {}
        for index, axis in enumerate(root):
            row = options[axis]
            assert len(row['children']) == 2
            for child, receipt in zip(children(box, axis), row['children']):
                bind(child, receipt)
            live = [r for r in row['children'] if r['status'] != 'EXCLUDED']
            widths = [F(r['width_upper']) for r in live]
            relative = (box[axis][1]-box[axis][0])/(root[axis][1]-root[axis][0])
            scores[axis] = (2-len(live), sum(r['status'] == 'WITHIN_TARGET' for r in live),
                           -max(widths, default=F(0)), -sum(widths, F(0))/max(1, len(live)), relative, -index)
            assert tuple(map(F, row['score'])) == scores[axis]
        return max(root, key=scores.get)

    visited = set()

    def walk(identifier):
        assert identifier not in visited
        visited.add(identifier)
        node = nodes[identifier]
        box = pairs(node['box'])
        bind(box, node['evaluation'])
        assert 0 <= node['depth'] <= parameters['max_depth']
        if 'split_variable' not in node:
            leaves.append(identifier)
            return
        assert node['evaluation']['status'] == 'UNRESOLVED'
        assert node['depth'] < parameters['max_depth']
        axis = node['split_variable']
        assert axis == audit_options(box, node['alternatives'])
        splits.append(axis)
        for side, child in zip(('L', 'R'), children(box, axis)):
            row = nodes[identifier+side]
            assert pairs(row['box']) == child and row['depth'] == node['depth']+1
            walk(identifier+side)

    walk('r')
    assert visited == set(nodes)
    assert sorted(leaves) == data['leaf_ids'] and len(leaves) == data['leaf_count']
    assert len(evaluated) == data['tree_evaluations'] <= parameters['max_tree_evaluations']
    measure = F(0)
    for identifier in leaves:
        product = F(1)
        box = pairs(nodes[identifier]['box'])
        for axis in root:
            product *= (box[axis][1]-box[axis][0])/(root[axis][1]-root[axis][0])
        measure += product
    assert measure == F(data['exact_partition_volume']) == 1
    live = [nodes[k]['evaluation'] for k in leaves if nodes[k]['evaluation']['status'] != 'EXCLUDED']
    assert live
    assert data['certified_separated_point_pair'] is None
    expected = 'GREEN' if all(F(r['width_upper']) < 10 for r in live) else 'UNRESOLVED'
    assert data['status'] == expected
    assert F(data['common_total_corridor_upper']) == max(F(r['width_upper']) for r in live)
    assert data['excluded_leaf_count'] == len(leaves)-len(live)
    assert data['within_target_leaf_count'] == sum(r['status'] == 'WITHIN_TARGET' for r in live)
    assert data['unresolved_leaf_count'] == sum(r['status'] == 'UNRESOLVED' for r in live)
    assert data['split_counts'] == {axis: splits.count(axis) for axis in root}
    if expected == 'UNRESOLVED':
        reason = data['stop_reason']
        assert reason in ('tree_node_budget_exhausted', 'depth_budget_exhausted', 'lookahead_evaluation_budget_exhausted')
        if reason == 'tree_node_budget_exhausted':
            assert len(nodes)+2 > parameters['max_tree_nodes']
        elif reason == 'lookahead_evaluation_budget_exhausted':
            assert data['tree_evaluations']+8 > parameters['max_tree_evaluations']
        else:
            assert all(nodes[k]['depth'] == parameters['max_depth'] for k in leaves if nodes[k]['evaluation']['status'] == 'UNRESOLVED')
    assert len(data['diagnostics']) <= parameters['terminal_diagnostic_boxes']
    for item in data['diagnostics']:
        assert item['leaf_id'] in leaves
        box = pairs(nodes[item['leaf_id']]['box'])
        audit_options(box, item['alternatives'])
        assert item['midpoint_probes_are_not_cover_or_feasibility_certificates'] is True
        assert set(item['conditional_midpoint_probes']) == set(root) | {','.join(root)}
        for axes, receipt in item['conditional_midpoint_probes'].items():
            conditional = dict(box)
            for axis in axes.split(','):
                mid = sum(conditional[axis])/2
                conditional[axis] = (mid, mid)
            bind(conditional, receipt)
    assert len(evaluated) == data['total_evaluations_with_diagnostics']
    assert data['full_nuisance_uncertainties_retained'] and data['all_stage_a_and_new_Y68_data_used']
    assert not any(data[k] for k in ('existence_from_box_survival', 'large_operator_integrals_repeated', 'new_Y58_dual_computation', 'A13_inputs_used'))
    points = json.loads((HERE/'inputs/counterfamily.json').read_bytes())['certified_completions']
    indices = {'Y57': (4,6), 'Y58': (4,7), 'Y67': (5,6), 'Y68': (5,7)}
    for label, point in points.items():
        coords = {k: tuple(map(F, point['corrected_Y'][i][j])) for k,(i,j) in indices.items()}
        containing = [identifier for identifier in sorted(leaves) if all(F(nodes[identifier]['box'][k][0]) <= a <= b <= F(nodes[identifier]['box'][k][1]) for k,(a,b) in coords.items())]
        assert containing and containing == sorted(data['inherited_point_containing_leaves'][label])
        assert all(nodes[k]['evaluation']['status'] != 'EXCLUDED' for k in containing)
    return evaluated


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--certificate', type=Path, default=HERE/'verification.json')
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--structure-only', action='store_true')
    args = parser.parse_args()
    raw = args.certificate.read_bytes()
    data = json.loads(raw)
    parameters = json.loads((HERE/'parameters.json').read_bytes())
    expected = check_structure(data, parameters)
    # Genuine negative controls, including incomplete coverage and false GREEN.
    bad = copy.deepcopy(data)
    bad['leaf_ids'].pop()
    try:
        check_structure(bad, parameters)
    except AssertionError:
        pass
    else:
        raise AssertionError('missing leaf accepted')
    bad = copy.deepcopy(data)
    bad['status'] = 'GREEN' if data['status'] != 'GREEN' else 'UNRESOLVED'
    try:
        check_structure(bad, parameters)
    except AssertionError:
        pass
    else:
        raise AssertionError('false classification accepted')
    count = 0
    if not args.structure_only:
        with tempfile.TemporaryDirectory(prefix='adaptive-audit-') as name:
            model, v, variables, _, _ = load_model(Path(name))
            assert v.rational(model.root_box()) == data['root_box']
            assert v.rational(model.reference) == data['reference']
            cache_fixed_functionals(model, v)
            for key, receipt in expected.items():
                box = dict(zip(variables, key))
                actual = evaluate(model, v, box)
                assert v.rational(actual) == receipt, ('numeric mismatch', count)
                count += 1
                if count % 64 == 0:
                    print('Exact numerical replay:', count, '/', len(expected), flush=True)
    out = {'status': 'PASS', 'certificate_sha256': hashlib.sha256(raw).hexdigest(),
           'exact_cover_checked': True, 'all_split_scores_checked': True,
           'strict_ten_degree_acceptance_checked': True, 'tamper_controls_passed': True,
           'unique_numerical_evaluations_replayed': count, 'expected_evaluations': len(expected),
           'all_numeric_receipts_identical': count == len(expected),
           'independent_search_tree_audit': True,
           'independent_large_operator_implementation': False}
    args.out.write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps(out), flush=True)


if __name__ == '__main__':
    main()
