"""Independent Arb check of every reported rational angular upper bound."""
from pathlib import Path
from fractions import Fraction as F
import argparse
import json
import tempfile
from flint import arb, fmpq, ctx
import flint
from angle_model import HERE, load_model, width_upper


def exact_bound(ball):
    mantissa, exponent = ball.man_exp()
    return F(int(mantissa)) * F(2) ** int(exponent)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--certificate', type=Path)
    parser.add_argument('--additional-certificate', type=Path, action='append', default=[])
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    assert flint.__version__ == '0.9.0'
    ctx.prec = 768
    cases = set()
    with tempfile.TemporaryDirectory(prefix='angle-independent-') as name:
        _, v, _, _, _ = load_model(Path(name))
        for s in (F(0), F(1,100), F(1,200), F(1,2), F(3,4), F(99,100), F(1),
                  F('0.00759612349'), F('0.00759612350')):
            cases.add((s, width_upper(v, s)))
    if args.certificate:
        def visit(x):
            if isinstance(x, dict):
                if x.get('sin2') is not None:
                    cases.add((F(x['sin2'][1]), F(x['width_upper'])))
                for value in x.values():
                    visit(value)
            elif isinstance(x, list):
                for value in x:
                    visit(value)
        for path in [args.certificate, *args.additional_certificate]:
            visit(json.loads(path.read_bytes()))
    for sine, bound in sorted(cases):
        if sine in (F(0), F(1,2), F(1)):
            assert bound >= {F(0): F(0), F(1,2): F(90), F(1): F(180)}[sine]
            continue
        actual = 360 * arb(fmpq(sine.numerator, sine.denominator)).sqrt().asin() / arb.pi()
        assert exact_bound(actual.upper()) <= bound, (sine, bound, str(actual))
    threshold = (arb.pi()/36).sin()**2
    assert F('0.00759612349') < exact_bound(threshold.lower())
    assert exact_bound(threshold.upper()) < F('0.00759612350')
    result = {'status': 'PASS', 'independent_engine': 'python-flint 0.9.0 / Arb at 768 bits',
              'distinct_upper_bounds_checked': len(cases),
              'strict_five_degree_sine_squared_bracket': ['0.00759612349', '0.00759612350'],
              'old_one_percent_threshold_is_not_ten_degree_green': True,
              'operator_integrals_computed': False}
    args.out.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
