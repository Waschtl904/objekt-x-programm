"""Independently reconstruct the prescribed search order from node births."""
from pathlib import Path
from fractions import Fraction as F
import copy
import json

HERE = Path(__file__).resolve().parent


def check(data, parameters):
    nodes = {node['id']: node for node in data['nodes']}
    root = data['root_box']
    active = {'r'}

    def priority(identifier):
        node = nodes[identifier]
        volume = F(1)
        for axis, pair in root.items():
            lo, hi = map(F, node['box'][axis])
            volume *= (hi-lo)/(F(pair[1])-F(pair[0]))
        return -F(node['evaluation']['width_upper']), -volume, identifier

    for index in range(1, len(data['nodes']), 2):
        left, right = data['nodes'][index:index+2]
        assert left['id'].endswith('L') and right['id'] == left['id'][:-1]+'R'
        parent = left['id'][:-1]
        candidates = [key for key in active if nodes[key]['evaluation']['status'] == 'UNRESOLVED'
                      and nodes[key]['depth'] < parameters['max_depth']]
        assert candidates and parent == min(candidates, key=priority)
        active.remove(parent)
        active.update((left['id'], right['id']))
    assert sorted(active) == data['leaf_ids']


def main():
    data = json.loads((HERE/'verification.json').read_bytes())
    parameters = json.loads((HERE/'parameters.json').read_bytes())
    check(data, parameters)
    bad = copy.deepcopy(data)
    bad['nodes'][1], bad['nodes'][3] = bad['nodes'][3], bad['nodes'][1]
    try:
        check(bad, parameters)
    except AssertionError:
        pass
    else:
        raise AssertionError('invalid search order accepted')
    print('PASS: all 127 leaf selections follow the predeclared exact priority; altered birth order rejected.')


if __name__ == '__main__':
    main()
