"""Conditional central-model diagnostics, never a uniform certificate."""
from pathlib import Path
from fractions import Fraction as F
import argparse
import copy
import json
import tempfile
from angle_model import HERE, load_model, evaluate, cache_fixed_functionals


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='central-conditional-groups-') as name:
        model, v, variables, _, dependencies = load_model(Path(name))
        transport, _, df = dependencies
        e = transport.e
        source = json.loads(df['inputs/primary.json'])
        outer = json.loads(df['inputs/outer_primary.json'])
        measures = {suffix: e.measure(source['results'][key], outer['trials'][chamber])
            for suffix, chamber, key in [('A', 'A9-odd', 'A8->A9-odd'), ('B', 'A11-odd', 'A9->A11-odd')]}
        fixed = {letter+suffix: e.intervals(v, measures[suffix][field])
            for suffix in ('A', 'B') for letter, field in [('G', 'GP'), ('L', 'LP'), ('Z', 'ZP')]}
        central = json.loads((HERE/'inputs/counterfamily.json').read_bytes())['certified_completions']['central']
        cy = v.matrix(central['corrected_Y'])
        four = {key: cy[i][j] for key,(i,j) in variables.items()}
        choices = [('four_coordinates_only', False, ()),
                   ('all_Y', True, ()), ('GB', False, ('GB',)),
                   ('LB', False, ('LB',)), ('ZB', False, ('ZB',)),
                   ('all_full_moments', False, tuple(fixed)),
                   ('all_Y_and_all_full_moments', True, tuple(fixed))]
        rows = {}
        for label, use_y, groups in choices:
            conditional = copy.copy(model)
            conditional.full = dict(model.full)
            for key in groups:
                # Restrict to data of the inherited fully certified central model.
                assert v.intersectmat(model.full[key], fixed[key]) == fixed[key]
                conditional.full[key] = fixed[key]
            conditional.y = cy if use_y else model.y
            if use_y:
                assert v.intersectmat(model.y, cy) == cy
            conditional.prepare()
            cache_fixed_functionals(conditional, v)
            result = evaluate(conditional, v, four)
            assert result['status'] != 'EXCLUDED'
            rows[label] = {'evaluation': result, 'all_Y_restricted': use_y,
                           'full_moment_groups_restricted': list(groups)}
            print(label, result['status'], float(result['width_upper']), result['enclosure_unresolved'], flush=True)
        output = {'status': 'CONDITIONAL_DIAGNOSTIC_ONLY', 'reference_completion': 'inherited central',
            'uses_certified_model_data_instead_of_arbitrary_midpoints': True,
            'full_uncertainty_retention_applies_to_main_tree_not_these_restricted_probes': True,
            'probes': rows, 'global_or_uniform_angle_claim': False,
            'necessity_of_new_measurement_proved': False}
        args.out.write_text(json.dumps(v.rational(output), indent=2)+'\n', encoding='utf-8', newline='\n')


if __name__ == '__main__':
    main()
