"""Bounded adaptive outer-cover certificate with exact rational decisions."""
from pathlib import Path
from fractions import Fraction as F
import argparse
import hashlib
import json
import tempfile
from angle_model import HERE, load_model, evaluate, cache_fixed_functionals


def volume(box, root):
    out = F(1)
    for key in root:
        out *= (box[key][1] - box[key][0]) / (root[key][1] - root[key][0])
    return out


def score(children, relative_width, index):
    live = [x for x in children if x['status'] != 'EXCLUDED']
    widths = [x['width_upper'] for x in live]
    return (2 - len(live), sum(x['status'] == 'WITHIN_TARGET' for x in live),
            -max(widths, default=F(0)), -sum(widths, F(0))/max(1, len(widths)),
            relative_width, -index)


def classify(leaves, certified_separation=None):
    # A separation is accepted only from a separate complete point certificate.
    if certified_separation is not None:
        assert certified_separation['both_points_fully_certified_in_new_family'] is True
        assert F(certified_separation['angle_lower']) > 10
        return 'NEW_STRUCTURAL_OPEN'
    live = [n for n in leaves if n['evaluation']['status'] != 'EXCLUDED']
    assert live, 'empty outer cover contradicts the inherited actual solution; not GREEN'
    return 'GREEN' if all(n['evaluation']['width_upper'] < 10 for n in live) else 'UNRESOLVED'


def run(temp, parameters):
    model, v, variables, split, _ = load_model(temp)
    assert parameters['variables'] == list(variables)
    assert parameters['strict_common_total_width_degrees'] == 10
    cache_fixed_functionals(model, v)
    root = model.root_box()
    evaluations = {}

    def assess(box):
        key = tuple(box[k] for k in variables)
        if key not in evaluations:
            evaluations[key] = evaluate(model, v, box)
        return evaluations[key]

    def alternatives(box):
        rows = {}
        for index, key in enumerate(variables):
            children = split(box, key)
            results = [assess(child) for child in children]
            width = (box[key][1] - box[key][0]) / (root[key][1] - root[key][0])
            rows[key] = {'children': results, 'score': score(results, width, index)}
        return rows

    nodes = [{'id': 'r', 'depth': 0, 'box': root, 'evaluation': assess(root)}]
    leaves = {'r': nodes[0]}
    decisions = []
    while True:
        status = classify(list(leaves.values()))
        if status != 'UNRESOLVED':
            stop = 'all_live_leaves_strictly_within_common_ten_degree_corridor'
            break
        candidates = [n for n in leaves.values() if n['evaluation']['status'] == 'UNRESOLVED'
                      and n['depth'] < parameters['max_depth']]
        if not candidates:
            stop = 'depth_budget_exhausted'
            break
        if len(nodes) + 2 > parameters['max_tree_nodes']:
            stop = 'tree_node_budget_exhausted'
            break
        if len(evaluations) + 8 > parameters['max_tree_evaluations']:
            stop = 'lookahead_evaluation_budget_exhausted'
            break
        selected = min(candidates, key=lambda n: (-n['evaluation']['width_upper'],
                                                  -volume(n['box'], root), n['id']))
        options = alternatives(selected['box'])
        key = max(variables, key=lambda k: options[k]['score'])
        selected['split_variable'] = key
        selected['alternatives'] = options
        del leaves[selected['id']]
        for suffix, box in zip(('L', 'R'), split(selected['box'], key)):
            child = {'id': selected['id'] + suffix, 'depth': selected['depth'] + 1,
                     'box': box, 'evaluation': assess(box)}
            nodes.append(child)
            leaves[child['id']] = child
        decisions.append(key)
        if len(decisions) % 8 == 0 or len(decisions) == 1:
            print(json.dumps({'splits': len(decisions), 'nodes': len(nodes),
                'evaluations': len(evaluations), 'excluded_leaves': sum(n['evaluation']['status'] == 'EXCLUDED' for n in leaves.values()),
                'within_target_leaves': sum(n['evaluation']['status'] == 'WITHIN_TARGET' for n in leaves.values()),
                'worst_width': float(max(n['evaluation']['width_upper'] for n in leaves.values() if n['evaluation']['status'] != 'EXCLUDED'))}), flush=True)
    tree_evaluations = len(evaluations)
    live = [n for n in leaves.values() if n['evaluation']['status'] != 'EXCLUDED']
    assert sum((volume(n['box'], root) for n in leaves.values()), F(0)) == 1
    sample = sorted((n for n in live if n['evaluation']['status'] == 'UNRESOLVED'), key=lambda n: n['id'])
    count = min(parameters['terminal_diagnostic_boxes'], len(sample))
    indices = sorted({i*(len(sample)-1)//max(1, count-1) for i in range(count)})
    diagnostics = []
    for index in indices:
        node = sample[index]
        options = alternatives(node['box'])
        conditional = {}
        for keys in [(key,) for key in variables] + [tuple(variables)]:
            box = dict(node['box'])
            for key in keys:
                middle = sum(box[key])/2
                box[key] = (middle, middle)
            conditional[','.join(keys)] = assess(box)
        diagnostics.append({'leaf_id': node['id'], 'alternatives': options,
                            'conditional_midpoint_probes': conditional,
                            'midpoint_probes_are_not_cover_or_feasibility_certificates': True})
    # Guard the cover against accidentally discarding previously certified points.
    points = json.loads((HERE / 'inputs/counterfamily.json').read_bytes())['certified_completions']
    containing = {}
    for label, row in points.items():
        coordinates = {name: tuple(map(F, row['corrected_Y'][i][j])) for name, (i, j) in variables.items()}
        containing[label] = [n['id'] for n in leaves.values() if all(n['box'][k][0] <= pair[0] <= pair[1] <= n['box'][k][1] for k, pair in coordinates.items())]
        assert containing[label], ('known completion not contained in a leaf', label)
        assert all(leaves[node]['evaluation']['status'] != 'EXCLUDED' for node in containing[label])
    return v.rational({'gate': parameters['gate'], 'status': status,
        'main': parameters['main'], 'research_status': 'AUTHOR_DERIVED / EXTERNAL_REVIEW_OPEN',
        'parameters_sha256': hashlib.sha256((HERE / 'parameters.json').read_bytes()).hexdigest(),
        'source_bindings_sha256': hashlib.sha256((HERE / 'SOURCE_BINDINGS.json').read_bytes()).hexdigest(),
        'root_box': root, 'reference': model.reference, 'nodes': nodes,
        'leaf_ids': sorted(leaves), 'node_count': len(nodes), 'leaf_count': len(leaves),
        'tree_evaluations': tree_evaluations, 'total_evaluations_with_diagnostics': len(evaluations),
        'excluded_leaf_count': len(leaves) - len(live),
        'within_target_leaf_count': sum(n['evaluation']['status'] == 'WITHIN_TARGET' for n in live),
        'unresolved_leaf_count': sum(n['evaluation']['status'] == 'UNRESOLVED' for n in live),
        'split_counts': {k: decisions.count(k) for k in variables},
        'common_total_corridor_upper': max(n['evaluation']['width_upper'] for n in live),
        'strict_target_degrees': 10, 'exact_partition_volume': F(1), 'stop_reason': stop,
        'diagnostics': diagnostics, 'inherited_point_containing_leaves': containing,
        'certified_separated_point_pair': None, 'existence_from_box_survival': False,
        'full_nuisance_uncertainties_retained': True, 'all_stage_a_and_new_Y68_data_used': True,
        'large_operator_integrals_repeated': False, 'new_Y58_dual_computation': False,
        'A13_inputs_used': False, 'independent_large_operator_implementation': False})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    assert not args.out.exists()
    parameters = json.loads((HERE / 'parameters.json').read_bytes())
    with tempfile.TemporaryDirectory(prefix='adaptive-y68-') as name:
        result = run(Path(name), parameters)
    args.out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({k: result[k] for k in ('status', 'node_count', 'leaf_count', 'split_counts', 'common_total_corridor_upper', 'stop_reason')}), flush=True)


if __name__ == '__main__':
    main()
