"""Exact diagnostic aggregation; decimal displays are explicitly outward."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json
from angle_model import HERE


def decimal(x, upper=False, places=9):
    scale = 10**places
    q = F(x)*scale
    n = -((-q.numerator)//q.denominator) if upper else q.numerator//q.denominator
    sign = '-' if n < 0 else ''
    n = abs(n)
    return f'{sign}{n//scale}.{n%scale:0{places}d}'


def main():
    data = json.loads((HERE/'verification.json').read_bytes())
    nodes = {n['id']: n for n in data['nodes']}
    leaves = [nodes[k] for k in data['leaf_ids']]
    widths = [F(n['evaluation']['width_upper']) for n in leaves if n['evaluation']['status'] != 'EXCLUDED']
    informative, all_equal = [], []
    for node in data['nodes']:
        if 'alternatives' not in node:
            continue
        prefixes = {key: tuple(map(F, row['score'][:4])) for key, row in node['alternatives'].items()}
        if len(set(prefixes.values())) == 1:
            all_equal.append(node['id'])
        else:
            informative.append(node['split_variable'])
    rows = []
    for item in data['diagnostics']:
        parent = F(nodes[item['leaf_id']]['evaluation']['width_upper'])
        record = {'leaf': item['leaf_id'], 'parent_width_upper': str(parent), 'axes': {}}
        for axis, option in item['alternatives'].items():
            live = [r for r in option['children'] if r['status'] != 'EXCLUDED']
            childwidths = [F(r['width_upper']) for r in live]
            worst = max(childwidths, default=F(0))
            mean = sum(childwidths, F(0))/max(1,len(childwidths))
            record['axes'][axis] = {'excluded_children': 2-len(live), 'worst_child_width_upper': str(worst),
                'gain_in_worst_bound': str(parent-worst), 'gain_in_mean_bound': str(parent-mean)}
        rows.append(record)
    aggregate = {}
    for axis in data['split_counts']:
        worst_gains = [F(row['axes'][axis]['gain_in_worst_bound']) for row in rows]
        mean_gains = [F(row['axes'][axis]['gain_in_mean_bound']) for row in rows]
        aggregate[axis] = {'max_worst_bound_gain': str(max(worst_gains, default=F(0))),
                           'max_mean_bound_gain': str(max(mean_gains, default=F(0))),
                           'probes_with_positive_worst_gain': sum(g>0 for g in worst_gains),
                           'probes_with_positive_mean_gain': sum(g>0 for g in mean_gains)}
    conditional_all = [F(item['conditional_midpoint_probes']['Y57,Y58,Y67,Y68']['width_upper']) for item in data['diagnostics']]
    out = {'status': data['status'], 'nodes': data['node_count'], 'leaves': data['leaf_count'],
           'excluded': data['excluded_leaf_count'], 'within_target': data['within_target_leaf_count'],
           'unresolved': data['unresolved_leaf_count'], 'tree_evaluations': data['tree_evaluations'],
           'all_evaluations': data['total_evaluations_with_diagnostics'],
           'leaf_width_upper_range_outward_degrees': [decimal(min(widths)), decimal(max(widths), True)],
           'leaves_with_bound_below_180': sum(x<180 for x in widths),
           'depth_counts': dict(sorted(Counter(n['depth'] for n in leaves).items())),
           'split_counts': data['split_counts'], 'all_four_sensitivity_scores_equal': len(all_equal),
           'decisions_with_nontrivial_sensitivity': len(informative),
           'selected_axes_in_nontrivial_decisions': dict(Counter(informative)),
           'diagnostic_half_split_gains': aggregate, 'diagnostic_rows': rows,
           'all_four_fixed_conditional_width_upper_range_outward': [decimal(min(conditional_all)), decimal(max(conditional_all), True)],
           'diagnostics_do_not_establish_feasibility_or_a_uniform_angle': True}
    (HERE/'summary.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8', newline='\n')
    shown = {k:v for k,v in out.items() if k not in ('diagnostic_half_split_gains', 'diagnostic_rows')}
    shown['half_split_gains_degrees_display'] = {k:{a:float(F(b)) if isinstance(b,str) else b for a,b in r.items()} for k,r in aggregate.items()}
    print(json.dumps(shown, indent=2))


if __name__ == '__main__':
    main()
