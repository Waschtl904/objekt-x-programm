"""Keep all nuisance intervals while restricting the four axes near known points."""
from pathlib import Path
from fractions import Fraction as F
import argparse
import hashlib
import json
import tempfile
from angle_model import HERE, load_model, evaluate, cache_fixed_functionals


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    raw = (HERE/'inputs/counterfamily.json').read_bytes()
    points = json.loads(raw)['certified_completions']
    rows = {}
    with tempfile.TemporaryDirectory(prefix='known-point-slices-') as name:
        model, v, variables, _, _ = load_model(Path(name))
        cache_fixed_functionals(model, v)
        for label, point in points.items():
            box = {key: tuple(map(F, point['corrected_Y'][i][j])) for key,(i,j) in variables.items()}
            assert all(model.root_box()[key][0] <= lo <= hi <= model.root_box()[key][1] for key,(lo,hi) in box.items())
            row = evaluate(model, v, box)
            assert row['status'] != 'EXCLUDED'
            rows[label] = {'four_coordinate_box': box, 'evaluation': row,
                           'all_other_Y_and_full_moment_uncertainties_retained': True,
                           'conditional_slice_contains_inherited_certified_completion': True}
            print(label, row['status'], float(row['width_upper']), row['enclosure_unresolved'], flush=True)
        out = {'status': 'DIAGNOSTIC_ONLY', 'inherited_points_sha256': hashlib.sha256(raw).hexdigest(),
               'slices': rows, 'new_feasibility_claim': False,
               'uniform_family_angle_claim': False,
               'proof_that_all_refinements_must_fail': False,
               'nuisance_inputs_replaced_by_midpoints': False}
        args.out.write_text(json.dumps(v.rational(out), indent=2)+'\n', encoding='utf-8', newline='\n')


if __name__ == '__main__':
    main()
