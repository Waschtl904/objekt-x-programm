"""Load the unchanged common model and impose all Stage-A and Y68 data."""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import json
import sys
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
sys.set_int_max_str_digits(0)


def load_model(temp):
    bindings = json.loads((HERE / 'SOURCE_BINDINGS.json').read_bytes())
    for path, record in bindings['files'].items():
        assert hashlib.sha256((HERE / path).read_bytes()).hexdigest() == record['sha256'], path
    sys.path.insert(0, str(HERE / 'inputs/upstream'))
    import verify_box_gate as upstream
    from box_math import BoxModel, VARIABLES, split_box
    _, files, transport, old, v, df = upstream.dependencies(temp, False)
    source = json.loads(df['inputs/primary.json'])
    outer = json.loads(df['inputs/outer_primary.json'])
    projected = json.loads(df['inputs/projected_verification.json'])
    inherited = json.loads(df['verification.json'])
    gate_raw = (HERE / 'inputs/gate.json').read_bytes()
    gate = json.loads(gate_raw)
    angle = json.loads((HERE / 'inputs/angle.json').read_bytes())
    stage_raw = (HERE / 'inputs/stage_a.json').read_bytes()
    stage = json.loads(stage_raw)
    assert gate['algebra_status'] == 'PASS' and gate['strict_rotated_witness_exclusion'] and gate['signed_gate_passed']
    assert angle['gate_sha256'] == hashlib.sha256(gate_raw).hexdigest()
    assert angle['prior_stage_a_sha256'] == hashlib.sha256(stage_raw).hexdigest()
    model = BoxModel(v, source, outer, projected, inherited)
    fresh = v.matrix(stage['Y_direct_enclosure'])
    fresh[5][7] = tuple(map(F, gate['intersected_Y68']))
    model.y = v.intersectmat(model.y, fresh)
    model.prepare()
    assert model.y == v.matrix(angle['new_Y_intersection'])
    assert model.reference == v.matrix(angle['physical_reference_coefficients'])
    old_witness = json.loads(files['verification.json'])
    assert F(old_witness['results']['rotated']['corrected_Y'][5][7][1]) < model.y[5][7][0]
    return model, v, VARIABLES, split_box, (transport, old, df)


def cache_fixed_functionals(model, v):
    """Reuse only H bounds depending on fixed Y_left and fixed factors.

    F_right - H Y_right and the intersection with F N are still recomputed
    for every box. No interval input is replaced by a midpoint.
    """
    cache = {}
    proxy = SimpleNamespace(**vars(v))

    def functional(f, y, mc, n):
        yl = [row[:6] for row in y]
        key = tuple(tuple(row) for matrix in (f, yl, mc) for row in matrix)
        if key not in cache:
            out, diagnostic = v.functional_enclosure(f, y, mc, n)
            cache[key] = diagnostic
            return out, diagnostic
        diagnostic = cache[key]
        fr = [row[6:] for row in f]
        yr = [row[6:] for row in y]
        joint = v.submat(fr, v.mm(diagnostic['H_enclosure'], yr))
        out = v.intersectmat(joint, v.mm(f, n))
        return out, {**diagnostic, 'factor_on_N': out}

    proxy.functional_enclosure = functional
    model.v = proxy
    return cache


def width_upper(v, sine_squared_upper):
    """Twice the angle to ONE common reference; rational outward bound."""
    s = F(sine_squared_upper)
    assert 0 <= s <= 1
    if s == 0:
        return F(0)
    if s == 1:
        return F(180)
    if s == F(1, 2):
        return F(90)
    if s < F(1, 2):
        ratio = v.sqrt_upper(s / (1 - s))
        return F(90) if ratio >= 1 else min(F(90), 2 * v.angle_degrees(v.point(ratio))[1])
    ratio = v.sqrt_lower((1 - s) / s)
    return F(90) if ratio >= 1 else min(F(180), 180 - 2 * v.angle_degrees(v.point(ratio))[0])


def evaluate(model, v, box):
    result = model.evaluate(box)
    if result['filter_status'] == 'EXCLUDED':
        return {'status': 'EXCLUDED', 'reasons': result['exclusion_reasons'], 'width_upper': None}
    direction = result.get('direction', {})
    sine = direction.get('sine_squared_to_common_reference')
    width = width_upper(v, sine[1]) if sine else F(180)
    return {'status': 'WITHIN_TARGET' if width < 10 else 'UNRESOLVED',
            'width_upper': width, 'sin2': sine,
            'enclosure_unresolved': direction.get('enclosure_unresolved'),
            'same_N_for_all_moments': direction.get('same_N_for_all_moments', False),
            'reasons': [], 'legacy_boolean_ignored': True}
