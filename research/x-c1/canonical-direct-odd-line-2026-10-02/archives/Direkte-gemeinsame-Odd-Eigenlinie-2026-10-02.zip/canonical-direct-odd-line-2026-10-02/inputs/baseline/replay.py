"""Replay the sealed adaptive gate without a repository or operator solver."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def manifest(folder):
    record = json.loads((folder/'manifest.json').read_bytes())['sha256']
    actual = {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file() and p != folder/'manifest.json'}
    assert actual == set(record)
    for name, expected in record.items():
        path = PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
        assert hashlib.sha256((folder/name).read_bytes()).hexdigest() == expected, name
    return len(record)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--work-dir', type=Path, required=True)
    parser.add_argument('--quick', action='store_true', help='skip only the 1,121-box numerical replay; not a complete numerical acceptance')
    args = parser.parse_args()
    work = args.work_dir.resolve()
    assert work != HERE and HERE not in work.parents
    assert not work.exists(), 'use a fresh external directory'
    count = manifest(HERE)
    work.mkdir(parents=True)
    allowed = {'check_controls.py', 'inputs/upstream/check_box_gate.py',
               'audit_certificate.py', 'check_leaf_order.py', 'probe_known_points.py', 'probe_uncertainty_groups.py', 'check_angles_arb.py'}
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')

    def run(script, arguments, log):
        assert script in allowed
        with (work/log).open('w', encoding='utf-8') as stream:
            subprocess.run(['python', '-B', str(HERE/script), *map(str, arguments)],
                executable=sys.executable, shell=False, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
        print(script+': PASS', flush=True)

    run('check_controls.py', [], 'controls.log')
    run('inputs/upstream/check_box_gate.py', [], 'upstream_controls.log')
    run('check_leaf_order.py', [], 'leaf_order.log')
    audit_args = ['--certificate', HERE/'verification.json', '--out', work/'audit.json']
    if args.quick:
        audit_args += ['--structure-only']
    run('audit_certificate.py', audit_args, 'audit.log')
    run('probe_known_points.py', ['--out', work/'known_point_slices.json'], 'known_points.log')
    assert (work/'known_point_slices.json').read_bytes() == (HERE/'known_point_slices.json').read_bytes()
    run('probe_uncertainty_groups.py', ['--out', work/'uncertainty_groups.json'], 'uncertainty_groups.log')
    assert (work/'uncertainty_groups.json').read_bytes() == (HERE/'uncertainty_groups.json').read_bytes()
    run('check_angles_arb.py', ['--certificate', HERE/'verification.json',
        '--additional-certificate', work/'known_point_slices.json',
        '--additional-certificate', work/'uncertainty_groups.json', '--out', work/'angle_controls.json'], 'angles.log')
    assert (work/'angle_controls.json').read_bytes() == (HERE/'angle_controls.json').read_bytes()
    audit = json.loads((work/'audit.json').read_bytes())
    result = {'status': 'PASS', 'mode': 'QUICK_CONTROLS' if args.quick else 'FULL_NUMERICAL_REPLAY', 'manifest_bindings': count,
              'unique_box_evaluations_replayed': audit['unique_numerical_evaluations_replayed'],
              'all_box_receipts_recomputed': audit['all_numeric_receipts_identical'],
              'known_point_slices_byte_replayed': True,
              'uncertainty_groups_byte_replayed': True,
              'angle_controls_byte_replayed': True,
              'independent_structure_audit': True, 'large_operator_integrals_repeated': False}
    (work/'REPLAY.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
