"""Optional live Git provenance check; numerical replay is self-contained."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    bindings = json.loads((HERE/'SOURCE_BINDINGS.json').read_bytes())
    commit = bindings['main']
    assert re.fullmatch('[0-9a-f]{40}', commit)
    for target, row in bindings['files'].items():
        source = row['source_path']
        for value in (source, target):
            path = PurePosixPath(value)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in value
        assert source.startswith('research/') and target.startswith('inputs/')
        raw = (HERE/target).read_bytes()
        actual = subprocess.check_output(['git', '-c', 'safe.directory='+repo.as_posix(), '-c',
            'core.longpaths=true', '-C', str(repo), 'show', commit+':'+source], shell=False)
        assert raw == actual and hashlib.sha256(raw).hexdigest() == row['sha256']
    out = {'status': 'PASS', 'commit': commit, 'source_files_checked': len(bindings['files']),
           'source_bindings_sha256': hashlib.sha256((HERE/'SOURCE_BINDINGS.json').read_bytes()).hexdigest(),
           'all_files_match_git_blobs': True}
    args.out.write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps(out))


if __name__ == '__main__':
    main()
