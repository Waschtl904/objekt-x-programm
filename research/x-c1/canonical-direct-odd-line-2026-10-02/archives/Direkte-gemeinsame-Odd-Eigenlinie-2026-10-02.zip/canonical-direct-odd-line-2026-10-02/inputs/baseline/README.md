# Adaptiver Odd-Winkel nach Y68

**UNRESOLVED · AUTHOR_DERIVED / EXTERNAL_REVIEW_OPEN**

Der begrenzte adaptive Test endet nach 255 Knoten mit 128 unentschiedenen
Blättern. Es gibt noch keinen uniformen Winkelkorridor unter 10 Grad und
keinen neuen Gegenzeugennachweis. Der Bericht erklärt die Sensitivitätsdaten
und die bedingten Diagnosen zu den verbleibenden Momentunsicherheiten.

- `ADAPTIVE_ANGLE_GATE.md`: Ergebnis und nächste konkrete Frage.
- `PROOF.md`: mathematische Abnahme, Überdeckung und Aussagegrenzen.
- `verification.json`: vollständiger Baum und alle Probeteilungen.
- `audit.json`: vollständige rationale Nachrechnung aller 1.121 Auswertungen.
- `angle_controls.json`: unabhängige Arb-Prüfung der Winkelobergrenzen.
- `known_point_slices.json`, `uncertainty_groups.json`: bedingte Diagnosen.
- `SOURCE_BINDINGS.json`, `source_check.json`: acht Eingaben aus dem gepinnten Main.
- `manifest.json`: vollständige Dateiliste und SHA-256-Bindungen.

## Reproduktion

Python 3.13 und `python-flint==0.9.0` genügen. Alle mathematischen Eingaben
für diesen kleinen Winkelblock sind enthalten. Ein Repository-Checkout,
Netzwerkzugriff und neue Operatorintegrale sind für den Replay nicht nötig.

```text
python -m pip install -r requirements.txt
python -B replay.py --work-dir /path/to/fresh-external-replay-directory
```

Der vollständige Replay prüft das Manifest und die Kontrollen, rekonstruiert
die Überdeckung und alle Teilungsentscheidungen, berechnet sämtliche
1.121 Boxquittungen erneut und wiederholt die zwölf zusätzlichen bedingten
Punkt-/Momentdiagnosen bytegleich. Anschließend kontrolliert Arb die Winkel.
Die Laufzeit hängt vom Rechner ab; im Abnahmelauf benötigen die rationalen
Boxrechnungen insgesamt etwa eine Viertelstunde.

```text
python -B replay.py --quick --work-dir /path/to/another-fresh-directory
```

`--quick` überspringt ausschließlich die vollständige numerische
1.121-Box-Nachrechnung. Es ist keine vollständige numerische Abnahme;
der Ergebnisdatensatz kennzeichnet diesen Unterschied ausdrücklich.

Die Suche selbst kann aus den vorab festgelegten Parametern neu erzeugt werden:

```text
python -B adaptive_gate.py --out /path/to/new-verification.json
```

Optionaler Git-Provenienzvergleich:

```text
python -B check_sources.py --repo /path/to/objekt-x-programm --out /path/to/source-check.json
```

Lokales Forschungspaket auf Basis von Main `65e7614683b5cf59db93d8a687d815cbff677612`.
Keine Integration oder Statuspromotion. #187/A13 wurde nicht verändert.
