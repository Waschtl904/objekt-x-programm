from pathlib import Path
import argparse, copy, json, sys, tempfile
from fractions import Fraction as F
HERE = Path(__file__).resolve().parent
BASE = HERE/'inputs/baseline'
if not BASE.exists():
    BASE = HERE.parent/'adaptive-angle-2026-10-02'
sys.path.insert(0, str(BASE))
from angle_model import load_model, evaluate, cache_fixed_functionals
from line_engine import evaluate_line


def run(out, centered=False, affine=False):
    with tempfile.TemporaryDirectory(prefix='direct-odd-line-') as temp:
        model, v, variables, _, dependencies = load_model(Path(temp))
        cache_fixed_functionals(model, v)
        rows = {}
        def assess(label, current, box, scope):
            old = evaluate(current, v, box)
            new = evaluate_line(current, v, box, centered, affine)
            rows[label] = {'scope': scope, 'box': box, 'old': old, 'direct': new}
            print(label, float(old['width_upper']), new['status'], float(new['width_upper']), new['root']['status'], flush=True)
            out.write_text(json.dumps(v.rational({'cases': rows}), indent=2, sort_keys=True)+'\n', encoding='utf-8', newline='\n')
        assess('root', model, model.root_box(), 'FULL_FAMILY')
        transport, _, df = dependencies
        e = transport.e
        source, outer = json.loads(df['inputs/primary.json']), json.loads(df['inputs/outer_primary.json'])
        measures = {suffix: e.measure(source['results'][key], outer['trials'][chamber])
            for suffix, chamber, key in [('A','A9-odd','A8->A9-odd'), ('B','A11-odd','A9->A11-odd')]}
        fixed = {letter+suffix: e.intervals(v, measures[suffix][field])
            for suffix in ('A','B') for letter, field in [('G','GP'),('L','LP'),('Z','ZP')]}
        for key in fixed:
            assert v.intersectmat(model.full[key], fixed[key]) == fixed[key]
        points = json.loads((BASE/'inputs/counterfamily.json').read_bytes())['certified_completions']
        for label, point in points.items():
            cy = v.matrix(point['corrected_Y'])
            assert v.intersectmat(model.y, cy) == cy
            box = {key: cy[i][j] for key, (i,j) in variables.items()}
            restricted = copy.copy(model)
            restricted.full, restricted.y = fixed, cy
            restricted.prepare()
            cache_fixed_functionals(restricted, v)
            assess('point/'+label, restricted, box, 'CONDITIONAL_INHERITED_CERTIFIED_COMPLETION')
            assess('slice/'+label, model, box, 'CONDITIONAL_FOUR_COORDINATES_ONLY')
        tree = json.loads((BASE/'verification.json').read_bytes())
        nodes = {x['id']: x for x in tree['nodes']}
        for diagnostic in tree['diagnostics']:
            ident = diagnostic['leaf_id']
            box = {key: tuple(map(F, bounds)) for key, bounds in nodes[ident]['box'].items()}
            assess('terminal/'+ident, model, box, 'TERMINAL_BOX_WITH_ALL_NUISANCE_INTERVALS')
        result = {'status': rows['root']['direct']['status'], 'cases': rows, 'centered_compression': centered, 'joint_affine':affine,
                  'central_model_is_point_central': True, 'no_new_operator_inputs': True,
                  'new_feasibility_claim': False, 'uniform_scope_only_root': True}
        out.write_text(json.dumps(v.rational(result), indent=2, sort_keys=True)+'\n', encoding='utf-8', newline='\n')


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--centered',action='store_true');p.add_argument('--affine',action='store_true');args=p.parse_args()
    run(args.out, args.centered, args.affine)
