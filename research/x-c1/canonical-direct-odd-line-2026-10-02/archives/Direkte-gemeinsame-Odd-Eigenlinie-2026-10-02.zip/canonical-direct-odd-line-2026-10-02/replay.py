"""Closed-manifest portable replay of the small direct-line experiment."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verify():
 data=json.loads((HERE/'manifest.json').read_bytes())['sha256']
 for name in data:
  path=PurePosixPath(name)
  assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
  assert (HERE/name).is_file() and not (HERE/name).is_symlink()
 actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 assert actual==set(data)|{'manifest.json'}
 for name,value in data.items():assert sha(HERE/name)==value,name
 source=json.loads((HERE/'SOURCE_BINDINGS.json').read_bytes())
 for name,value in source['baseline_files'].items():assert sha(HERE/'inputs/baseline'/name)==value,name
 assert len(source['baseline_files'])==41
 return data
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 assert not a.out.exists();verify();a.out.mkdir(parents=True)
 steps=[('comparison.json',['compare.py']),('centered_comparison.json',['compare.py','--centered']),('affine_comparison.json',['compare.py','--centered','--affine']),('controls.json',['check_controls.py'])]
 receipts=[]
 for filename,args in steps:
  command=[sys.executable,'-B',str(HERE/args[0]),*args[1:],'--out',str(a.out/filename)]
  with (a.out/(filename+'.log')).open('w',encoding='utf-8', newline='\n') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=HERE)
  assert (a.out/filename).read_bytes()==(HERE/filename).read_bytes(),filename
  receipts.append({'file':filename,'sha256':sha(a.out/filename),'byte_identical':True})
  print(filename,'byte-identical',flush=True)
 command=[sys.executable,'-B',str(HERE/'audit_receipts.py')]
 for filename,_ in steps[:3]:command += ['--certificate',str(a.out/filename)]
 command += ['--out',str(a.out/'audit.json')]
 with (a.out/'audit.log').open('w',encoding='utf-8', newline='\n') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=HERE)
 assert (a.out/'audit.json').read_bytes()==(HERE/'audit.json').read_bytes()
 receipts.append({'file':'audit.json','sha256':sha(a.out/'audit.json'),'byte_identical':True})
 result={'status':'PASS','manifest_sha256':sha(HERE/'manifest.json'),'receipts':receipts,'full_case_replays':57,'new_operator_integrals':False,'uniform_gate':'UNRESOLVED','baseline_files_unchanged':41}
 (a.out/'REPLAY.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8', newline='\n')
 print(json.dumps(result),flush=True)
if __name__=='__main__':main()
