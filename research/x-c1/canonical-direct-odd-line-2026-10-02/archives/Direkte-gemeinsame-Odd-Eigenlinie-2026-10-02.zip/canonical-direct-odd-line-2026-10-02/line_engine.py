"""Rational direct generalized eigenline enclosure; no inverse pencil/projector."""
from fractions import Fraction as F
from angle_model import width_upper


def compressed(model, box, centered=False):
    v = model.v
    y = model.matrix_y(box)
    n = v.scale(v.mm(model.ylinv, [row[6:] for row in y]), -1) + v.eye(2)
    n = v.intersectmat(n, v.matrix(model.nr['N']))
    def compress(a):
        if centered:
            from centered import compress as centered_compress
            return centered_compress(v, a, n)
        return v.symmetric(v.mm(v.mm(v.tr(n), a), n))
    g = v.symmetric(v.intersectmat(compress(model.full['GB']), v.matrix(model.nr['compressed_moment_entries']['G0'])))
    lo = v.symmetric(v.matrix(model.r['energy_Loewner_lower_in_raw_basis']))
    hi = v.symmetric(v.matrix(model.r['energy_Loewner_upper_in_raw_basis']))
    l = v.symmetric(v.intersectmat(v.intersectmat(compress(model.full['LB']), v.matrix(model.nr['compressed_moment_entries']['L0'])), v.hull_from_order(lo, hi)))
    z = v.symmetric(v.intersectmat(compress(model.full['ZB']), v.matrix(model.nr['compressed_moment_entries']['Z0'])))
    flo, _ = v.functional_enclosure(v.matrix(model.r['trial_resolvent_lower_factor']), y, v.matrix(model.r['central_left']), n)
    fhi, _ = v.functional_enclosure(v.matrix(model.r['trial_resolvent_upper_factor']), y, v.matrix(model.r['central_left']), n)
    def gram(a):
        if centered:
            from centered import gram as centered_gram
            return centered_gram(v, a)
        return v.mm(v.tr(a), a)
    zlo = v.submat(gram(flo), v.scale(compress(model.s), 1/model.nu**2))
    zhi = gram(fhi)
    z = v.symmetric(v.intersectmat(z, v.hull_from_order(zlo, zhi)))
    detl = v.intersect(v.determinant(l), (v.determinant(lo)[0], v.determinant(hi)[1]))
    assert detl[0] > 0, 'positive energy determinant not enclosed'
    return n, g, l, z, detl


def pencil(v, g, l, z, detl):
    adj = [[l[1][1], v.neg(l[0][1])], [v.neg(l[1][0]), l[0][0]]]
    h = v.addmat(l, v.scale(g, 34))
    rr = v.addmat(h, v.scale(z, 289))
    mt = v.addmat([[v.mul(detl, x) for x in row] for row in h], v.scale(v.mm(v.mm(g, adj), g), 289))
    return rr, mt


def coefficients(v, rr, mt):
    a, b, d = rr[0][0], rr[0][1], rr[1][1]
    p, q, r = mt[0][0], mt[0][1], mt[1][1]
    return [v.sub(v.mul(b, p), v.mul(a, q)), v.sub(v.mul(d, p), v.mul(a, r)), v.sub(v.mul(d, q), v.mul(b, r))]


def root(v, abc, joint=None):
    a, b, c = abc
    affine_coefficients = None
    if joint is not None:
        from affine import Affine
        affine_coefficients = [Affine(row['center'],row['linear'],row['remainder_radius']) for row in joint['coefficients']]
    def fun(s):
        ordinary = v.add(v.add(v.mul(a, v.square(s)), v.mul(b, s)), c)
        if affine_coefficients is not None:
            aa,bb,cc=affine_coefficients
            ss=Affine.input(s,'chart_s')
            ordinary=v.intersect(ordinary,(aa*ss*ss+bb*ss+cc).bounds())
        return ordinary
    def der(s):
        ordinary = v.add(v.mul(v.point(2), v.mul(a, s)), b)
        if affine_coefficients is not None:
            aa,bb,_=affine_coefficients
            ordinary=v.intersect(ordinary,(2*aa*Affine.input(s,'chart_s')+bb).bounds())
        return ordinary
    # A fixed rational sign grid avoids treating a poor initial chart as
    # mathematical failure. The grid is only a bracket search, never a sample
    # certificate: every accepted endpoint sign encloses the whole family.
    grid = [(F(k,1024), fun(v.point(F(k,1024)))) for k in range(-128,129)]
    negative = [s for s,value in grid if value[1] < 0]
    positive = [s for s,value in grid if value[0] > 0]
    candidates = sorted(((lo,hi) for lo in negative for hi in positive if lo < hi), key=lambda pair:(pair[1]-pair[0],pair))
    domains = candidates[:1]+[(-radius,radius) for radius in (F(1,32),F(1,16),F(1,8),F(1,2),F(2))]
    trials = []
    for s in domains:
        left, right, derivative = fun(v.point(s[0])), fun(v.point(s[1])), der(s)
        record = {'initial': s, 'left_value': left, 'right_value': right, 'derivative': derivative}
        trials.append(record)
        if not (left[1] < 0 < right[0] and derivative[0] > 0):
            continue
        steps = []
        for _ in range(12):
            mid = sum(s)/2
            image = v.sub(v.point(mid), v.div(fun(v.point(mid)), der(s)))
            narrowed = v.intersect(s, image)
            steps.append({'domain': s, 'image': image, 'intersection': narrowed,
                          'strict_inclusion': s[0] < image[0] <= image[1] < s[1]})
            if narrowed == s:
                break
            s = narrowed
        return {'status': 'UNIQUE_MAXIMAL_ROOT', 'interval': s, 'trials': trials, 'newton': steps,
                'bracket_grid': {'denominator':1024,'index_min':-128,'index_max':128,'negative_count':len(negative),'positive_count':len(positive)},
                'uniform_endpoint_signs': True, 'positive_derivative': True,
                'rayleigh_second_derivative_negative_at_root': True}
    return {'status': 'UNRESOLVED', 'trials': trials,
            'bracket_grid': {'denominator':1024,'index_min':-128,'index_max':128,'negative_count':len(negative),'positive_count':len(positive)}}


def physical(v, model, n, s):
    u = v.mm(n, [[s], [v.point(1)]])
    c, gb = model.reference, model.full['GB']
    def inner(x, y):
        return v.mm(v.mm(v.tr(x), gb), y)[0][0]
    floor = min(gb[i][i][0]-sum(v.absolute(gb[i][j]) for j in range(len(gb)) if i != j) for i in range(len(gb)))
    assert floor > 0
    uu, cc, uc = inner(u, u), inner(c, c), inner(u, c)
    uu = (max(uu[0], floor*sum(v.square(row[0])[0] for row in u)), uu[1])
    cc = (max(cc[0], floor*sum(v.square(row[0])[0] for row in c)), cc[1])
    assert uu[0] > 0 and cc[0] > 0
    cos2 = v.div(v.square(uc), v.mul(uu, cc))
    direct = min(F(1), max(F(0), 1-cos2[0]))
    error = v.submat(u, c)
    ee = inner(error, error)
    # P_c^perp u = P_c^perp (u-c), hence sin^2(theta) <= ||u-c||^2 / ||u||^2.
    residual = min(F(1), max(F(0), ee[1]/uu[0]))
    sine = min(direct, residual)
    return {'u': u, 'reference': c, 'norm_u': uu, 'norm_reference': cc, 'inner': uc,
            'direct_sine_squared_upper': direct, 'residual_norm_squared': ee,
            'residual_sine_squared_upper': residual, 'sine_squared_upper': sine,
            'direct_width_upper': width_upper(v, direct), 'width_upper': width_upper(v, sine)}


def evaluate_line(model, v, box, centered=False, affine=False):
    n, g, l, z, detl = compressed(model, box, centered)
    rr, mt = pencil(v, g, l, z, detl)
    abc = coefficients(v, rr, mt)
    joint = None
    if affine:
        from affine import joint_coefficients
        joint = joint_coefficients(model, box)
        abc = [v.intersect(x,y['bounds']) for x,y in zip(abc,joint['coefficients'])]
    isolated = root(v, abc, joint)
    result = {'status': 'UNRESOLVED', 'width_upper': F(180), 'N': n, 'G': g, 'L': l, 'Z': z,
              'det_L': detl, 'R': rr, 'M_tilde': mt, 'coefficients': abc, 'root': isolated}
    if joint is not None:
        result['joint_affine'] = joint
    if isolated['status'] == 'UNIQUE_MAXIMAL_ROOT':
        angle = physical(v, model, n, isolated['interval'])
        result.update(physical=angle, width_upper=angle['width_upper'])
        if angle['width_upper'] < 10:
            result['status'] = 'WITHIN_TARGET'
    return result
