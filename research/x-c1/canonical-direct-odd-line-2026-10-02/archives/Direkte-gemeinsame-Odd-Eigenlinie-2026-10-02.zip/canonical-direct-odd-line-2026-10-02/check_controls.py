"""Exact algebra and adverse-case checks independent of production formulas."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json,sys,tempfile
from compare import BASE
from angle_model import load_model
from line_engine import pencil,coefficients,root
from affine import Affine
from centered import compress


def matmul(a,b):return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]
def det(a):return a[0][0]*a[1][1]-a[0][1]*a[1][0]
def inv(a):
 d=det(a);return [[a[1][1]/d,-a[0][1]/d],[-a[1][0]/d,a[0][0]/d]]
def add(a,b):return [[x+b[i][j] for j,x in enumerate(row)] for i,row in enumerate(a)]
def scale(a,s):return [[x*s for x in row] for row in a]
def enclosed(expected,actual):return actual[0]<=expected<=actual[1]


def run(out):
 with tempfile.TemporaryDirectory(prefix='line-controls-') as tmp:
  _,v,_,_,_=load_model(Path(tmp))
  count=0
  for k in range(1,41):
   l=[[F(k+2),F(k,7)],[F(k,7),F(2*k+3)]]
   g=[[F(1+k,3),F(1,9)],[F(1,9),F(2+k,5)]]
   z=[[F(k+3),F(-1,11)],[F(-1,11),F(k+4)]]
   assert det(l)>0 and det(g)>0
   as_interval=lambda a:[[v.point(x) for x in row] for row in a]
   rr,mt=pencil(v,as_interval(g),as_interval(l),as_interval(z),v.point(det(l)))
   b=add(l,scale(g,17));exactmt=scale(matmul(matmul(b,inv(l)),b),det(l))
   exactrr=add(add(l,scale(g,34)),scale(z,289))
   for i in range(2):
    for j in range(2):assert enclosed(exactmt[i][j],mt[i][j]) and enclosed(exactrr[i][j],rr[i][j])
   abc=coefficients(v,rr,mt)
   for s in (F(-1,2),F(0),F(1,100),F(1,4)):
    w=[[s],[F(1)]];rw=matmul(exactrr,w);mw=matmul(exactmt,w)
    stationarity=rw[1][0]*mw[0][0]-rw[0][0]*mw[1][0]
    interval=v.add(v.add(v.mul(abc[0],v.point(s*s)),v.mul(abc[1],v.point(s))),abc[2])
    assert enclosed(stationarity,interval)
    p,q,r=exactmt[0][0],exactmt[0][1],exactmt[1][1]
    a,b,d=exactrr[0][0],exactrr[0][1],exactrr[1][1]
    num=a*s*s+2*b*s+d;den=p*s*s+2*q*s+r
    assert (2*a*s+2*b)*den-num*(2*p*s+2*q)==-2*stationarity
    count+=1
  zero=v.point(0)
  assert root(v,[zero,v.point(3),zero])['status']=='UNIQUE_MAXIMAL_ROOT'
  assert root(v,[zero,v.point(-3),zero])['status']=='UNRESOLVED'
  assert root(v,[zero,zero,zero])['status']=='UNRESOLVED'
  affine_checks=0
  x=Affine.input((F(-2,3),F(5,7)),'x');y=Affine.input((F(1,11),F(4,3)),'y')
  forms=[x+y,x*y,x*x,(x-y)*(x+y),x*y-y*x,17*x*x+3*x*y-5*y*y]
  for ex in [F(k,4) for k in range(-4,5)]:
   for ey in [F(k,4) for k in range(-4,5)]:
    xx=(F(-2,3)+F(5,7))/2+(F(5,7)+F(2,3))/2*ex
    yy=(F(1,11)+F(4,3))/2+(F(4,3)-F(1,11))/2*ey
    actual=[xx+yy,xx*yy,xx*xx,(xx-yy)*(xx+yy),F(0),17*xx*xx+3*xx*yy-5*yy*yy]
    for af,truth in zip(forms,actual):
     center=af.c+af.t.get('x',0)*ex+af.t.get('y',0)*ey
     assert abs(truth-center)<=af.e
     assert enclosed(truth,af.bounds());affine_checks+=1
  aa=[[(F(2),F(3)),(F(-1,10),F(1,10))],[(F(-1,10),F(1,10)),(F(4),F(5))]]
  nn=[[(F(1,2),F(3,2)),(F(-1,4),F(1,4))],[(F(-1,3),F(1,3)),(F(1),F(2))]]
  enclosure=compress(v,aa,nn)
  centered_checks=0
  for t in (F(0),F(1,3),F(2,3),F(1)):
   a=[[lo+t*(hi-lo) for lo,hi in row] for row in aa]
   n=[[lo+(1-t)*(hi-lo) for lo,hi in row] for row in nn]
   actual=matmul(matmul(list(map(list,zip(*n))),a),n)
   for i in range(2):
    for j in range(2):assert enclosed(actual[i][j],enclosure[i][j]);centered_checks+=1
  record={'status':'PASS','exact_stationarity_and_rayleigh_identities':count,'scaled_pencil_cases':40,
          'maximal_minimal_and_degenerate_controls':3,'affine_point_and_rounding_controls':affine_checks,
          'centered_quadratic_controls':centered_checks,'controls_are_not_a_proof_of_uniform_family_localization':True}
  out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8', newline='\n')
  print(json.dumps(record),flush=True)


if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);args=p.parse_args();run(args.out)
