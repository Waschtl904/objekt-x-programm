"""Centered quadratic evaluation with symmetric matrix and vector reuse."""
from fractions import Fraction as F


def bilinear(v, a, x, y, same=False):
    terms = []
    for i in range(len(a)):
        terms.append(v.mul(a[i][i], v.square(x[i]) if same else v.mul(x[i], y[i])))
        for j in range(i):
            pair = v.mul(v.point(2), v.mul(x[i], x[j])) if same else v.add(v.mul(x[i], y[j]), v.mul(x[j], y[i]))
            terms.append(v.mul(a[i][j], pair))
    return v.total(terms)


def compress(v, a, n):
    """N0^T A N0 + E^T A N0 + N0^T A E + E^T A E.

    Symmetric A entries are collected once. For diagonal entries the two
    linear terms coincide and squared variables use interval square.
    Every occurrence of A retains its whole input interval.
    """
    a = v.symmetric(a)
    n0 = [[v.point(sum(x)/2) for x in row] for row in n]
    e = v.submat(n, n0)
    an0 = v.mm(a, n0)
    out = [[None for _ in n[0]] for _ in n[0]]
    for i in range(len(out)):
        ci, ei = [row[i] for row in n0], [row[i] for row in e]
        for j in range(i+1):
            cj, ej = [row[j] for row in n0], [row[j] for row in e]
            constant = bilinear(v, a, ci, cj, i == j)
            first = v.total(v.mul(ei[k], an0[k][j]) for k in range(len(n)))
            second = first if i == j else v.total(v.mul(ej[k], an0[k][i]) for k in range(len(n)))
            remainder = bilinear(v, a, ei, ej, i == j)
            value = v.add(v.add(constant, v.add(first, second)), remainder)
            out[i][j] = out[j][i] = value
    ordinary = v.symmetric(v.mm(v.mm(v.tr(n), a), n))
    return v.intersectmat(out, ordinary)


def gram(v, a):
    result = v.mm(v.tr(a), a)
    for i in range(len(result)):
        result[i][i] = v.total(v.square(row[i]) for row in a)
    return v.symmetric(result)
