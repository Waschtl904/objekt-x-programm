"""Independent rational endpoint/Newton audit and independent Arb angle check."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json,sys
from flint import arb,fmpq,ctx
sys.set_int_max_str_digits(0)
def iv(x):return tuple(map(F,x))
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
 values=[x*y for x in a for y in b];return min(values),max(values)
def square(a):
 lo,hi=a;return (F(0) if lo<=0<=hi else min(lo*lo,hi*hi),max(lo*lo,hi*hi))
def div(a,b):
 assert b[0]>0 or b[1]<0
 return mul(a,(1/b[1],1/b[0]))
def meet(a,b):
 result=max(a[0],b[0]),min(a[1],b[1]);assert result[0]<=result[1];return result
def contains(outer,inner):return outer[0]<=inner[0]<=inner[1]<=outer[1]
def affine_combination(rows,weights):
 center=sum(F(row['center'])*weight for row,weight in zip(rows,weights))
 terms={}
 error=sum(F(row['remainder_radius'])*abs(weight) for row,weight in zip(rows,weights))
 for row,weight in zip(rows,weights):
  for key,value in row['linear'].items():terms[key]=terms.get(key,F(0))+F(value)*weight
 radius=error+sum(map(abs,terms.values()),F(0))
 return center-radius,center+radius
def exact_bound(ball):
 m,e=ball.man_exp();return F(int(m))*F(2)**int(e)


def audit(paths,out):
 ctx.prec=768
 count=steps_checked=0;angles=set();case_counts={};root_status={}
 for path in paths:
  data=json.loads(path.read_bytes());case_counts[path.name]=len(data['cases'])
  assert len(data['cases'])==19
  root_status[path.name]=data['cases']['root']['direct']['status']
  assert root_status[path.name]=='UNRESOLVED'
  for name,row in data['cases'].items():
   result=row['direct'];cert=result['root'];abc=list(map(iv,result['coefficients']))
   af=result.get('joint_affine',{}).get('coefficients')
   def fun(s):
    value=add(add(mul(abc[0],(s*s,s*s)),mul(abc[1],(s,s))),abc[2])
    if af:value=meet(value,affine_combination(af,[s*s,s,F(1)]))
    return value
   def derivative(s):
    value=add(mul((F(2),F(2)),mul(abc[0],s)),abc[1])
    if af:
     middle=sum(s)/2;radius=(s[1]-s[0])/2
     linear=affine_combination(af,[2*middle,F(1),F(0)])
     arange=iv(af[0]['bounds']);error=2*radius*max(map(abs,arange))
     value=meet(value,(linear[0]-error,linear[1]+error))
    return value
   if cert['status']!='UNIQUE_MAXIMAL_ROOT':
    assert result['status']=='UNRESOLVED' and F(result['width_upper'])==180
    continue
   count+=1;trial=cert['trials'][-1];domain=iv(trial['initial'])
   assert contains(iv(trial['left_value']),fun(domain[0]))
   assert contains(iv(trial['right_value']),fun(domain[1]))
   assert contains(iv(trial['derivative']),derivative(domain))
   assert F(trial['left_value'][1])<0<F(trial['right_value'][0]) and F(trial['derivative'][0])>0
   for step in cert['newton']:
    assert iv(step['domain'])==domain
    mid=sum(domain)/2
    mathematical_image=sub((mid,mid),div(fun(mid),derivative(domain)))
    assert contains(iv(step['image']),mathematical_image)
    assert bool(step['strict_inclusion'])==(domain[0]<F(step['image'][0])<=F(step['image'][1])<domain[1])
    domain=meet(domain,iv(step['image']));assert domain==iv(step['intersection']);steps_checked+=1
   assert domain==iv(cert['interval'])
   assert cert['uniform_endpoint_signs'] and cert['positive_derivative'] and cert['rayleigh_second_derivative_negative_at_root']
   angle=result['physical'];sine=F(angle['sine_squared_upper']);width=F(result['width_upper'])
   assert 0<=sine<=1 and width==F(angle['width_upper'])
   direct=F(angle['direct_sine_squared_upper']);residual=F(angle['residual_sine_squared_upper'])
   assert sine==min(direct,residual)
   assert result['status']==('WITHIN_TARGET' if width<10 else 'UNRESOLVED')
   angles.add((sine,width));angles.add((direct,F(angle['direct_width_upper'])))
 for sine,width in angles:
  if sine in (0,1):assert width>={0:F(0),1:F(180)}[sine]
  else:
   actual=360*arb(fmpq(sine.numerator,sine.denominator)).sqrt().asin()/arb.pi()
   assert exact_bound(actual.upper())<=width
 record={'status':'PASS','comparison_case_counts':case_counts,'uniform_root_status':root_status,
         'independent_rational_maximal_root_certificates':count,'independent_newton_steps':steps_checked,
         'independent_Arb_768bit_angle_bounds':len(angles),'no_uniform_angle_promotion':True}
 out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8', newline='\n');print(json.dumps(record),flush=True)


if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--certificate',type=Path,action='append',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();audit(a.certificate,a.out)
