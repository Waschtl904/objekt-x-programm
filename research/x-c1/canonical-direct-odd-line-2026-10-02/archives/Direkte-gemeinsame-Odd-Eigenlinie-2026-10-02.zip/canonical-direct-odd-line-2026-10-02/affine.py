"""First-order Taylor forms with exact rational coefficients and bounded remainder."""
from fractions import Fraction as F


class Affine:
    SCALE = 10**100

    def __init__(self, center=0, terms=None, error=0):
        center, error = F(center), F(error)
        assert error >= 0
        def rounded(value):
            value=F(value)
            return F((value.numerator*self.SCALE)//value.denominator,self.SCALE)
        self.c = rounded(center)
        self.t = {}
        error += abs(center-self.c)
        for key,value in (terms or {}).items():
            value=F(value);replacement=rounded(value)
            error += abs(value-replacement)
            if replacement:self.t[key]=replacement
        self.e = F(-((-error.numerator*self.SCALE)//error.denominator),self.SCALE)

    @staticmethod
    def input(bounds, key):
        lo, hi = bounds
        assert lo <= hi
        return Affine((lo+hi)/2, {key:(hi-lo)/2})

    def radius(self):
        return sum(map(abs, self.t.values()), self.e)

    def bounds(self):
        radius = self.radius()
        return self.c-radius, self.c+radius

    @staticmethod
    def coerce(other):
        return other if isinstance(other, Affine) else Affine(other)

    def __add__(self, other):
        other = self.coerce(other)
        terms = dict(self.t)
        for key, value in other.t.items():
            terms[key] = terms.get(key, F(0))+value
        return Affine(self.c+other.c, terms, self.e+other.e)

    __radd__ = __add__

    def __neg__(self):
        return Affine(-self.c, {k:-x for k,x in self.t.items()}, self.e)

    def __sub__(self, other):
        return self+-self.coerce(other)

    def __rsub__(self, other):
        return self.coerce(other)+-self

    def __mul__(self, other):
        other = self.coerce(other)
        terms = {k:self.c*other.t.get(k, F(0))+other.c*self.t.get(k, F(0)) for k in self.t.keys() | other.t.keys()}
        # The exact shared diagonal eps_i^2 lies in [0,1]. All remaining
        # second-order terms and inherited errors use their L1 bounds.
        diagonal = [x*other.t.get(k, F(0)) for k,x in self.t.items()]
        shift = sum(diagonal, F(0))/2
        error = abs(self.c)*other.e+abs(other.c)*self.e+self.radius()*other.radius()-sum(map(abs, diagonal), F(0))/2
        return Affine(self.c*other.c+shift, terms, error)

    __rmul__ = __mul__

    def receipt(self):
        return {'center':self.c,'linear':self.t,'remainder_radius':self.e,'bounds':self.bounds()}


def matrix_input(matrix, label, symmetric=False):
    return [[Affine.input(x, label+'/'+str(max(i,j) if symmetric else i)+'/'+str(min(i,j) if symmetric else j))
             for j,x in enumerate(row)] for i,row in enumerate(matrix)]


def mm(a,b):
    return [[sum((x*b[k][j] for k,x in enumerate(row)), Affine()) for j in range(len(b[0]))] for row in a]


def tr(a):return [list(row) for row in zip(*a)]
def add(a,b):return [[x+b[i][j] for j,x in enumerate(row)] for i,row in enumerate(a)]
def scale(a,s):return [[x*s for x in row] for row in a]
def determinant(a):return a[0][0]*a[1][1]-a[0][1]*a[1][0]


def joint_coefficients(model, box):
    # Each Y and inverse-Y_left entry is retained as one shared variable.
    # Treating the inverse enclosure independently only enlarges the family.
    y = matrix_input([row[6:] for row in model.matrix_y(box)], 'Yright')
    inverse = matrix_input(model.ylinv, 'Yleft_inverse')
    n = scale(mm(inverse, y), -1)+[[Affine(1),Affine(0)],[Affine(0),Affine(1)]]
    matrices = {}
    for name in ('G','L','Z'):
        a = matrix_input(model.full[name+'B'], name+'B', True)
        matrices[name] = mm(mm(tr(n), a), n)
    g,l,z = (matrices[k] for k in ('G','L','Z'))
    detl = determinant(l)
    adj = [[l[1][1],-l[0][1]],[-l[1][0],l[0][0]]]
    h=add(l,scale(g,34));rr=add(h,scale(z,289))
    mt=add(scale(h,detl),scale(mm(mm(g,adj),g),289))
    a,b,d=rr[0][0],rr[0][1],rr[1][1]
    p,q,r=mt[0][0],mt[0][1],mt[1][1]
    abc=[b*p-a*q,d*p-a*r,d*q-b*r]
    return {'coefficients':[x.receipt() for x in abc],
            'moments':{k:[[x.receipt() for x in row] for row in matrix] for k,matrix in matrices.items()},
            'shared_input_count':len(set().union(*(set(x.t) for x in abc))),
            'coefficient_decimal_places':100,'all_rounding_errors_paid':True,
            'all_input_intervals_retained':True}
