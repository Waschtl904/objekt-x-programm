"""Signed analytic correction for a core/shell Gamma parity mismatch.
No change to repository or frozen packages. No residual quadrature.
"""
import sys,signal
from pathlib import Path
from math import factorial
from fractions import Fraction as F
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from load_context import *
signal.alarm(1800)
resmod=module('correction_residuals',ROOT/'research/x-c1/w9-partial-energy-2026-10-18/residuals.py');of=module('correction_old_fields',ROOT/'research/x-c1/w9-partial-energy-2026-10-18/old_fields.py');res=resmod.Residuals(env['inp'],'even')
logmod=module('correction_log_integrals',WHOLE/'vendor/log_integrals.py')
ns={'arb':arb,'arb_mat':arb_mat,'arb_poly':arb_poly,'factorial':factorial,'q':q,'c':c,'res':res,'of':of,'leg':res.legs,'old':env['inp'].json('a8_model')};ns.update(values)
source=(WHOLE/'whole_function_probe.py').read_text();code=source[source.index('gamma=of.gamma_coefficients'):source.index('\ng,prime,*_=')]
assert code.count('regular_out(ym)(arb_poly([0,a]))')==1
code=code.replace('regular_out(ym)(arb_poly([0,a]))','regular_core(ym)(arb_poly([0,a]))')
def regular_core(moments):
 co=ns['convker']*arb_poly([moments[k]/ns['fac'][k]for k in range(225)])
 return arb_poly([co[224-k]/ns['fac'][k]*(1+(-1)**k)for k in range(225)])
ns['regular_core']=regular_core
exec(compile(code,'candidate_core_kernel_correction','exec'),ns)
a,b,hs,mid,half,delta,mu=(values[k]for k in ('a','b','hs','mid','half','delta','mu'))
J,Y,wc,pv,ff=(values[k]for k in ('J','Y','w','pv','ff'))
eta=q('1e-10');fY=arb_mat([[pv[i,0]]for i in range(4,12)])
local_S=J*wc-Y*fY;local_psi=Y*fY-(J*wc)*(1-eta)
def poly_source(local):
 pol=sum((res.legs[k]*(local[k,0]*(arb(2*k+1)/(2*hs)).sqrt())for k in range(96)),arb_poly([]))
 return pol(arb_poly([-mid/half,1/half]))
def correction(local):
 spx=poly_source(local)
 moments=[c.pint(spx*arb_poly([0]*k+[1]),a,b)for k in range(225)]
 # Q has MINUS the regular kernel, hence old kernel minus correct kernel.
 return (ns['regular_out'](moments)-regular_core(moments))(arb_poly([0,a]))
CS=correction(local_S);Cpsi=correction(local_psi)
alpha=c.pint(CS)/c.mellin(0,a)
v=(CS-ns['mc']*alpha)*(1/delta)
Ipsi=a*c.pint(Cpsi*ns['mc'])
assert c.pint(v).contains(0) or abs(c.pint(v)).upper()<q('1e-150')
mom=logmod.Moments(values['roots'],800)
previous=json.loads((BASE/'localized-pairing/localized-result.json').read_bytes())
raw=env['inp'].json('old_sources')['cases'][0];cJ=mat(raw['galerkin']['old_low_c_model'])
rows=[]
for i in range(84):
 ej=arb_mat(84,1);ej[i,0]=1
 parts,prime,_,_,lmJ,_=ns['build_core'](arb_mat(191,1),arb_mat(12,1),ej)
 primes=[prime(lo,hi)for lo,hi in zip(values['edges'][:-1],values['edges'][1:])]
 vp=logmod.function_product({None:v},parts,mom,'zero','one')
 for (lo,hi),pp in zip(values['cells'],primes):vp+=mom.integral(v*pp,lo,hi)
 corecorr=2*a*vp
 directmomentcorr=-2*lmJ*Ipsi/mu
 change=corecorr+directmomentcorr
 old=c.box(previous['rows'][i]['Delta_interval'])
 remaining=old+change
 row=c.encode({'coordinate':i+1,'old_Delta_interval':old,'core_U_correction':corecorr,'direct_moment_correction':directmomentcorr,
  'signed_corrected_minus_original_pairing':change,'corrected_Delta_interval':remaining,
  'corrected_Delta_contains_zero':remaining.contains(0),
  'corrected_Delta_absolute_upper':abs(remaining).upper(),
  'old_midpoint_plus_correction':old.mid()+change,'old_integration_cap':c.box(previous['rows'][i]['total_integration_cap'])})
 rows.append(row)
 if i%8==0 or i==83:
  print('COORD',i+1,'CHANGE',change.str(16),'LEFT',remaining.str(12),'MID',(old.mid()+change).str(12),'TIME',round(time.monotonic()-start,2),flush=True)
  out={'status':'SOURCE_IDENTIFIED_FROZEN_MODEL_CORRECTION_ANALYTIC','rows':rows,'all_completed':i==83,
       'complete_connection_accepted':False,'no_new_residual_quadrature':True,'repository_modified':False,
       'coefficients':c.encode({'core_source_correction_t':list(CS),'direct_source_correction_t':list(Cpsi),
          'projected_U_correction_t':list(v),'alpha_correction':alpha,'direct_moment_correction_integral':Ipsi}),
       'sources':{'published_builder_sha256':sha((WHOLE/'whole_function_probe.py').read_bytes()),
          'prior_localized_result_sha256':sha((BASE/'localized-pairing/localized-result.json').read_bytes())},'elapsed_seconds':time.monotonic()-start}
  (HERE/'kernel-correction.json').write_text(json.dumps(out,indent=2)+'\n')
print('COMPLETE',sum(r['corrected_Delta_contains_zero']for r in rows),'of 84',flush=True)
