import sys,signal
from pathlib import Path
from math import factorial
from fractions import Fraction as F
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from load_context import *
signal.alarm(1800)
for alias in ['old_source_code','old_global_code','old_kernel_code']:(HERE/(alias+'.txt')).write_bytes(env['inp'].data[alias])
resmod=module('low_residuals',ROOT/'research/x-c1/w9-partial-energy-2026-10-18/residuals.py');of=module('low_old_fields',ROOT/'research/x-c1/w9-partial-energy-2026-10-18/old_fields.py');res=resmod.Residuals(env['inp'],'even')
logmod=module('low_log_integrals',WHOLE/'vendor/log_integrals.py')
ns={'arb':arb,'arb_mat':arb_mat,'arb_poly':arb_poly,'factorial':factorial,'q':q,'c':c,'res':res,'of':of,'leg':res.legs,'old':env['inp'].json('a8_model')};ns.update(values)
source=(WHOLE/'whole_function_probe.py').read_text()
code=source[source.index('gamma=of.gamma_coefficients'):source.index('\ng,prime,*_=')]
assert code.count('regular_out(ym)(arb_poly([0,a]))')==1
code=code.replace('regular_out(ym)(arb_poly([0,a]))','regular_core(ym)(arb_poly([0,a]))')
def regular_core(moments):
 co=ns['convker']*arb_poly([moments[k]/ns['fac'][k]for k in range(225)])
 return arb_poly([co[224-k]/ns['fac'][k]*(1+(-1)**k)for k in range(225)])
ns['regular_core']=regular_core
exec(compile(code,'candidate_core_kernel_correction','exec'),ns)
v=arb_mat(84,1);v[0,0]=1;parts,prime,*_=ns['build_core'](arb_mat(191,1),arb_mat(12,1),v)
print('Degrees',[(k,len(p))for k,p in parts.items()],flush=True)
primes=[prime(lo,hi)for lo,hi in zip(values['edges'][:-1],values['edges'][1:])]
mom=logmod.Moments(values['roots'],1000)
ms=logmod.function_moments(parts,mom,'zero','one',382)
for (lo,hi),pp in zip(values['cells'],primes):
 ppms=mom.polynomial_moments(pp,lo,hi,382);ms=[x+y for x,y in zip(ms,ppms)]
raw=env['inp'].json('old_sources')['cases'][0];cj=mat(raw['galerkin']['old_low_c_model'])
rows=[]
for j,p in enumerate(ns['phi']):
 vv=2*values['a']*sum((p[k]*ms[k]for k in range(len(p))),arb(0))
 dif=vv-cj[j,0]
 rows.append(c.encode({'low_index':j,'value':vv,'stored':cj[j,0],'difference':dif,'weighted_difference':dif*values['ff'][j,0]}))
 if j in [0,1,2,3,4,5,10,30,50,100,190]:print(j,'new',vv.str(15),'old',cj[j,0].str(15),'diff',dif.str(15),'f',values['ff'][j,0].str(10),flush=True)
(HERE/'corrected-low-source-check.json').write_text(json.dumps({'status':'DIAGNOSTIC','rows':rows},indent=2)+'\n')
print('TIME',time.monotonic()-start,flush=True)
