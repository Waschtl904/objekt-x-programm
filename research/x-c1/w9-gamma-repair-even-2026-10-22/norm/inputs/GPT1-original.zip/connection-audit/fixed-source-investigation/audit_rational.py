"""Pure rational endpoint audit, with a symbolic monomial counterexample."""
import json
from fractions import Fraction as F
from pathlib import Path
from math import comb
here=Path(__file__).resolve().parent
p=json.loads((here/'kernel-correction.json').read_bytes())
assert p['all_completed'] and len(p['rows'])==84
contains=0;maxremaining=F(0);maxold=F(0);maxratio=F(0)
for r in p['rows']:
 a,b=map(F,r['old_Delta_interval']);c,d=map(F,r['signed_corrected_minus_original_pairing']);lo,hi=map(F,r['corrected_Delta_interval'])
 assert lo<=a+c and hi>=b+d
 assert lo<=0<=hi and not a<=0<=b
 cap=max(abs(lo),abs(hi));maxremaining=max(maxremaining,cap);maxold=max(maxold,abs(a),abs(b));contains+=1
 maxratio=max(maxratio,cap/min(abs(a),abs(b)))
# First odd kernel monomial, rational a=1,b=2,x=1/2, s(y)=1.
# The kernel argument is distance/2, as in the actual Gamma polynomial.
a,b,x=F(1),F(2),F(1,2);M0=b-a;M1=(b*b-a*a)/2
gamma1=F(-1,24)
correct=gamma1*M1;wrong=gamma1*x*M0
assert correct==F(-1,16) and wrong==F(-1,48) and wrong-correct==F(1,24)
# Pure integer parity identities: even kernel powers are unaffected; odd ones
# change the placement of the parity projector from l to k-l.
for k in range(225):
 for ell in range(k+1):
  good=1+(-1)**ell;bad=1+(-1)**(k-ell)
  assert (good==bad)if k%2==0 else(good+bad==2 and good!=bad)
low=json.loads((here/'corrected-low-source-check.json').read_bytes())
assert len(low['rows'])==191
assert all(F(r['difference'][0])<=0<=F(r['difference'][1])for r in low['rows'])
outer=json.loads((here/'correction-outer-check.json').read_bytes())
assert len(outer['rows'])==84
for r in outer['rows']:
 lo,hi=map(F,r['difference']);assert lo<=0<=hi
 a,b=map(F,r['outer_correction_pairing']);cc,dd=map(F,r['adjoint_correction_pairing'])
 assert max(a,cc)<=min(b,dd)
bounds=outer['bounds']
assert F(bounds['correction_X_norm_upper'][1])<F('3.653e-7')
assert F(bounds['corrected_model_X_norm_upper_by_triangle'][1])<F('1.924e-6')
assert F(bounds['conditional_repaired_Ldual_energy_upper'][1])<F('4.632e-11')<F('1e-9')
result={'84_corrected_difference_intervals_contain_zero':contains,'191_corrected_first_test_low_source_intervals_contain_zero':True,
 'maximum_old_difference_absolute':str(maxold),'maximum_corrected_difference_absolute':str(maxremaining),
 'worst_remaining_to_old_lower_magnitude_ratio':str(maxratio),
 'monomial_counterexample':{'a':'1','b':'2','x':'1/2','gamma_1':'-1/24','correct':'-1/16','published_formula':'-1/48','published_minus_correct':'1/24'},
 'parity_cases':sum(k+1 for k in range(225)),'84_outer_and_adjoint_pairings_overlap':True,'correction_X_norm_cap':'3.653e-7','conditional_repaired_energy_cap':'4.632e-11','original_energy_cap':'1e-9','conclusion':'The parity substitution is an algebraic defect; interval containment is checked separately.'}
(here/'rational-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('84 corrected intervals; 191 source coordinates; 25425 parity cases checked.')
print('max old',float(maxold),'max remaining',float(maxremaining),'max remaining / old lower magnitude',float(maxratio))
