"""Second analytic route for the Gamma correction, including its full X norm."""
from pathlib import Path
HERE=Path(__file__).resolve().parent
code=(HERE/'kernel_correction.py').read_text()
exec(compile(code[:code.index('\nrows=[]')],'correction_context','exec'))
# Exterior Q action of v supported on [-a,a], even by reflection.
# The source v on the positive half need not itself be an even polynomial.
vmom=[a**(k+1)*c.pint(v*arb_poly([0]*k+[1]))for k in range(225)]
reg=ns['regular_out'](vmom)
quot=arb_poly([sum((v[k]/(k-j)for k in range(j+1,len(v))),arb(0))for j in range(len(v)-1)])
plus=arb_poly([0,1/a]);minus=arb_poly([0,-1/a])
vp,vm=v(plus),v(minus)
parts={None:(quot(plus)-quot(minus))*(arb(1)/2)-reg,'zero':-(vp-vm)*(arb(1)/2),'left':vp*(arb(1)/2),'minus_left':-vm*(arb(1)/2)}
# Every translated point is within the core for this shell; certify the side.
for n,(sh,wt)in zip((2,3,4,5,7,8),values['channels']):
 # x+log(n)>a throughout. For x-log(n), n=2 is positive;
 # n>=3 is negative, with the exact endpoint identities log(3)=b,
 # log(8)=2a handled symbolically instead of comparing rounded equal balls.
 assert a+sh>a
 lo,hi=a-sh,b-sh
 assert lo>-a if n!=8 else (sh-2*a).contains(0)
 assert hi<a
 if n==2:
  assert lo>0
  aff=arb_poly([-sh/a,1/a])
 else:
  assert hi<0 if n!=3 else (sh-b).contains(0)
  aff=arb_poly([sh/a,-1/a])
 parts[None]-=v(aff)*wt

Iq=logmod.function_product({None:v},ns['qm'],mom,'zero','one')
for (ll,hh),(lo,hi)in zip(values['cells'],zip(values['edges'][:-1],values['edges'][1:])):
 at=(lo+hi)/2;qp=arb_poly([])
 for sh,wt in values['channels']:
  for sg in (-1,1):
   if abs(at+sg*sh)<a:qp-=ns['mc'](arb_poly([sg*sh/a,1]))*wt
 Iq+=mom.integral(v*qp,ll,hh)
Iq*=a
moment_coefficient=(Iq+Ipsi)/mu
m_shell=arb_poly([arb(1)/(2**k*factorial(k))if k%2==0 else arb(0)for k in range(161)])
parts[None]-=m_shell*moment_coefficient
maxdegree=max(len(p)-1 for p in parts.values())
outer_mom=logmod.Moments({'zero':arb(0),'left':a,'right':b,'minus_left':-a},2*maxdegree)
normsq=2*logmod.function_product(parts,parts,outer_mom,'left','right')
assert normsq>0
# m_shell truncation: exp(b/2)*(b/2)^162/162! bounds the even Taylor tail.
mtail=(b/2).exp()*(b/2)**162/arb.fac_ui(162)
field_tail=mtail*abs(moment_coefficient).upper()
whole_norm=normsq.upper().sqrt()+(2*hs).sqrt()*field_tail
allmom=logmod.function_moments(parts,outer_mom,'left','right',95)
physleg=[res.legs[k](arb_poly([-mid/half,1/half]))*(arb(2*k+1)/(2*hs)).sqrt()for k in range(96)]
legvec=arb_mat([[2*sum((p[k]*allmom[k]for k in range(len(p))),arb(0))]for p in physleg])
outvec=J.transpose()*legvec
first=json.loads((HERE/'kernel-correction.json').read_bytes())
rows=[]
for i in range(84):
 target=c.box(first['rows'][i]['signed_corrected_minus_original_pairing'])
 testn=(J.transpose()*J)[i,i].upper().sqrt()
 full=c.pad(outvec[i,0],field_tail*(2*hs).sqrt()*testn)
 dif=full-target
 rows.append(c.encode({'coordinate':i+1,'outer_correction_pairing':full,'adjoint_correction_pairing':target,'difference':dif,'overlap':dif.contains(0)}))
 assert dif.contains(0)
wr=json.loads((WHOLE/'WHOLE_RESULT.json').read_bytes())
oldnorm=q(wr['model_X_norm_squared_upper']).sqrt()
newnorm=oldnorm+whole_norm
# This is only the numerical repair estimate under the unchanged inherited
# analytic operator/source assumptions, not an automatic reacceptance of #252.
wholedual=q('5/21').sqrt()*(newnorm+q(wr['core_quadrature_X_error_upper'])+q(wr['core_bridge_X_error_upper']))+q(wr['whole_operator_model_Ldual_error_upper'])
result={'status':'INDEPENDENT_EXTERIOR_MODEL_CORRECTION_AND_NORM_CHECK','all_84_pairing_routes_agree':True,
 'new_quadrature':False,'repository_modified':False,'complete_connection_accepted':False,
 'bounds':c.encode({'correction_X_norm_squared_polynomial_moment_model':normsq,'moment_Taylor_pointwise_error':field_tail,'correction_X_norm_upper':whole_norm,
 'old_model_X_norm_upper':oldnorm,'corrected_model_X_norm_upper_by_triangle':newnorm,'conditional_repaired_Ldual_norm_upper':wholedual,
 'conditional_repaired_Ldual_energy_upper':wholedual**2,'moment_coefficient':moment_coefficient}),
 'rows':rows,'seconds':time.monotonic()-start,
 'conditional_warning':'Inherited source, domain, projection and quadrature hypotheses not independently re-proven; updated full-source accounting and package validation still required.'}
(HERE/'correction-outer-check.json').write_text(json.dumps(result,indent=2)+'\n')
mcmod.save(HERE/'correction-function-exact.json.gz',{'core_source':CS,'direct_source':Cpsi,'core_U_correction':v,'outer_correction':parts,'a':a,'b':b,'moment_coefficient':moment_coefficient},sha(Path(__file__).read_bytes()),{'published_builder':sha((WHOLE/'whole_function_probe.py').read_bytes())})
for k,vv in result['bounds'].items():print(k,[float(F(x))for x in vv],flush=True)
print('ALL84_OUTER_ADJOINT_AGREE',time.monotonic()-start,flush=True)
