"""Bound fixed-model mean/moment diagnostic; no new quadrature."""
import sys
if not __debug__: raise SystemExit('Optimized Python is rejected.')
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,hashlib,importlib.util,json,time
from math import factorial
from flint import arb,arb_mat,arb_poly,ctx,fmpq
ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
R=args.repo.resolve();O=args.out.resolve();O.mkdir(parents=True,exist_ok=True);start=time.monotonic()
P=R/'research/x-c1/w9-gamma-repair-even-2026-10-22';W=R/'research/x-c1/w9-residual-centered-control-even-2026-10-21/whole'
for name,h in json.loads((P/'MANIFEST.json').read_bytes()).items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h,name
for name,h in json.loads((P/'INPUT_BINDINGS.json').read_bytes())['repository_files'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==h,name
def mod(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
S=R/'research/x-c1/w9-new-k-schur-underform-even-2026-10-20';eng=mod('identity_schur',S/'engine.py');spec,data=eng.snapshot(R,(S/'INPUT_BINDINGS.json').read_bytes());env=eng.load(R,spec,data);c=env['common'];e=env['energy'];q=c.q
ctx.prec=3072
cache=mod('identity_cache',W/'model_cache.py');v,bindings=cache.load(W/'whole-model-ed58da3caacd.json.gz',hashlib.sha256((W/'whole_function_probe.py').read_bytes()).hexdigest())
assert bindings=={k:hashlib.sha256(d).hexdigest()for k,d in env['inp'].data.items()}
log=mod('identity_log',W/'vendor/log_integrals.py');a,b,delta=(v[k]for k in ['a','b','delta'])
mc=arb_poly([(a/2)**k/factorial(k)if k%2==0 else arb(0)for k in range(161)])
corr=json.loads((P/'norm/inputs/GPT1-kernel-correction.json').read_bytes())
du=arb_poly([c.box(x)for x in corr['coefficients']['projected_U_correction_t']])
parts=dict(v['ustatic']);parts[None]+=du
mom=log.Moments(v['roots'],800)
def integrate(test):
 ans=a*log.function_product(parts,{None:test},mom,'zero','one')
 for cell,pp in zip(v['cells'],v['upp']):ans+=a*mom.integral(pp*test,*cell)
 return ans-sum((wh*test(x/a)for x,wh in v['hpoints']),arb(0))/delta
mean=integrate(arb_poly([1]));moment=integrate(mc)
phi_mean=-(a/2).sqrt()*sum((v['ff'][i,0]*arb(2*n+1).sqrt()*c.mellin(n,a)/c.mellin(0,a) for i,n in enumerate(range(2,384,2))),arb(0))
raw_high_mean=mean-phi_mean
candidate=json.loads((S/'CANDIDATE.json').read_bytes())['raw_coefficients']
wref=arb_mat([[q(x)]for x in candidate]);dw=c.norm(wref-v['w'])
jgram=v['J'].transpose()*v['J']
jgram_rows=[sum((abs(jgram[i,j]).upper()for j in range(jgram.ncols())),arb(0))for i in range(jgram.nrows())]
jop=max(x.upper()for x in jgram_rows).sqrt()+e.eBareJ
assert jop<q('1.001')
tail=(a/2).exp()*(a/2)**162/arb.fac_ui(162)
rho=e.w['rho'];Ki=e.w['Ki'];aa=e.w['a'];case=env['inp'].json('common')['cases'][0];raw=env['inp'].json('old_sources')['cases'][0]
UF=arb_mat([[env['U'][i,j]for j in range(12)]for i in range(12)]);UJ=arb_mat([[env['U'][i,j]for j in range(12,96)]for i in range(12,96)])
EF=2*(c.mat(case['finite_feature_error_gram'])+c.mat(raw['old_certificate']['joint_high_source_error_gram'])/delta)
EJ=2*(c.box(case['tail_feature_error_scalar'])+c.box(raw['galerkin']['high_source_error_norm'])**2/delta)
tr=c.trace;root=lambda x:x.upper().sqrt();tkG=tr(Ki*e.w['GF']);tkU=tr(Ki*UF);tkE=tr(Ki*EF);tpG=tr(e.w['GJ']);tpU=tr(UJ);tpE=84*EJ
a_error_HS=e.bounds['direct_energy_relative_error_upper']*root(tkG*tpG)+root(tkU*tpE)+root(tkE*tpU)+root(tkE*tpE)
pj=aa.transpose()*Ki*aa;pprice=10*(root(tr(pj))+a_error_HS)*dw
u8=c.box(e.bounds['U8_norm_upper']) if isinstance(e.bounds['U8_norm_upper'],list)else e.bounds['U8_norm_upper']
# Conditional whole-operator caps already present in the inherited ledger.
wprice=(q('5/21').sqrt()*(10000+10000*u8*q('1.001'))*dw+pprice)
assert wprice<q('1e-200')
high_lift=q('5/21').sqrt()*100/delta*q('1e40')*tail
assert high_lift<q('1e-200')
enc=lambda x:[str(x.lower().fmpq()),str(x.upper().fmpq())]
out={'status':'DIAGNOSTIC_MODEL_MOMENT_AND_ROUNDING','base_commit':'beb38c9d1cba666bb3b7ddab9577873e59d854c4',
 'corrected_core_mean':enc(mean),'raw_high_mean_after_subtracting_Phi_ff':enc(raw_high_mean),'corrected_core_moment_against_m160':enc(moment),'cosh160_sup_remainder':enc(tail),
 'candidate_w_midpoint_difference_norm':enc(dw),'J_X_operator_norm_upper_including_inherited_rounding':enc(jop),'conditional_whole_w_rounding_Ldual_upper':enc(wprice),
 'a_action_HS_error_included':enc(a_error_HS),'conditional_raw_high_lift_Ldual_upper':enc(high_lift),'raw_high_norm_cap_assumed':'1e40',
 'inherited_U8_norm_upper':enc(u8),'no_new_quadrature':True,'all_analytic_lemmas_reproved':False,'seconds':time.monotonic()-start}
(O/'core-moment-diagnostic.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:c.box(v).str(16)for k,v in out.items()if isinstance(v,list)},indent=2));print('SECONDS',out['seconds'])
