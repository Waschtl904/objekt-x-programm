"""Exact finite countercontrols for the accompanying general operator identities.

These fixtures are not new physical witnesses and do not certify inherited lemmas.
Requires python-flint, already used by the bound repair package.
"""
import sys
if not __debug__: raise SystemExit('Optimized Python is rejected.')
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,ast,hashlib,importlib.util,json
from flint import fmpq as Q,fmpq_mat as M
ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
R=args.repo.resolve();O=args.out.resolve();O.mkdir(parents=True,exist_ok=True)
P=R/'research/x-c1/w9-gamma-repair-even-2026-10-22';old=R/'research/x-c1/w9-residual-centered-control-even-2026-10-21/whole/whole_function_probe.py'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='ed58da3caacd5ca39de1f910c77920e7079eec905a560b487600c71e97c8df64'
spec=importlib.util.spec_from_file_location('identity_corrected_builder',P/'corrected_builder.py');adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
source=adapter.corrected_source(R);tree=ast.parse(source)
assign={ast.unparse(t):ast.unparse(n.value)for n in ast.walk(tree)if isinstance(n,ast.Assign)for t in n.targets}
expected={
 '(g, prime, *_)':'build_core(-ff, -pv, w)',
 '(gpsi, primepsi, sp, spx, lm, slocal)':'build_core(zero, pv, -(1 - eta) * w)',
 'alpha':'(intg - hmom[0]) * scale / me',
 'momentR':'hm + a * mqpsi + a * uq - hq / delta',
 'physical_mom':'[a ** (k + 1) * v - hmom[k] / delta for k, v in enumerate(um)]',
 'ustatic[None]':"ustatic.get(None, arb_poly([])) + phif - (plow + alpha * mc) * (1 / delta)",
 'outerstatic[None]':'outerstatic[None] - mc * (lm / mu)'}
for name,want in expected.items():assert assign.get(name)==want,(name,assign.get(name),want)
fn={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
ret=next(n for n in fn['outer_value'].body if isinstance(n,ast.Return))
assert ast.unparse(ret.value)=='val - res.m(x) * momentR / mu'
assert 'regular_core(ym)' in ast.unparse(fn['build_core'])
assert ast.unparse(fn['regular_out'])==ast.unparse(next(n for n in ast.parse(old.read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='regular_out'))
assert '((2, 2), (3, 3), (4, 2), (5, 5), (7, 7), (8, 2))' in assign['channels']
def eye(n):return M([[int(i==j)for j in range(n)]for i in range(n)])
def gen(n,m,s):return M([[Q((7*i+3*j+s)%11-5,7)for j in range(m)]for i in range(n)])
def col(xs):return M([[x]for x in xs])
def quad(x,A):return (x.transpose()*A*x)[0,0]
def vertical(a,b):return M([[a[i,j]for j in range(a.ncols())]for i in range(a.nrows())]+[[b[i,j]for j in range(b.ncols())]for i in range(b.nrows())])
def slice_rows(a,lo,hi):return M([[a[i,j]for j in range(a.ncols())]for i in range(lo,hi)])
records=[]
for seed in range(1,6):
 mc=col([1,Q(seed,3),Q(1,5)]);ms=col([Q(seed,7),Q(1,4),Q(-1,6)]);mu=(mc.transpose()*mc)[0,0]
 E=vertical(eye(3),M(3,3));Lam=vertical(-mc*ms.transpose()/mu,eye(3));G=eye(3)+ms*ms.transpose()/mu
 assert Lam.transpose()*Lam==G
 Pi=eye(3)-mc*mc.transpose()/mu
 A=gen(6,6,seed);A=A.transpose()*A+eye(6)
 m=vertical(mc,ms);P9=eye(6)-m*m.transpose()/(m.transpose()*m)[0,0];F=P9*gen(6,2,seed+2)
 V=gen(3,3,seed+3);U=Pi*(V.transpose()*V+eye(3))*Pi
 K=gen(2,2,seed+4);K=K.transpose()*K+eye(2);Ki=K.inv()
 f=gen(6,1,seed+5);h=Pi*E.transpose()*f;t=gen(3,1,seed+6);eta=Q(1,10+seed)
 g=Pi*E.transpose()*A*Lam;gF=Pi*E.transpose()*A*F
 a=F.transpose()*A*Lam-gF.transpose()*U*g
 v=F.transpose()*f-gF.transpose()*U*h
 H=(1-eta)*Lam.transpose()*A*Lam-g.transpose()*U*g-a.transpose()*Ki*a
 nu=Lam.transpose()*f-g.transpose()*U*h-a.transpose()*Ki*v
 direct=nu-H*t;p=Ki*(a*t-v);s=g*t-h-gF*p;u=U*s
 y=f+A*(F*p-(1-eta)*Lam*t+E*u)
 rho=slice_rows(y,3,6)-ms*(mc.transpose()*slice_rows(y,0,3))/mu
 assert rho==direct
 riesz=G.inv()*rho
 assert 2*(riesz.transpose()*G*t)[0,0]==2*(rho.transpose()*t)[0,0]
 L=Q(21,5)*G+eye(3);assert 2*quad(rho,L.inv())<=Q(5,21)*2*quad(rho,eye(3))
 assert rho!=slice_rows(y,3,6),'Missing adjoint moment correction must be detected'
 assert rho!=Lam.transpose()*(f+A*(F*p-Lam*t+E*u)),'Missing eta-q term must be detected'
 assert riesz!=rho,'X density must not be called the W_X Riesz vector'
 dp=gen(2,1,seed+7)
 def at_p(pp):return Lam.transpose()*f-(1-eta)*Lam.transpose()*A*Lam*t+Lam.transpose()*A*F*pp+g.transpose()*U*(g*t-h-gF*pp)
 assert at_p(p+dp)-at_p(p)==a.transpose()*dp
 assert at_p(p+dp)-at_p(p)!=2*a.transpose()*dp,'Duplicate p charge/difference must be detected'
 records.append({'fixture':seed,'schur_to_physical_density':True,'moment_adjoint':True,'WX_Riesz_conversion':True,'Ldual_density_bound':True,'p_telescope_once':True,'negative_controls_detected':4})
# A nonorthogonal old low/high split. The general proof is in MODELLIDENTIFIKATION.txt.
old_records=[]
for seed in range(1,6):
 m=col([2,Q(seed,5),Q(1,7),Q(1,11),Q(-1,13)]);e0=col([1,0,0,0,0]);I=eye(5)
 Elow=M([[int(i==j+1)for j in range(2)]for i in range(5)]);Ehigh=M([[int(i==j+3)for j in range(2)]for i in range(5)])
 Phi=Elow-e0*(m.transpose()*Elow)/m[0,0];Th=Ehigh-e0*(m.transpose()*Ehigh)/m[0,0]
 A=gen(5,5,seed);A=A.transpose()*A+eye(5);B=Phi.transpose()*A*Th
 C=gen(2,2,seed+2)+eye(2);delta=Q(3,2);rho=Q(1,100);X=C*C.transpose()/(1-rho)
 Z=Phi-Th*B.transpose()/delta;U=Th*Th.transpose()/delta+Z*X*Z.transpose();s=gen(5,1,seed+8)
 ff=X*(Phi.transpose()*s-B*Th.transpose()*s/delta);z=s-A*Phi*ff
 alpha=(e0.transpose()*z)[0,0]/m[0,0]
 high=z-m*alpha-Elow*(Phi.transpose()*z)
 assert high==Ehigh*(Th.transpose()*z)
 u=Phi*ff+Th*(Ehigh.transpose()*high)/delta
 assert u==U*s
 assert (m.transpose()*u)[0,0]==0
 wrong_alpha=(m.transpose()*z)[0,0]/(m.transpose()*m)[0,0]
 wrong=z-m*wrong_alpha-Elow*(Phi.transpose()*z)
 assert wrong!=high,'Orthogonal and oblique projection must be distinguished'
 assert Phi*ff+high/delta!=u,'Raw high field needs the moment lift in the exact model'
 old_records.append({'fixture':seed,'U8_factorization_identity':True,'oblique_alpha_and_low_projection':True,'exact_high_moment_lift':True,'negative_controls_detected':2})
result={'status':'EXACT_ALGEBRA_AND_BOUND_SOURCE_MAP_PASS_CONDITIONAL','repository_base':'beb38c9d1cba666bb3b7ddab9577873e59d854c4',
 'original_builder_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'corrected_source_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'bound_source_equations':expected,'prime_channels':[[2,2],[3,3],[4,2],[5,5],[7,7],[8,2]],'schur_fixtures':records,'old_U8_fixtures':old_records,
 'physical_research_witnesses_added':0,'finite_fixtures_replace_general_proof':False,'all_inherited_analytic_lemmas_reproved':False,'complete_numerical_error_allocation_accepted':False,'external_acceptance':False}
(O/'model-identity-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: bound source map, 5 Schur/W_X fixtures, 5 nonorthogonal U8 fixtures, 30 failing-mutation controls. Analytic total acceptance remains open.')
