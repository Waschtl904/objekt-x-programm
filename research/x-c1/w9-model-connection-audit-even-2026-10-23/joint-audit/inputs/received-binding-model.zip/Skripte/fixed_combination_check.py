"""Analytic 191-coordinate core-source check for the actual frozen combination.

No new physical direction and no function quadrature. All inherited bounds remain conditional.
"""
import sys
if not __debug__:raise SystemExit('Optimized Python is rejected.')
sys.dont_write_bytecode=True
from pathlib import Path
from math import factorial
import argparse,hashlib,importlib.util,json,time
from flint import arb,arb_mat,arb_poly,ctx
ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
R=args.repo.resolve();O=args.out.resolve();O.mkdir(parents=True,exist_ok=True);start=time.monotonic()
P=R/'research/x-c1/w9-gamma-repair-even-2026-10-22';W=R/'research/x-c1/w9-residual-centered-control-even-2026-10-21/whole'
for name,h in json.loads((P/'MANIFEST.json').read_bytes()).items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h,name
for name,h in json.loads((P/'INPUT_BINDINGS.json').read_bytes())['repository_files'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==h,name
def mod(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
S=R/'research/x-c1/w9-new-k-schur-underform-even-2026-10-20';eng=mod('fixed_combo_schur',S/'engine.py');spec,data=eng.snapshot(R,(S/'INPUT_BINDINGS.json').read_bytes());env=eng.load(R,spec,data);c=env['common'];e=env['energy'];q=c.q
ctx.prec=3072
cache=mod('fixed_combo_cache',W/'model_cache.py');v,bindings=cache.load(W/'whole-model-ed58da3caacd.json.gz',hashlib.sha256((W/'whole_function_probe.py').read_bytes()).hexdigest());assert bindings=={k:hashlib.sha256(d).hexdigest()for k,d in env['inp'].data.items()}
part=R/'research/x-c1/w9-partial-energy-2026-10-18';resmod=mod('fixed_combo_residuals',part/'residuals.py');of=mod('fixed_combo_old',part/'old_fields.py');res=resmod.Residuals(env['inp'],'even')
adapter=mod('fixed_combo_builder',P/'corrected_builder.py');source=adapter.corrected_source(R);code=source[source.index('gamma=of.gamma_coefficients'):source.index('\ng,prime,*_=')]
ns={'arb':arb,'arb_poly':arb_poly,'arb_mat':arb_mat,'factorial':factorial,'q':q,'c':c,'res':res,'of':of,'leg':res.legs,'old':env['inp'].json('a8_model')};ns.update(v);exec(compile(code,'bound_corrected_core_builder','exec'),ns)
g,prime,*_=ns['build_core'](-v['ff'],-v['pv'],v['w']);primes=[prime(lo,hi)for lo,hi in zip(v['edges'][:-1],v['edges'][1:])]
log=mod('fixed_combo_log',W/'vendor/log_integrals.py');degree=max(len(p)-1 for p in list(g.values())+primes);mom=log.Moments(v['roots'],degree+382)
ms=log.function_moments(g,mom,'zero','one',382)
for cell,pp in zip(v['cells'],primes):ms=[x+y for x,y in zip(ms,mom.polynomial_moments(pp,*cell,382))]
raw=env['inp'].json('old_sources')['cases'][0];old=env['inp'].json('a8_model');Am=arb_mat([[q(x[0]).union(q(x[1]))/10**100 for x in row]for row in old['parities']['even']['A']])
reference=c.mat(raw['galerkin']['old_low_c_model'])*v['w']-c.mat(raw['old_certificate']['source_c_model'])*v['pv']-Am*v['ff']
enc=lambda x:[str(x.lower().fmpq()),str(x.upper().fmpq())]
diff=[];rows=[]
for i,p in enumerate(ns['phi']):
 actual=2*v['a']*sum((p[k]*ms[k]for k in range(len(p))),arb(0));d=actual-reference[i,0];diff.append(d)
 rows.append({'coordinate':i+1,'actual_corrected_model':enc(actual),'bound_reference_model':enc(reference[i,0]),'difference':enc(d)})
dn=sum((abs(d).upper()**2 for d in diff),arb(0)).sqrt()
bound=e.eLJ*c.norm(v['w'])+eng.quad(e.ELF,v['pv']).upper().sqrt()+e.eLowA*c.norm(v['ff'])
out={'status':'FIXED_COMBINATION_LOW_SOURCE_CHECK_PASS_CONDITIONAL'if dn<bound else'UNRESOLVED_LOW_SOURCE_BOUND',
 'base_commit':'beb38c9d1cba666bb3b7ddab9577873e59d854c4','combination':'Q0(Jw-Fp0-Phi f0)','rows':rows,
 'full_coordinate_difference_norm_upper':enc(dn),'inherited_low_source_error_cap':enc(bound),'strictly_inside_bound':bool(dn<bound),
 'h_source_reintegrated':False,'new_physical_direction':False,'all_analytic_lemmas_reproved':False,'seconds':time.monotonic()-start}
(O/'fixed-combination-source-check.json').write_text(json.dumps(out,indent=2)+'\n')
print('STATUS',out['status'],'NORM',dn.str(16),'CAP',bound.str(16),'SECONDS',out['seconds'],flush=True)
if not dn<bound:raise SystemExit(2)
