"""Read-only extra controls for PR254 dd644c65; not whole model acceptance."""
import sys
if not __debug__:
    raise SystemExit('Assertions must be enabled; -O/-OO is rejected.')
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as Q
from math import comb, factorial
import argparse, ast, gzip, hashlib, importlib.util, json

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--out',type=Path,required=True)
args=ap.parse_args()
R=args.repo.resolve();O=args.out.resolve()
P=R/'research/x-c1/w9-gamma-repair-even-2026-10-22'
assert not O.is_relative_to(P),'Write the review outside the bound package'
O.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'MANIFEST.json')=='ce44e7b00cef7c77a19c732ce0eb58b7e137bcb45a9afd85c82e02349f5f3edf'
manifest=json.loads((P/'MANIFEST.json').read_bytes())
for name,want in manifest.items():assert sha(P/name)==want,name
old=json.loads((P/'INPUT_BINDINGS.json').read_bytes())['repository_files']
for name,want in old.items():assert sha(R/name)==want,name

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m
from flint import arb,arb_poly,ctx,fmpq
ctx.prec=3072
def q(v):
    v=Q(v);return arb(fmpq(v.numerator,v.denominator))
def enc(v):return [str(v.lower().fmpq()),str(v.upper().fmpq())]

# Execute the actual helper emitted by corrected_builder, with the original
# convolution layout. Reference coefficients are integrated directly for f=1
# on [1,2]. This does not execute or certify the full residual model.
adapter=module('pr254_corrected_builder',P/'corrected_builder.py')
source=adapter.corrected_source(R)
tree=ast.parse(source)
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
oldtree=ast.parse((R/adapter.OLD).read_text(encoding='utf-8'))
oldout=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef)and n.name=='regular_out')
assert ast.dump(oldout)==ast.dump(functions['regular_out'])
assert sum(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='regular_core'
           for n in ast.walk(functions['build_core']))==1
ns={'arb':arb,'arb_poly':arb_poly,'fac':[arb(factorial(k))for k in range(600)]}
exec(compile(ast.Module(body=[functions['regular_out'],functions['regular_core']],type_ignores=[]),
             'bound_PR254_kernel_helpers','exec'),ns)
mom=[Q(2**(k+1)-1,k+1)for k in range(225)]
cases=[{}, {1:Q(-1,24)}, {2:Q(1,12)}, {0:Q(3,7),1:Q(-1,24),4:Q(1,30),7:Q(-1,101)}, {224:Q(1,97)}]
rows=[]
for case in cases:
    ns['convker']=arb_poly([q(case.get(k,0))*ns['fac'][k]/2**k for k in range(224,-1,-1)])
    polys={name:ns[name]([q(v)for v in mom])for name in ['regular_core','regular_out']}
    for name,pol in polys.items():
        for ell in range(225):
            expected=sum((gj*Q(comb(j,ell),2**j)*mom[j-ell]*
                          (1+(-1)**(ell if name=='regular_core'else j-ell))
                          for j,gj in case.items()if j>=ell),Q(0))
            assert pol[ell].contains(fmpq(expected.numerator,expected.denominator)),(case,name,ell)
            assert pol[ell].rad()<q('1e-180'),(case,name,ell,'wide enclosure')
    if case=={1:Q(-1,24)}:
        assert polys['regular_core'](q('1/2')).contains(fmpq(-1,16))
        assert polys['regular_out'](q('1/2')).contains(fmpq(-1,48))
    rows.append({'nonzero_gamma_indices':list(case),'inner_and_outer_coefficients_checked':450})

# A second whole norm route uses the existing, hash-bound logarithmic-product
# primitives. The standard PR replay uses smooth log expansions instead.
DATA=P/'norm/inputs'
cache=module('pr254_model_cache',DATA/'model_cache.py')
logpath=R/'research/x-c1/w9-residual-centered-control-even-2026-10-21/whole/vendor/log_integrals.py'
assert sha(logpath)=='de20f48cc0858a9d7468f32b2f7f69471762618f2b392c71d62c487660bd9811'
log=module('pr254_log_integrals',logpath)
path=DATA/'GPT1-correction.json.gz';payload=json.loads(gzip.decompress(path.read_bytes()))
v=cache.load(path,payload['source_sha256'])[0]
a,b=v['a'],v['b'];parts=v['outer_correction']
degree=max(len(pol)-1 for pol in parts.values())
moments=log.Moments({'zero':arb(0),'left':a,'right':b,'minus_left':-a},2*degree)
norm2=2*log.function_product(parts,parts,moments,'left','right')
assert norm2>0
tail=(2*(b-a)).sqrt()*(b/2).exp()*(b/2)**162/arb.fac_ui(162)*abs(v['moment_coefficient']).upper()
upper=norm2.upper().sqrt()+tail
assert upper<q('3.653e-7')
reference=json.loads((P/'norm/independent-norm.json').read_bytes())
lo,hi=map(q,reference['correction_X_norm_interval'])
assert lo<=upper and norm2.lower().sqrt()-tail<=hi
result={'status':'SUPPLEMENTAL_NUMERICAL_CONTROLS_PASS_CONDITIONAL',
        'commit':'dd644c65f6e10184dea7b64370774e7a40814e89',
        'package_manifest_sha256':sha(P/'MANIFEST.json'),
        'executed_corrected_builder_helper_cases':rows,
        'outer_helper_unchanged':True,'inner_helper_call_in_build_core':1,
        'second_whole_norm_method':'Bound log-product primitives, same Arb library; no new quadrature.',
        'norm_squared':enc(norm2),'moment_tail_X':enc(tail),'correction_X_norm_upper':enc(upper),
        'complete_model_identification_accepted':False,'external_acceptance':False}
(O/'supplemental-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('PASS: actual emitted kernel helper: 5 cases / 2250 coefficients; second whole norm <3.653e-7.')
print('Full model identification and external acceptance remain OPEN.')
