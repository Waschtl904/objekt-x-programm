"""Check this distribution and its rational exported endpoints; no integrations.

Run in an unpacked distribution. Optional --repo checks the pinned Git inputs.
This does not reprove analytic assumptions or recreate historical integrals.
"""
import argparse, hashlib, json
from fractions import Fraction as Q
from pathlib import Path

def require(ok, message):
    if not ok:
        raise SystemExit('CHECK FAILED: '+message)

ap=argparse.ArgumentParser()
ap.add_argument('--repo',type=Path)
args=ap.parse_args()
root=Path(__file__).resolve().parent
read=lambda name:json.loads((root/name).read_bytes())
manifest=read('SHA256SUMS.json')
for name,want in manifest.items():
    require(hashlib.sha256((root/name).read_bytes()).hexdigest()==want,name)
actual={p.relative_to(root).as_posix()for p in root.rglob('*')if p.is_file()and p!=root/'SHA256SUMS.json'}
require(actual==set(manifest),'distribution inventory')

rows=read('Ergebnisse/fixed-combination-source-check.json')
require(len(rows['rows'])==191,'191 source coordinates')
sum_sq=Q(0)
for row in rows['rows']:
    a,b=map(Q,row['actual_corrected_model'])
    c,d=map(Q,row['bound_reference_model'])
    lo,hi=map(Q,row['difference'])
    require(lo<=a-d and b-c<=hi,'complete difference interval')
    sum_sq+=max(abs(lo),abs(hi))**2
norm_upper=Q(rows['full_coordinate_difference_norm_upper'][1])
cap_lower=Q(rows['inherited_low_source_error_cap'][0])
require(sum_sq<=norm_upper**2,'whole 191-coordinate norm enclosure')
require(norm_upper<Q('1.032e-30')<cap_lower,'strict source comparison')

diag=read('Ergebnisse/core-moment-diagnostic.json')
for key,bound in [
    ('cosh160_sup_remainder','1.288e-335'),
    ('candidate_w_midpoint_difference_norm','4.064e-309'),
    ('conditional_whole_w_rounding_Ldual_upper','3.103e-279'),
    ('conditional_raw_high_lift_Ldual_upper','3.448e-294'),
    ('J_X_operator_norm_upper_including_inherited_rounding','1.001')]:
    require(Q(diag[key][1])<Q(bound),key)
require(Q(diag['cosh160_sup_remainder'][0])>0,'nonzero cosh remainder retained')
require(Q(diag['corrected_core_moment_against_m160'][0])>0,'diagnostic model moment is nonzero')

replay=read('Ergebnisse/isolated-replay.json')
require(replay['inherited_files']==568,'568 inherited inputs')
require(replay['new_panels_recomputed']==16,'16 panel replay')
require(replay['whole_arithmetic_hulls_inside_errors']==84,'84 interval hulls')
require(replay['complete_model_identification_accepted']is False,'scope retained')
ident=read('Ergebnisse/model-identity-audit.json')
require(sum(x['negative_controls_detected']for key in ['schur_fixtures','old_U8_fixtures']for x in ident[key])==30,'30 algebraic controls')
require(read('Ergebnisse/supplemental-result.json')==read('GPT2/Zusaetzliche-Kern-und-Normpruefung.json'),'fresh GPT2 replay matches mathematical output')
if args.repo:
    for name,item in read('SOURCE_BINDINGS.json')['repository_files'].items():
        data=(args.repo/name).read_bytes()
        require(hashlib.sha256(data).hexdigest()==item['sha256'],'source '+name)
        blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        require(blob==item['git_blob_sha1'],'Git blob '+name)
print('PASS: distribution hashes, 191 full difference intervals and norm, conditional tiny remainders, replay receipts and scope. Analytic total acceptance remains open.')
