"""Check delivered hashes, exact rational bounds and both full replay receipts.

Standard library only. Does not recreate analytic integrals or accept open lemmas.
"""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib,zipfile
R=Path(__file__).resolve().parent
def need(ok,message):
    if not ok:raise SystemExit('FAIL: '+message)
def read(p):return json.loads((R/p).read_bytes())
manifest=read('SHA256SUMS.json')
actual={p.relative_to(R).as_posix()for p in R.rglob('*')if p.is_file()and p!=R/'SHA256SUMS.json'}
need(set(manifest)==actual,'complete inventory')
for name,h in manifest.items():need(hashlib.sha256((R/name).read_bytes()).hexdigest()==h,name)
incoming=R/'Eingang/Objekt-X-Modellanschluss-2026-10-22.zip'
need(hashlib.sha256(incoming.read_bytes()).hexdigest()=='ce07cb163ea1d9e6591e64105d5ba67386e8f3aa4c785bbcb7dedba43e655657','unchanged original ZIP')
with zipfile.ZipFile(incoming)as z:
    im=json.loads(z.read('MANIFEST.json'))
    for p,h in im.items():need(hashlib.sha256(z.read(p)).hexdigest()==h,'incoming '+p)
    original=json.loads(z.read('evidence/component-rebuild.json'))
for name in ['component-rebuild.json','rounding-result.json','audit-result.json']:
    a=read('Belege/Seed0/'+name);b=read('Belege/Seed1/'+name)
    for x in [a,b]:x.pop('seconds',None);x.pop('component_rebuild_sha256',None)
    need(a==b,'all deterministic fields: '+name)
c=read('Belege/Seed1/component-rebuild.json')
need(c['old_cache_exact_reproduction_pass'],'exact old reconstruction')
need(c['bounds']['shared_whole_correction_identification_X']==original['bounds']['shared_whole_correction_identification_X'],'same whole correction')
need(Q(c['bounds']['shared_whole_correction_identification_X'][1])<Q('6.648e-313'),'whole correction cap')
r=read('Belege/Seed1/rounding-result.json')
need(Q(r['bounds']['rounding_Ldual_price'][1])<Q('6.198e-279'),'rounding cap')
need(Q(r['bounds']['total_allowance_X_equivalent'][1])<Q('4.243e-237')<Q('1e-150'),'joint allocation')
need(len(read('Belege/strict-replay-differences.json'))==4,'original failure retained')
op=read('Belege/operator-lemmas.json')
for name,cap in [('cross_operator','9.023'),('Q8_m_norm','23.401'),('raw_g_X_operator','13.066'),('degree95_whole_Q','192'),('degree8_global_Q','49'),('oblique_projection_operator_norm','1.001'),('conditional_explicit_moment_amplification','2.003e22'),('conditional_moment_transport_X','8.493e-257')]:
    need(Q(op['values'][name][1])<Q(cap),name)
P=op['endpoint_square_polynomial_ascending'];need([P[k]-(k+1)*P[k+1]if k<4 else P[k]for k in range(5)]==[1,0,2,0,1],'endpoint identity')
rev=R/'Vorbereitete-Revision'
for name,h in json.loads((rev/'MANIFEST.json').read_bytes()).items():need(hashlib.sha256((rev/name).read_bytes()).hexdigest()==h,'revision '+name)
need(op['inherited_source_contour_and_domain_lemmas_all_accepted']is False,'analytic scope retained')
print('PASS: hashes, exact bounds, two deterministic full replays, retained original failure and conditional scope.')
