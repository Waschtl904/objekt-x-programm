"""Directed elementary constants for the accompanying operator-lemma audit.

No stored numeric caps are loaded. The physical Q representation remains the
stated input. This does not certify the inherited source or contour lemmas.
"""
import sys
if not __debug__:raise SystemExit('Do not use -O/-OO.')
from pathlib import Path
from fractions import Fraction
from math import factorial
import argparse,json
from flint import arb,ctx
ctx.prec=1024
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
q=lambda s:arb(str(s))
a=3*arb(2).log()/2;b=arb(3).log();s=b-a;mu=(a+a.sinh())/2
channels=[(2,2),(3,3),(4,2),(5,5),(7,7),(8,2)]
prime=2*sum((arb(p).log()/arb(n).sqrt()for n,p in channels),arb(0))
# Gamma(z)=(sech(z)+csch(z)-1/z)/4. For 0<=z<=Z,
# |sinh(z)-z|<=z^3 cosh(Z)/6 and sinh(z)>=z.
Z=q('1.1');gamma_real=(1+Z*Z.cosh()/6)/4
assert gamma_real<q('0.327')
# Retain the existing coarse constant 2; no improved energy claim is made.
reg=q(2)
cross=arb.pi()/2+(s/a).sqrt()/2+2*reg*(a*s).sqrt()+prime
mn=(2*a).sqrt()*(a/2).cosh()
cv=abs(-(2*arb.pi()).log()-arb.const_euler()-a.log()).upper()
qm=(2*a).sqrt()*a*(a/2).sinh()/2+mn*(cv+arb(2).sqrt()/2+arb(2).log()/2+2*a*reg+prime)
lambdaop=((s+b.sinh()-a.sinh())/4).sqrt()
graw=cross+lambdaop*qm/mu
assert cross<q('9.023')and qm<q('23.401')and graw<q('13.066')<100
v0=-(2*arb.pi()).log()-arb.const_euler()-s.log()
H95=sum((arb(1)/n for n in range(1,96)),arb(0))
core=cross+100*lambdaop/mu
shell=H95+96*(abs(v0).upper()+arb(2).sqrt())+s/(2*a)+2*reg*s+prime+cross*(2*mu).sqrt()*lambdaop/mu
q95=(core**2+shell**2).sqrt()
assert q95<192
cvb=abs(-(2*arb.pi()).log()-arb.const_euler()-b.log()).upper()
q8global=sum((arb(1)/n for n in range(1,9)),arb(0))+9*(cvb+arb(2).sqrt())+2*b*reg+prime
assert q8global<100
Qpsi_cap=192*(16*q('1e7')+4)+100*4*q('1e7')
assert Qpsi_cap<q('1e15')
# Moment projector on the whole raw kernel, including low leakage.
Mnorm=(2*mu).sqrt()*(2*a).sqrt()/(4*(a/2).sinh())
assert Mnorm<q('1.01')
Mnorm_b=(b+b.sinh()).sqrt()*(2*b).sqrt()/(4*(b/2).sinh())
assert Mnorm_b<q('1.01')
# Exact cosh-tail bounds. The scaling U makes the constant unit-norm.
high_tail=arb(2)/arb(factorial(384))
E=arb(2*10**6)/arb(factorial(160))
for j in (0,1,2):
    real_tail=(a/2).exp()*(a/2)**(162-j)/(2**j*arb(factorial(162-j)))
    assert real_tail<E
postM_X=100*high_tail*q('1e21')
assert postM_X<q('9.899e-805')
log_core_integral=2*(4+a*(1+a.log()**2))
assert log_core_integral<16
assert a.log()+a.log()**2/2<1
# Exact identity P(t)-P'(t)=(1+t^2)^2 for the integrated endpoint envelope.
P=[29,28,14,4,1]
assert [P[k]-(k+1)*P[k+1]if k<4 else P[k]for k in range(5)]==[1,0,2,0,1]
# Conditional, explicit moment-amplification budget at the CONTINUOUS model
# stage, before the independent h-Gauss replacement. See proof for each term.
Qe_cap=(2*a).sqrt()*(a+cv+arb(2).sqrt()/2+arb(2).log()/2+2*a*reg+prime)
assert Qe_cap<100
alpha_cap=q('1e17');lm_cap=q(2);u_cap=q('1e20')
delta_u_factor=lm_cap*100+4*lm_cap*100+2*alpha_cap
# |Lambda*| <=2; raw outer transport <=100; the separate moment functional
# mismatch is bounded by lambdaop/mu * ||u0|| * ||Q e||.
moment_amplification=100*delta_u_factor+2*lm_cap*100+2*u_cap*100+4*q('1e15')
assert moment_amplification<q('1e25')<q('1e40')
enc=lambda x:[str(x.lower().fmpq()),str(x.upper().fmpq())]
values=dict(a=a,b=b,mu=mu,prime_translation_sum=prime,Gamma_real_upper=gamma_real,
    cross_operator=cross,Q8_m_norm=qm,raw_g_X_operator=graw,degree95_whole_Q=q95,degree8_global_Q=q8global,
    conditional_Qpsi_whole_norm=Qpsi_cap,
    oblique_projection_operator_norm=Mnorm,moment_error_Q8_factor=Qe_cap,
    cosh_high_tail=high_tail,post_M_outer_X=postM_X,moment160_C2_envelope=E,logarithmic_core_square_integral=log_core_integral,
    conditional_explicit_moment_amplification=moment_amplification,
    conditional_moment_transport_X=E*moment_amplification)
out={'status':'ELEMENTARY_OPERATOR_AND_PROJECTION_LEMMAS_CHECKED',
 'scope':'fixed even geometry; stated physical Q representation',
 'endpoint_square_polynomial_ascending':P,
 'Gauss_error_lemma':'8 * interval_length * contour_sup * 2**(-2*n), assuming analyticity inside the Bernstein ellipse of parameter 2',
 'values':{k:enc(v)for k,v in values.items()},
 'conditional_moment_inputs':{'continuous_corrected_model_norm':'1e20','alpha_abs':'1e17','both_shell_moments_abs':'2','Qpsi_model_whole_norm':'1e15','frozen_Y_HS_norm':'16','p_norm':'1e7','Jw_X_norm':'4'},
 'inherited_source_contour_and_domain_lemmas_all_accepted':False,
 'whole_program_or_second_direction_promotion':False}
args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v.str(14)for k,v in values.items()},indent=2))
