"""Isolate unordered summation using the unchanged exact archived cache."""
import sys
if not __debug__:raise SystemExit('Do not use optimized Python.')
from pathlib import Path
import argparse,importlib.util,json,hashlib,itertools
from flint import arb,arb_poly,ctx
ctx.prec=3072
ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--fresh',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
W=args.repo/'research/x-c1/w9-residual-centered-control-even-2026-10-21/whole'
sys.path.insert(0,str(W));sys.path.insert(0,str(args.input/'scripts'))
import exact_cache
v,_=exact_cache.load(W/'whole-model-ed58da3caacd.json.gz',hashlib.sha256((W/'whole_function_probe.py').read_bytes()).hexdigest())
parts=v['outerstatic'];terms={}
for tag,p in parts.items():
    factor=(2*v['a']).sqrt()if tag is None else (4*v['a']).sqrt()if tag=='one'else (2*v['a']).sqrt()*max(abs(abs(v['rootvalues'][tag]).log()).upper(),abs(abs(1-v['rootvalues'][tag]).log()).upper())
    poly=p-p
    bound=sum((abs(x).upper()for x in poly),arb(0)).upper()
    terms[tag]=bound*factor
key='old_cache_outerstatic_X'
expected=json.loads((args.input/'evidence/component-rebuild.json').read_bytes())['bounds'][key]
fresh=json.loads((args.fresh/'component-rebuild.json').read_bytes())['bounds'][key]
enc=lambda x:[str(x.lower().fmpq()),str(x.upper().fmpq())]
orders=[];seen=set()
for perm in itertools.permutations(terms):
    s=arb(0)
    for k in perm:s+=terms[k]
    value=enc(s.upper());seen.add(tuple(value))
    if value in [expected,fresh]:orders.append({'order':list(perm),'matches_expected':value==expected,'matches_fresh':value==fresh})
assert any(x['matches_expected']for x in orders)and any(x['matches_fresh']for x in orders)
canonical=sorted(terms,key=lambda k:(k is not None,''if k is None else k))
s=arb(0)
for k in canonical:s+=terms[k]
out={'status':'UNORDERED_SUM_EXPLAINS_ARCHIVED_DIAGNOSTIC_DIFFERENCE','terms':len(terms),'distinct_directed_results':len(seen),'matching_orders':orders,'canonical_order':canonical,'canonical_value':enc(s.upper()),'underlying_cached_intervals_changed':False,'tolerance_relaxed':False}
norm=lambda mat:sum((abs(mat[i,j]).upper()**2 for i in range(mat.nrows())for j in range(mat.ncols())),arb(0)).sqrt()
Ynorm=norm(v['Y']);pnorm=norm(v['pv']);wnorm=norm(v['w']);jwnorm=norm(v['J']*v['w'])
assert Ynorm<16 and pnorm<arb('1e7')and wnorm<2 and jwnorm<4 and abs(v['lm'])<1
out['fixed_model_ingredients']={k:enc(x)for k,x in dict(Y_HS_norm=Ynorm,p_norm=pnorm,w_norm=wnorm,Jw_X_norm=jwnorm,shell_moment=abs(v['lm'])).items()}
args.out.write_text(json.dumps(out,indent=2)+'\n')
print('PASS: both exact endpoint versions reproduced by summing the same',len(terms),'terms in different orders; distinct results:',len(seen))
