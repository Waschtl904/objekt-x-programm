"""Small exact controls for the targeted L1 review; no integrations.

Uses only the Python standard library. Run from any directory.
These controls do NOT replay the new local L1/R2 author package.
"""
import argparse
import hashlib
import json
from fractions import Fraction as Q
from math import comb, factorial
from pathlib import Path


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--inputs", type=Path, default=Path(__file__).parent / "inputs")
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    p = args.inputs
    count = 0
    for n in range(225):
        for k in range(n + 1):
            direct = Q(comb(n, k) * (1 + (-1) ** k), 2 ** n)
            convolution = Q(factorial(n) * (1 + (-1) ** k),
                            2 ** n * factorial(n-k) * factorial(k))
            need(direct == convolution, "Inner Gamma coefficient identity")
            count += 1
    correct = Q(1 + (-1) ** 0, 2)
    wrong = Q(1 + (-1) ** 1, 2)
    need(correct != wrong, "Wrong-orientation control")

    matrix = ((Q(3), Q(1)), (Q(1), Q(2)))
    u0, du = (Q(2), Q(-1)), (Q(1, 3), Q(2, 5))
    m0, d = (Q(1), Q(4)), (Q(-2, 7), Q(1, 2))
    def add(a, b):
        return tuple(x + y for x, y in zip(a, b))
    def pair(a, b):
        return sum(a[i] * matrix[i][j] * b[j]
                   for i in range(2) for j in range(2))
    lhs = pair(add(u0, du), add(m0, d)) - pair(u0, m0)
    rhs = pair(du, add(m0, d)) + pair(u0, d)
    linearized = pair(du, m0) + pair(u0, d)
    need(lhs == rhs, "Bilinear regrouping")
    need(lhs != linearized, "Omitted mixed term must fail")

    # Conservative, already published whole-function bounds from SOURCE-CAPS
    # sections 1, 4, 5. No claim to reproduce the new tighter local source caps.
    lam1 = lam2 = Q(2)
    alpha, unorm, qpsi = Q(10**18), Q(10**20), Q(10**15)
    eps = Q(2, factorial(160))
    moment_x = eps * (100 * (300*lam1 + 2*alpha + 2*lam2)
                      + 2*qpsi + 100*unorm + 24*lam2)
    old = read(p / "reconciliation-result.json")
    cache = read(p / "cache-price.json")
    energy = read(p / "rational-cross-audit.json")
    delta = Q(old["delta"])
    moment_raw = moment_x * delta / 100
    joint_raw = moment_raw
    kept_rows = ["canonical_w_and_directional_rebase",
                 "exact_high_moment_lift", "whole_correction_source_bridge"]
    for name in kept_rows:
        joint_raw += Q(old["identified_remainder_rows"][name]
                       ["raw_source_equivalent_upper"])
    joint_raw += Q(cache["complete_difference_X_upper"]) * delta / 100
    need(moment_x < Q("1e-262"), "Conservative R2 X bound")
    need(joint_raw < Q("1e-264") < Q("1e-150"), "Five-family allocation")
    energy_upper = Q(energy["repaired_Ldual_energy_upper"])
    need(energy_upper < Q("4.632e-11"), "Stored energy endpoint")
    received_t = read(p / "received-T-endpoints.json")
    original_prices = read(p / "historical-energy-errors.json")
    functions = read(p / "FUNCTIONS12.json")["parities"]["even"]["functions"]
    d_columns = []
    for function in functions:
        part = function["D"]
        cap = sum(abs(Q(v)) for v in part["polynomial"])
        cap += 2 * sum(abs(Q(v)) for v in part["V_multiplier"])
        cap += 2 * abs(Q(part["moment_multiplier"]))  # sqrt(3) < 2
        for shift in part["shift_terms"]:
            cap += sum(abs(Q(v)) for v in shift["polynomial"])
        d_columns.append(cap)
    dnorm_cap = sum(d_columns)  # l1 >= l2 of nonnegative column caps
    t_price = dnorm_cap * Q(received_t["fresh_distance_upper"])
    need(Q(received_t["fresh_distance_upper"]) < Q(received_t["old_distance_lower"]),
         "Fresh T norm endpoint below old norm endpoint")
    need(t_price < Q(original_prices["errors"]["frozen_T_Hilbert"][0]),
         "Whole new T price below original published lower endpoint")
    r15 = read(p / "received-R15-summary.json")
    historical_manifest = read(p / "historical-MANIFEST.json")
    historical_bindings = read(p / "INPUT_BINDINGS.json")
    need(r15["cache_sha256"] == historical_manifest[
        "whole/whole-model-ed58da3caacd.json.gz"], "R15 cache binding")
    for alias in ("frozen_Y_even", "frozen_J_even"):
        need(r15["reference_input_sha256"][alias] ==
             historical_bindings["members"][alias]["sha256"], "R15 reference binding")
    need(r15["entries_compared"] == 96*(8+84), "R15 dimensions/count")
    need(all(v == 0 for v in r15["different_entries"].values()), "Reported R15 equality")
    need(all(Q(v) == 0 for v in r15["coordinate_difference_HS"].values()),
         "Reported R15 norm zero")
    out = {
        "scope": "FORMAL_IDENTITIES_AND_CONSERVATIVE_ALLOCATION_ONLY",
        "formal_kernel_weight_identities": count,
        "wrong_orientation_counterexample": {
            "n": 1, "k": 0, "correct": str(correct), "wrong": str(wrong)},
        "bilinear_identity_pass": lhs == rhs,
        "omitted_cross_term_rejected": lhs != linearized,
        "nonzero_mixed_term": str(lhs - linearized),
        "R2_coarse_X_upper": str(moment_x),
        "R2_coarse_raw_upper": str(moment_raw),
        "joint_raw_upper": str(joint_raw),
        "joint_raw_less_1e_264": True,
        "retained_raw_allowance": "1e-150",
        "retained_rows": kept_rows,
        "cache_difference_included": True,
        "replaced_row": "inherited_moment_derivative_envelope_other_stages",
        "stored_energy_endpoint_less_4_632e_11": True,
        "new_energy_reconstruction": False,
        "new_T_endpoint_and_absolute_price_checks_pass": True,
        "new_T_matrix_Arb_build_replayed": False,
        "Dnorm_coarse_l1_upper": str(dnorm_cap),
        "new_T_absolute_price_upper": str(t_price),
        "R15_exact_cache_comparison_reproduced": False,
        "R15_reported_input_hashes_match_historical_bindings": True,
        "R15_checker_reviewed_against_published_cache_encoding": True,
        "new_tight_R2_endpoints_reproduced": False,
        "new_30_source_manifest_verified": False,
        "inputs_sha256": {name: hashlib.sha256((p / name).read_bytes()).hexdigest()
                           for name in ("reconciliation-result.json", "cache-price.json",
                                        "rational-cross-audit.json", "SOURCE-CAPS.txt",
                                        "received-T-endpoints.json", "historical-energy-errors.json",
                                        "FUNCTIONS12.json", "received-R15-summary.json",
                                        "historical-MANIFEST.json", "INPUT_BINDINGS.json")},
    }
    if args.output:
        args.output.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print("PASS: 25,425 formal identities; mixed-term negative control; "
          "conservative five-family raw allocation <1e-264 <1e-150.")
    print("PASS: received new T endpoint times independently bounded D norm "
          "is below the original published T price.")
    print("PASS: R15 reported source hashes match historical bindings. "
          "The 8,832-entry comparison itself was reviewed, not reexecuted.")
    print("No new L1 package, fresh T matrix construction, R15 or full energy replay claimed.")


if __name__ == "__main__":
    main()
