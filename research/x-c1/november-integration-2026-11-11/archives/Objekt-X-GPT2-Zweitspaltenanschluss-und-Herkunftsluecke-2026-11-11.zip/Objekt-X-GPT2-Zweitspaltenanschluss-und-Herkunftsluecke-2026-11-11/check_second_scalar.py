"""Bounded exact C2 check from existing common primitive error parameters.
No first-column replay, inverse, quadrature, q evaluation or physical generation.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal, localcontext
from math import isqrt
import hashlib, json, sys, argparse
sys.set_int_max_str_digits(0)
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--abnahme',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
BASE=args.abnahme
paths={
 'budget':'review_20261110/original_20261109/budget/carrier_recombination/SHARP_BUDGET_INPUTS.json',
 'direct':'review_20261110/gpt2/DIRECT_BLOCK_RESULT.json',
 'projection':'review_20261110/original_20261109/budget/carrier_recombination/FIXED_PROJECTION_PRICE.json',
}
expected={
 'budget':'99cc57b33748ffd568b995f4710421bdfcc18d893851d60c7b7bef5177e2de8c',
 'direct':'86359656e85e981167e68fd2a09bafefec9267e2811aa4ec7f2e0a4f75e4f3ae',
 'projection':'8cdd24511af234ae10b5646b5f9adbcf07f02b69f0c66381ec579716219e6f48',
}
data={}
for label,path in paths.items():
 raw=(BASE/path).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==expected[label]
 data[label]=json.loads(raw)
j,r,p=(data[label]for label in ['budget','direct','projection'])
def up(x):
 x=F(x);s=10**80
 return F(-((-x.numerator*s)//x.denominator),s)
def sqrtup(x):
 s=10**80;n=isqrt(x.numerator*s*s//x.denominator)
 if F(n*n,s*s)<x:n+=1
 ans=F(n,s);assert ans*ans>=x
 return ans
def rec(x):
 with localcontext()as c:
  c.prec=32
  return {'rational':str(x),'decimal_display':str(Decimal(x.numerator)/Decimal(x.denominator))}
M=[[F(v)for v in row]for row in j['M_on_t_e']]
E=[[F(v['rational'])for v in row]for row in r['unchanged_other_error_on_t_e']]
lam=F(p['lambda_bar'][1]['rational']);k=F(j['k'])
assert lam<0 and k==F(13619,125000)
aa=up(F(r['alpha_abs_upper']['rational']))
bb=up(F(r['beta_abs_upper']['rational']))
rtt,rte,ree=up(E[0][0]),sqrtup(E[0][0]*E[1][1]),up(E[1][1])
b14=list(map(F,j['rank']['b14']));X12=list(map(F,j['X']['X12']))
# tau=mt+2*b+me, z2=b14-k*b-X12; same b in BOTH quantities.
constant=lam*lam*(M[0][0]+2*M[0][1]+M[1][1])-2*lam*(-k*M[0][1])
coeff=[lam*lam,2*lam*k,lam*lam,2*lam*lam+2*lam*k,lam*lam,-2*lam,2*lam]
boxes=[[-aa,aa],[-bb,bb],[-rtt,rtt],[-rte,rte],[-ree,ree],b14,X12]
names=['alpha','beta','dt','db','de','b14','X12']
argmax=[hi if c>=0 else lo for c,(lo,hi)in zip(coeff,boxes)]
cmax=constant+sum(c*x for c,x in zip(coeff,argmax))
alpha,beta,dt,db,de,c,y=argmax
mt=M[0][0]+alpha-2*beta+dt;b=M[0][1]+beta+db;me=M[1][1]+de
tau=mt+2*b+me;z2=c-k*b-y
assert cmax==lam*lam*tau-2*lam*z2
quoted=F('-0.0001814041205755')
Q=F('0.03518');r22_using_quote=F(25,21)*Q+quoted
assert r22_using_quote<F('0.0417')
out={
 'scope':'Second-column scalar implication only; inherited X12 physical/source contract remains conditional. No GPT1 second-column original package supplied.',
 'input_hashes':{paths[x]:expected[x]for x in paths},
 'lambda_bar2':rec(lam),'k':str(k),
 'C2_affine_coefficients':{name:rec(x)for name,x in zip(names,coeff)},
 'common_parameter_corner_maximum':rec(cmax),
 'quoted_C2_strict_cap':rec(quoted),'quoted_cap_reproduced':cmax<quoted,
 'R22_upper_using_quoted_C2':rec(r22_using_quote),
 'R22_upper_using_computed_C2':rec(F(25,21)*Q+cmax),
 'margin_below_0.0417_using_quote':rec(F('0.0417')-r22_using_quote),
 'second_energy_proved':False,'native_provenance_resolved':False,
}
args.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:(val['decimal_display']if isinstance(val,dict)and'decimal_display'in val else val)for key,val in out.items()if key not in ['input_hashes','C2_affine_coefficients']},indent=2))
