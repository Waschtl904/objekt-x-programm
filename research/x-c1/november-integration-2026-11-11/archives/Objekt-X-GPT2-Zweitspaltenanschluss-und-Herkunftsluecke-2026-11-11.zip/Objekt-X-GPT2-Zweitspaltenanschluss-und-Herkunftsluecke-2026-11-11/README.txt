Objekt X — Zweitspaltenanschluss und Herkunftslücke, GPT2, 11. November 2026

Der Bericht nennt den bedingten mathematischen Schluss, den tatsächlichen
Prüfumfang sowie genau die fehlenden Originaldateien. Die erste Spalte wurde
nicht erneut geprüft. Keine ganze zweite Restenergie wurde nachgewiesen.

Reproduktion ausschließlich des kleinen rationalen C2-/Qq-Anschlusses:
Python >=3.11, keine Zusatzpakete, keine Option -O. Im entpackten Paket:

python -B -X utf8 check_second_scalar.py --abnahme inputs --output RESULT_NEU.json

Die drei benötigten gebundenen Dateien liegen unter inputs/. Der Prüfer
kontrolliert ihre Hashes. Er führt weder eine neue q-Auswertung noch einen
Replay der ersten Spalte oder des Budgetprüfers aus.

SECOND_SCALAR_RESULT.json enthält die exakten Brüche; Dezimalanzeigen sind
nur lesbare Näherungen. NATIVE_BINDING_RESULT.json dokumentiert die gezielten
Herkunftsprüfungen samt erwarteten und tatsächlichen Hashes, betroffenen
Datenfeldern und Vergleichsbefunden. Die fehlenden nativen Originale sind
hier nicht enthalten. Die lokalen Hilfsbelege schließen diese Lücke nicht.

sources/ enthält die gelesene alte analytische Brücke und den verwendeten
Rekombinationscode als Herkunftsbelege; dieser Code wurde nicht ausgeführt.
MANIFEST.json bindet alle übrigen Paketmitglieder.
