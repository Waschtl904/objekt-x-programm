#!/usr/bin/env python3
"""Fixed first residual column: exact rational contraction, no new inverse.

Requires python-flint 0.9.0 for rational matrix multiplication only.
The physical contracts remain inherited; see HERLEITUNG.txt.
"""
import argparse
import gzip
import hashlib
import json
import math
import sys
from decimal import Decimal, localcontext
from fractions import Fraction as Q
from pathlib import Path
from flint import fmpq, fmpq_mat

sys.set_int_max_str_digits(0)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--abnahme', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--bindings', required=True, type=Path)
args = parser.parse_args()
bindings = json.loads(args.bindings.read_text())
for relative, expected in bindings.items():
    assert hashlib.sha256((args.abnahme / relative).read_bytes()).hexdigest() == expected, relative

def read(relative):
    data = (args.abnahme / relative).read_bytes()
    return json.loads(gzip.decompress(data) if data[:2] == b'\x1f\x8b' else data)

def matrix(rows):
    return fmpq_mat([[fmpq(str(v)) for v in row] for row in rows])

def rat(v):
    return Q(str(v))

def ceil_decimal(v, places=40):
    v = rat(v)
    scale = 10**places
    return Q(-((-v.numerator * scale) // v.denominator), scale)

def sqrt_upper(v, places=40):
    v = rat(v)
    assert v >= 0
    scale = 10**places
    n = math.isqrt((v.numerator * scale**2) // v.denominator)
    if n*n*v.denominator < v.numerator*scale**2:
        n += 1
    result = Q(n, scale)
    assert result*result >= v
    return result

def display(v):
    v = rat(v)
    with localcontext() as context:
        context.prec = 28
        return str(Decimal(v.numerator) / Decimal(v.denominator))

def record(v):
    return {'rational': str(rat(v)), 'decimal_display': display(v)}

def trace(a):
    return sum(a[i, i] for i in range(a.nrows()))

def positive_definite(a):
    # Exact LDL on the small, supplied 12-dimensional metric. No inverse.
    assert a == a.transpose()
    a = fmpq_mat(a)
    for k in range(a.nrows()):
        assert a[k, k] > 0
        for i in range(k + 1, a.nrows()):
            for j in range(i, a.nrows()):
                a[i, j] -= a[i, k] * a[j, k] / a[k, k]
                a[j, i] = a[i, j]

bank = read('budget_work/vorabtest/eingang/COMMON_BANK_109.json.gz')
coords = read('budget_work/vorabtest/eingang/FIRST_COLUMN_COORDINATES.json')
direct = read('review_20261110/gpt2/DIRECT_BLOCK_INPUTS.json')
inverse = read('direction/Objekt-X-GPT2-Richtungsnachweis-Neue-Inversmajorante-2026-11-01/final-inputs/INVERSE_DATA.json')
projection = read('review_20261110/original_20261109/budget/carrier_recombination/FIXED_PROJECTION_PRICE.json')
n = 109
model = matrix(bank['M_model_integer']) / fmpq(bank['denominator'])
error = matrix(bank['E_upper_integer']) / fmpq(bank['denominator'])
answer = matrix(coords['Tans109_first_column'])
assert answer.nrows() == n and answer[108, 0] == -1
assert [answer[i, 0] for i in range(n)] == [fmpq(x) for x in direct['t']]
assert model == model.transpose() and error == error.transpose()
radii = matrix(direct['radii'])
assert all(radii[i, j] >= 0 for i in range(n) for j in range(n))
old_direct = fmpq_mat(n, n)
for i, value in enumerate(direct['old_row_majorant']):
    old_direct[i, i] = fmpq(value)
    assert old_direct[i, i] >= sum(radii[i, j] for j in range(n))
# The additive physical provenance is part of the bound input contract.
# Keep all other 34 charges and export rounding; remove only the old direct
# interval row majorant. Pay its symmetrized primitive radii separately.
rest = error - old_direct
radii = (radii + radii.transpose()) / 2
b = matrix(inverse['input_basis_B'])
bi = matrix(inverse['input_basis_B_inverse'])
gp = matrix(inverse['G_p'])
gpi = matrix(inverse['G_p_inverse'])
identity = fmpq_mat(12, 12)
for i in range(12):
    identity[i, i] = 1
assert b * bi == identity and bi * b == identity
assert gp * gpi == identity and gpi * gp == identity
positive_definite(gp)
cgi = bi * gpi * bi.transpose()
cg = b.transpose() * gp * b
assert cg * cgi == identity and cgi * cg == identity
assert coords['Cg_B_transported_Gp_exact'] is True
y = matrix(inverse['test_columns_Y'])
selection = fmpq_mat(n, 12)
for j in range(12):
    selection[96 + j, j] = 1
    for i in range(96):
        selection[i, j] = -y[i, j]

# S(sigma0) = -selection^T M_phys answer.
smodel = -selection.transpose() * model * answer
model_sq = (smodel.transpose() * cgi * smodel)[0, 0]
rest_trace = trace(cgi * selection.transpose() * rest * selection)
rest_on_answer = (answer.transpose() * rest * answer)[0, 0]
assert model_sq >= 0 and rest_trace >= 0 and rest_on_answer >= 0
rest_sq = rest_trace * rest_on_answer
entry = [sum(radii[i, j] * abs(answer[j, 0]) for j in range(n)) for i in range(n)]
selected_entry = [sum(abs(selection[i, j]) * entry[i] for i in range(n)) for j in range(12)]
direct_sq = sum(abs(cgi[i, j]) * selected_entry[i] * selected_entry[j]
                for i in range(12) for j in range(12))
parts = [sqrt_upper(z) for z in (model_sq, rest_sq, direct_sq)]
s_upper = sum(parts)
s_cap = Q('0.001326293')
assert s_upper < s_cap

# Old WHOLE Qold price already includes F, shifted T, P and kappa errors.
f_old, t_old, p_old = Q('0.000000081'), Q('0.000342'), Q('0.000107')
old_ftp = f_old**2 + 10*(t_old + 10*f_old)**2 + Q(11, 10)*p_old**2
qold_cap = Q('0.0000012')
assert old_ftp < qold_cap
sigma_energy_cap = Q(25, 21)*(qold_cap + s_cap**2)

# t1 = sigma0 + s0, s0 = S_R w. Hence eta1 = sigma0 + epsilon*s0.
# Its WHOLE s0 energy is tau, not a separate T/P model estimate.
unit = fmpq_mat(n, 1)
unit[108, 0] = 1
w = answer + unit
tau_model = (w.transpose() * model * w)[0, 0]
tau_error = (w.transpose() * error * w)[0, 0]
tau_lower, tau_upper = tau_model - tau_error, tau_model + tau_error
assert 0 < tau_lower <= tau_upper < 4
epsilon = 1 - Q(projection['lambda_bar'][0]['rational'])
assert 0 < epsilon < Q('0.000000000000011406')
eta_norm_upper = sqrt_upper(sigma_energy_cap) + 2*epsilon
eta_energy_upper = eta_norm_upper**2
eta_cap = Q('0.000003523')
cap1, cap2 = Q('0.000006051814'), Q('0.1')
assert eta_energy_upper < eta_cap < cap1
# One sufficient joint condition; no claim that the second column meets it.
second_energy_threshold = cap2*(1-eta_cap/cap1)
joint_example = Q('0.0417')
assert eta_cap/cap1 + joint_example/cap2 < 1

result = {
    'status': 'FIRST_FIXED_RESIDUAL_COLUMN_BOUNDED_UNDER_INHERITED_CONTRACTS',
    'joint_status': 'RESTMACHBARKEIT_OFFEN',
    'new_integrations': 0, 'new_inversions': 0, 'new_q_evaluations': 0,
    'S_sigma0': {
        'model_norm_upper': record(parts[0]),
        'other_34_charges_and_export_norm_upper': record(parts[1]),
        'primitive_direct_norm_upper': record(parts[2]),
        'whole_norm_upper': record(s_upper),
        'rounded_norm_cap': record(s_cap),
        'rest_trace_upper': record(ceil_decimal(rest_trace)),
        'rest_on_answer_upper': record(ceil_decimal(rest_on_answer))},
    'inherited_FTP_sigma0': {
        'f_norm_cap': record(f_old), 'raw_t_norm_cap': record(t_old),
        'shifted_t_norm_cap': record(t_old + 10*f_old), 'p_norm_cap': record(p_old),
        'weighted_energy_from_separate_caps': record(old_ftp),
        'whole_Qold_energy_cap_used': record(qold_cap)},
    'sigma0_whole_energy_cap': record(sigma_energy_cap),
    'tau_upper_from_original_bank': record(ceil_decimal(tau_upper)),
    'tau_norm_cap_used': '2',
    'epsilon': record(epsilon),
    'eta1_whole_energy_upper': record(eta_energy_upper),
    'eta1_energy_cap': record(eta_cap),
    'certified_diagonal_capacity': [record(cap1), record(cap2)],
    'sufficient_second_whole_energy_threshold': record(second_energy_threshold),
    'second_energy_0_0417_sufficient': True,
    'second_energy_achieved': False,
    'physical_assumptions': [
        'Inherited H1-H4, corrected form comparison and complete old F/T/P prices.',
        'Additive common-bank provenance; -Erest <= DeltaMrest <= Erest.',
        'Cg = B^T Gp B and the frozen exact rational B,Y maps.',
        'sigma0=t1-S_R*w and tau=<w,S_R*w>; energy equals the kernel-zero Cs dual energy.'
    ],
    'input_sha256': bindings
}
args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({
    'status': result['status'], 'joint_status': result['joint_status'],
    'S_sigma0_norm_upper': display(s_upper),
    'sigma0_energy_cap': display(sigma_energy_cap),
    'eta1_energy_upper': display(eta_energy_upper),
    'eta1_energy_cap': str(eta_cap),
    'first_capacity': str(cap1),
    'second_sufficient_energy_threshold_NOT_ACHIEVED': display(second_energy_threshold)
}, indent=2))
