"""Independent integer/Fraction replay of the supplied finite certificate.
No matrix inversion, floating arithmetic, quadrature or source generation.
"""
from pathlib import Path
from fractions import Fraction as F
from math import gcd, lcm, isqrt
from decimal import Decimal, localcontext
import json, gzip, hashlib, time, sys, argparse
sys.set_int_max_str_digits(0)
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--abnahme',required=True,type=Path)
parser.add_argument('--nachtrag',required=True,type=Path)
parser.add_argument('--output',required=True,type=Path)
args=parser.parse_args()
BASE=args.abnahme
PKG=args.nachtrag
started=time.monotonic()

class Mat:
    def __init__(self, nums, den=1):
        self.a=nums
        self.d=den
        self.n=len(nums)
        self.m=len(nums[0])
        assert den>0 and all(len(r)==self.m for r in nums)
        g=den
        for r in nums:
            for x in r:
                g=gcd(g,x)
        if g>1:
            self.a=[[v//g for v in r]for r in nums]
            self.d//=g
    @classmethod
    def parse(cls, rows):
        rows=[[F(v)for v in r]for r in rows]
        den=1
        for r in rows:
            for v in r: den=lcm(den,v.denominator)
        return cls([[v.numerator*(den//v.denominator)for v in r]for r in rows],den)
    def T(self):return Mat([list(r)for r in zip(*self.a)],self.d)
    def __matmul__(self, b):
        assert self.m==b.n
        cols=list(zip(*b.a))
        return Mat([[sum(x*y for x,y in zip(row,col) if x and y)for col in cols]for row in self.a],self.d*b.d)
    def __add__(self,b):
        assert (self.n,self.m)==(b.n,b.m)
        den=lcm(self.d,b.d); x=den//self.d; y=den//b.d
        return Mat([[x*self.a[i][j]+y*b.a[i][j]for j in range(self.m)]for i in range(self.n)],den)
    def __neg__(self):return Mat([[-v for v in row]for row in self.a],self.d)
    def __sub__(self,b):return self+-b
    def half(self):return Mat(self.a,2*self.d)
    def abs(self):return Mat([[abs(v)for v in r]for r in self.a],self.d)
    def val(self,i=0,j=0):return F(self.a[i][j],self.d)
    def trace(self):return F(sum(self.a[i][i]for i in range(self.n)),self.d)
    def __eq__(self,b):return self.d==b.d and self.a==b.a

def read(rel):
    raw=(BASE/rel).read_bytes()
    return json.loads(gzip.decompress(raw)if raw[:2]==b'\x1f\x8b'else raw)

def sqrtup(x):
    x=F(x);assert x>=0
    scale=10**40
    n=isqrt(x.numerator*scale*scale//x.denominator)
    if n*n*x.denominator<x.numerator*scale*scale:n+=1
    q=F(n,scale);assert q*q>=x
    return q

def ceil40(x):
    x=F(x); scale=10**40
    return F(-((-x.numerator*scale)//x.denominator),scale)

def rec(x):
    x=F(x)
    with localcontext()as ctx:
        ctx.prec=30
        return {'rational':str(x),'decimal_display':str(Decimal(x.numerator)/Decimal(x.denominator))}

def assert_spd(a):
    assert a==a.T()
    b=[[a.val(i,j)for j in range(a.n)]for i in range(a.n)]
    for k in range(a.n):
        assert b[k][k]>0
        for i in range(k+1,a.n):
            for j in range(i,a.n):
                b[i][j]-=b[i][k]*b[j][k]/b[k][k]
                b[j][i]=b[i][j]

bindings=json.loads((PKG/'INPUT_BINDINGS.json').read_text())
bindings['direction/Objekt-X-GPT2-Richtungsnachweis-Neue-Inversmajorante-2026-11-01/COMMON_FULL_LEDGER.json']='c61eb43ccca5c9fb53e5ec809b16554d623c18c6b7d58598b60bb3b6197d50af'
for p,h in bindings.items():assert hashlib.sha256((BASE/p).read_bytes()).hexdigest()==h,p
bank=read('budget_work/vorabtest/eingang/COMMON_BANK_109.json.gz')
coords=read('budget_work/vorabtest/eingang/FIRST_COLUMN_COORDINATES.json')
direct=read('review_20261110/gpt2/DIRECT_BLOCK_INPUTS.json')
inv=read('direction/Objekt-X-GPT2-Richtungsnachweis-Neue-Inversmajorante-2026-11-01/final-inputs/INVERSE_DATA.json')
ledger=read('direction/Objekt-X-GPT2-Richtungsnachweis-Neue-Inversmajorante-2026-11-01/COMMON_FULL_LEDGER.json')
proj=read('review_20261110/original_20261109/budget/carrier_recombination/FIXED_PROJECTION_PRICE.json')
M=Mat([[int(v)for v in row]for row in bank['M_model_integer']],int(bank['denominator']))
E=Mat([[int(v)for v in row]for row in bank['E_upper_integer']],int(bank['denominator']))
t=Mat.parse(coords['Tans109_first_column'])
assert t.n==109 and t.val(108)==-1
assert t==Mat.parse([[v]for v in direct['t']])
assert M==M.T() and E==E.T()
rad=Mat.parse(direct['radii'])
rows=list(map(F,direct['old_row_majorant']))
assert len(rows)==109
assert all(v>=0 for row in rad.a for v in row)
assert all(rows[i]>=F(sum(rad.a[i]),rad.d)for i in range(109))
ED=Mat.parse([[rows[i]if i==j else 0 for j in range(109)]for i in range(109)])
Er=E-ED
rad=(rad+rad.T()).half()
B,Bi,G,Gi=[Mat.parse(inv[k])for k in ['input_basis_B','input_basis_B_inverse','G_p','G_p_inverse']]
I=Mat([[int(i==j)for j in range(12)]for i in range(12)])
assert B@Bi==I and Bi@B==I and G@Gi==I and Gi@G==I
assert_spd(G)
Cg=B.T()@G@B
Q=Bi@Gi@Bi.T()
assert Cg@Q==I and Q@Cg==I
assert coords['Cg_B_transported_Gp_exact'] is True
Y=inv['test_columns_Y']
L=Mat.parse([[-F(Y[i][j])if i<96 else int(i==96+j)if i<108 else 0 for j in range(12)]for i in range(109)])
print('Inputs and exact metric identities PASS',flush=True)
mu=-(L.T()@M@t)
model_sq=(mu.T()@Q@mu).val()
trace_rest=(Q@(L.T()@Er@L)).trace()
on_t=(t.T()@Er@t).val()
assert model_sq>=0 and trace_rest>=0 and on_t>=0
direct_vector=L.abs().T()@rad@t.abs()
direct_sq=(direct_vector.T()@Q.abs()@direct_vector).val()
parts=[sqrtup(x)for x in [model_sq,trace_rest*on_t,direct_sq]]
s=sum(parts);s_cap=F('0.001326293');assert s<s_cap
old_trace=(Q@(L.T()@ED@L)).trace()
old_t=(t.T()@ED@t).val()
old_record=ledger['prices']['direct_pairing_saved_interval']
trace_match=F(old_record['lift_trace'][0])<=old_trace<=F(old_record['lift_trace'][1])
t_match=F(old_record['witness'][0])<=old_t<=F(old_record['witness'][1])
assert t_match and trace_match
print('S contraction PASS; old direct witness',t_match,'old direct lift trace',trace_match,flush=True)
f,tt,p=map(F,['0.000000081','0.000342','0.000107'])
ftp=f*f+10*(tt+10*f)**2+F(11,10)*p*p
assert ftp<F('0.0000012')
sigma_cap=F(25,21)*(F('0.0000012')+s_cap*s_cap)
unit=Mat([[int(i==108)]for i in range(109)])
w=t+unit
tau0=(w.T()@M@w).val();taue=(w.T()@E@w).val()
assert 0<tau0-taue<=tau0+taue<4
eps=1-F(proj['lambda_bar'][0]['rational']);assert 0<eps<F('1.1406e-14')
eta_upper=(sqrtup(sigma_cap)+2*eps)**2
eta_cap=F('0.000003523');c1=F('0.000006051814');c2=F('0.1')
assert eta_upper<eta_cap<c1
threshold=c2*(1-eta_cap/c1)
trace_sum=eta_cap/c1+F('0.0417')/c2
assert trace_sum<1
author=json.loads((PKG/'RESULT.json').read_text())
checks={
 'S_sigma0.model_norm_upper':parts[0],
 'S_sigma0.other_34_charges_and_export_norm_upper':parts[1],
 'S_sigma0.primitive_direct_norm_upper':parts[2],
 'S_sigma0.whole_norm_upper':s,
 'S_sigma0.rounded_norm_cap':s_cap,
 'S_sigma0.rest_trace_upper':ceil40(trace_rest),
 'S_sigma0.rest_on_answer_upper':ceil40(on_t),
 'inherited_FTP_sigma0.weighted_energy_from_separate_caps':ftp,
 'sigma0_whole_energy_cap':sigma_cap,
 'tau_upper_from_original_bank':ceil40(tau0+taue),
 'epsilon':eps,
 'eta1_whole_energy_upper':eta_upper,
 'eta1_energy_cap':eta_cap,
 'sufficient_second_whole_energy_threshold':threshold,
}
for path,value in checks.items():
    obj=author
    for part in path.split('.'):obj=obj[part]
    assert F(obj['rational'])==value,path
result={
 'status':'PASS_TARGETED_INDEPENDENT_RATIONAL_REVIEW',
 'backend':'Python arbitrary-size integers and fractions.Fraction; python-flint author checker not executed',
 'scope':'All new matrix products, supplied inverse identities, positive metric, directed square-root bounds, complete scalar closing chain and joint normalized trace. Physical contracts inherited.',
 'author_exact_rational_values_matched':{k:rec(v)for k,v in checks.items()},
 'old_direct_charge_witness_in_original_interval':t_match,
 'old_direct_charge_S_trace_in_original_interval':trace_match,
 'old_direct_charge_S_trace':rec(old_trace),
 'joint_trace_upper':rec(trace_sum),'joint_trace_margin':rec(1-trace_sum),
 'tau_lower':rec(tau0-taue),'new_integrations':0,'new_inversions':0,'new_q_evaluations':0,
 'input_sha256':bindings,'elapsed_seconds':round(time.monotonic()-started,3)
}
args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'S_norm_upper':rec(s),'eta1_energy_upper':rec(eta_upper),'second_threshold':rec(threshold),'joint_trace_upper':rec(trace_sum),'seconds':result['elapsed_seconds']},ensure_ascii=False,indent=2),flush=True)
