OBJEKT X — GPT2-Prüfpaket vom 11. November 2026

Ergebnis: ERSTE_FESTE_RESTSPALTE_GEZIELT_ABGENOMMEN unter H1–H4 und den
übernommenen physischen Verträgen. RESTMACHBARKEIT_OFFEN.

Der Bericht enthält die mathematische Abnahme und die Grenzen des Prüfumfangs.
Die Prüfakte trennt eigene Nachrechnung, Identitätsprüfungen und übernommene
physische Voraussetzungen. INDEPENDENT_RESULT.json speichert exakte rationale
Resultate; seine Dezimalanzeigen sind nur zur Lesbarkeit gerundet.

Das originale GPT1-ZIP liegt unverändert unter autor/. Der originale
python-flint-Prüfer wurde nicht ausgeführt. GPT2 hat die endliche Rechnung
unabhängig mit Ganzzahlmatrizen und fractions.Fraction nachvollzogen.

Reproduktion mit Python >=3.11, ohne zusätzliche Pakete:
1. Dieses Prüfpaket und das beigefügte GPT1-ZIP entpacken.
2. Den bereits übergebenen Abnahmestand vom 10. November entpackt bereithalten.
   Sein ZIP ist hier nicht nochmals enthalten. Größe und SHA256 stehen in
   der Prüfakte unter prior_source_package.
3. Vom Paketordner aus ausführen (Pfade ersetzen, ohne Python-Option -O):

python -B -X utf8 independent_review.py --abnahme "PFAD_ZUM_ABNAHMESTAND" --nachtrag "PFAD_ZUM_GPT1_PAKETORDNER" --output "RESULT_NEU.json"

Der Abnahmestand muss unmittelbar budget_work/, direction/ und
review_20261110/ enthalten. Der GPT1-Paketordner enthält INPUT_BINDINGS.json
und RESULT.json. Der Prüfer kontrolliert elf Autorenbindungen sowie eine
zusätzliche Bindung an das originale COMMON_FULL_LEDGER.json.

Die Zeitangabe elapsed_seconds kann zwischen Wiederholungen abweichen.
Der Prüfer erzeugt keine neuen Integrale, Inversen oder q-Auswertungen.
Er ersetzt nicht die historischen Quellen-, Integrations- und Domänenbeweise.

MANIFEST.json bindet alle übrigen Dateien dieses Prüfpakets per Größe und SHA256.
Die zweite Energie <=0.0417 ist nur ein hinreichendes Ziel, kein erzieltes Ergebnis.
