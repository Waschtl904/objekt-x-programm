"""Fresh whole-function transport for the one model-coupling response.

The previous physical B-to-model Gamma prices are retained. The additional
B0-to-B change in the high response is paid again conservatively.
"""
from common_core_source_price import *
from load_full_source_model import load
from math import factorial

def main():
    started=time.monotonic();ns=load(analytic=True);ctx.prec=2048
    v=build(model_only=True,gamma_reserve=True);e=v['e'];C=v['C'];sub=v['sub'];co=v['co']
    oc=v['oc'];ga=v['ga'];gamma=e.w['gamma'];rho=e.w['rho'];s=1-rho
    d=q('19/10');d0=q('1.8219');d1=q('1.84298');beta=q('5/21')
    norm=lambda A:trace(A.transpose()*A).upper().sqrt()
    quad=lambda A,x:(x.transpose()*A*x)[0,0].upper()
    def mid(A):return arb_mat([[A[i,j].mid()for j in range(A.ncols())]for i in range(A.nrows())])
    def cat(AA):return arb_mat([[A[i,j]for A in AA for j in range(A.ncols())]for i in range(AA[0].nrows())])
    def psup(poly):
        # Exact power-to-Chebyshev conversion on [-1,1], before absolute values.
        out=[arb(0)]*len(poly);power=[arb(1)]
        for a in poly:
            for j,w in enumerate(power):out[j]+=a*w
            nxt=[arb(0)]*(len(power)+1)
            for j,w in enumerate(power):
                if j==0:nxt[1]+=w
                else:nxt[j-1]+=w/2;nxt[j+1]+=w/2
            power=nxt
        return sum((abs(z).upper()for z in out),arb(0)).upper()
    G=WS/'work/common-form-gain-review-2026-11-01/gpt1-original';P=WS/'work/stronger-form-inventory-2026-11-01'
    witness=read(HERE/'MODEL_COUPLING_RITZ_WITNESS.json')
    y=matrix(witness['shell96_rational']);c=matrix(witness['outer12_raw_rational']);xi=matrix(witness['core_low_coefficients_MODEL_rational'])
    yF=sub(y,range(12),[0]);yJ=sub(y,range(12,96),[0]);combo=arb_mat([[y[i,0]if i<96 else c[i-96,0]]for i in range(108)])
    proof=read(HERE/'MODEL_COUPLING_CORE.json');Gup=matrix(proof['G0_upper_integer'])/q(proof['G0_upper_denominator'])
    low=read(P/'inputs/LOW_SCHUR_CERTIFICATE.json');HB=matrix(low['HB1_integer'])/q(low['HB1_denominator'])
    LP=C.transpose()*(matrix(low['F1_rational'])+HB/d0+(q('7e-40')-q(proof['physical_low_defect_price']))*eye(191)-Gup/d)*C
    assert pos(LP)[0];Li=LP.inv()
    source=read(HERE/'bound-source-inputs/FINITE_MODEL_FUNCTIONALS.json');phi=boxes(source['Phi_g'])
    force=read(WS/'work/new-block-energy-2026-11-01/inputs/FORCE_NORM.json');fq=force['quantities'];ag=boxes(force['force_model'])
    rawc=cat([boxes(oc['source_c_model']),boxes(ga['old_low_c_model']),e.ell])
    rawb=cat([boxes(oc['source_Bh_model']),boxes(ga['old_low_Bh_model']),e.By])
    vq=(d1/d)*s.sqrt()*mid(ag)+(1-d1/d)*C.transpose()*mid(phi)-C.transpose()*(mid(rawc)-mid(rawb)/d)*combo
    xmodel=C*Li*vq
    eta_round=s.sqrt()*norm(C.solve(xi-xmodel))
    pre=read(HERE/'COMMON_CORE_SOURCE_PRICE.json')['quantities']
    evpre=box(pre['preconditioned_source_error']).upper()
    eta=s.sqrt()*norm(Li)*evpre+eta_round
    eb=box(oc['old_coupling_error_norm']).upper()
    forcecap=10+beta.sqrt()*100*((1/d0-1/d)*trace(C.transpose()*HB*C).upper().sqrt()/s.sqrt()+eb*norm(C)/(d*s.sqrt()))
    ledger=read(G/'inputs/SOURCE_BLOCK_LEDGER_V2.json');EcF=boxes(oc['joint_low_source_error_gram'])
    sharp=boxes(ledger['sharpening']['new_physical_z_source_error_gram'])
    for i in range(4):
        for j in range(4):EcF[i,j]=2*gamma*sharp[i,j]
    eflow=quad(EcF,yF).sqrt();jlow=gamma.sqrt()*box(ga['source_model_error_norm']).upper()*norm(yJ)
    ephysical=e.eResidual.upper()*quad(e.G,c).sqrt();eg=box(fq['core_source_error']).upper()
    old=v['s']['env']['inp'].json('a8_model')
    Am=arb_mat([[q(a).union(q(b))/q(10**100)for a,b in row]for row in old['parities']['even']['A']])
    ff=ns['ff'];low_round=norm(rawc*combo-phi-Am*ff-ns['low'])
    pn=norm(yF);wn=norm(yJ);fn=norm(xi)
    rawsource=gamma.sqrt()*(e.eRawJ*wn+e.eRawF*pn+e.eRawA*fn+ephysical+eg)
    rawsource+=jlow+eflow+e.eLowA*fn+gamma.sqrt()*(ephysical+eg)+low_round
    # Additional physical B -> chosen B0 high-response difference, distinct
    # from all older Gamma160/A160 model errors in rawsource.
    B0_extra=eb*fn
    a=ns['a'];Pphi=2*sum((abs(ff[i,0]).upper()*(q(2*n+1)/(2*a)).sqrt()for i,n in enumerate(range(2,384,2))),arb(0))
    Plow=2*sum((abs(ns['low'][i,0]).upper()*(q(2*n+1)/(2*a)).sqrt()for i,n in enumerate(range(2,384,2))),arb(0))
    Z=32*pn;binding=read(HERE/'directed-full-source-model/BINDING.json');S=q(binding['caps']['shell_polynomial_sup_upper'])
    Hcore=psup(ns['h_global'])+max(psup(p)for p in ns['h_primes'])+ns['h_uniform_error'].upper()
    # These are core-only real envelopes. The source's outer endpoint
    # envelope is not needed to bound the norm of the core response.
    Fcore=10000*(Pphi+Plow+Z+S+abs(ns['lm']).upper()+Hcore+1)
    U=100*(Fcore+Hcore+1)
    reg=e.bounds['old_FJ_regular_kernel_uniform_error']
    pair=read(OLD/'work/single-force-2026-10-27/PAIR_BUDGET.json')['quantities']
    eg9=box(pair['new_source_Hilbert_error']).upper();g9cap=box(pair['simple_G_norm_cap']).upper()
    assert eg9<2*eg and g9cap<=32
    rawX=100*(rawsource+B0_extra)/d+100*reg*U+100*reg*(wn+16*pn)
    rawX+=100000*(e.eBareJ*wn+e.eBareF*pn)+2*ephysical+eg9
    # The complete analytic inner approximation has no missing strip.
    # Componentwise (Cauchy, regular convolution and moments) transport is
    # used here, because only the integrated core pieces use the polynomial.
    # 1e8 dominates the separate inherited Hilbert/regular/moment caps; no
    # cancellation of these approximation errors is assumed.
    analytic=q('1e8')*(ns['h_whole_error'].upper()+ns['hm_cosh_price'].upper())
    caps=binding['caps'];F=q(caps['core_real_log_envelope']);hc=q(caps['source_real_log_envelope'])
    lm=abs(ns['lm']).upper();Lambda=2*lm;A=10*(F+hc+1);Um=100*(F+hc+1)
    Qpsi=100*(40*Z+20*S+1000*lm+1);eps=q(Fraction(2,factorial(160)))
    moment=eps*(100*(300*Lambda+2*A+2*Lambda)+2*Qpsi+100*Um+24*Lambda)
    lift=1000*eps*(Um+Pphi+1);small=moment+lift
    assert small<q('1e-150')
    rawX+=q('1e-150')+analytic
    error_T=forcecap*eta+beta.sqrt()*rawX
    finite=read(HERE/'bound-source-inputs/FINITE_ERROR_CONTRACT.json')
    p0_bound=sum(((box(r['bare_old_price']).upper()+box(r['bare_new_source_price']).upper())**2 for r in finite['per_column']),arb(0)).sqrt()
    assert p0_bound<q('1e-20')
    # Bare-old/new prices each dominate the P0-only term in their documented
    # formula. They are used to prove this cap, not added to the new ledger.
    vals={'preconditioned_source_error':evpre,'low_inverse_Frobenius_norm':norm(Li),'frozen_low_answer_eta_round':eta_round,
        'physical_low_answer_eta_error':eta,'new_low_force_cap':forcecap,'raw_projection_rounding':low_round,
        'old_physical_raw_source_error':rawsource,'additional_B0_high_response_raw_price':B0_extra,
        'core_source_real_sup':Hcore,'Phi_ff_real_sup':Pphi,'core_raw_response_norm_cap':U,
        'outer_Gamma_kernel_error':reg,'outer_Gamma_error_price':100*reg*U,
        'whole_raw_X_error':rawX,'analytic_core_approximation_X_price':analytic,'moment_and_lift_X_price':small,
        'whole_T_dual_error':error_T,'same_g9_norm_cap':g9cap,'same_g9_Hilbert_model_error':eg9,
        'P0_g_B_covector_error_cap_from_inherited_parts':p0_bound}
    out={'status':'FRESH_WHOLE_PHYSICAL_TRANSPORT_PENDING_WRITTEN_APPLICATION_AUDIT',
        'quantities':{k:endpoints(x)for k,x in vals.items()},'display_only':{k:float(x.mid())for k,x in vals.items()},
        'complete_model_norm_included':False,'Fo_component_included':False,'outer_lift_component_included':False,
        'physical_B_to_B0_change_paid_separately':True,'old_Gamma160_errors_retained':True,
        'source_approximation_includes_whole_inner_strip':True,'new_quadratures':0,
        'pending':'Written scope audit of inherited force/whole-coupling caps and new core-only real envelope',
        'physical_inverse_upper_claimed':False,'bindings':bindings}
    (HERE/'WHOLE_PHYSICAL_TRANSPORT.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    for k,x in vals.items():print(k,float(x.mid()),flush=True)
    print('seconds',time.monotonic()-started,flush=True)

if __name__=='__main__':main()
