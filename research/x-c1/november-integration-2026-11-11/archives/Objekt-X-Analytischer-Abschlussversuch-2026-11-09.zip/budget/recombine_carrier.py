#!/usr/bin/env python3
"""Bounded recombination of SAVED primitives, not a second physical run.

Usage: python3 recombine_carrier.py PREPARATION_DIR RESULT_DIR OUTPUT_DIR
Requires exactly python-flint 0.9.0. Precision remains 3328 bits.
No primitive-generation method is imported or called. Missing cache keys abort.
"""
import gzip, hashlib, json, sys
from pathlib import Path
from fractions import Fraction
from functools import lru_cache

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'python_deps'))
prep=Path(sys.argv[1]).resolve(); results=Path(sys.argv[2]).resolve(); out=Path(sys.argv[3]).resolve()
out.mkdir(exist_ok=True)
sys.dont_write_bytecode=True
sys.path.insert(0,str(prep/'belege'))
import flint
assert flint.__version__=='0.9.0'
from flint import arb,arb_poly,arb_mat,ctx
ctx.prec=3328
from common import q,box,enc,legs,mellin,norm,pad
from old_fields import kernel
from weights import gamma_error
import model_cache

manifest=json.loads((prep/'MANIFEST.json').read_bytes())
source_hashes={}
def native(path, source_hash, prepared=False):
    raw=path.read_bytes(); source_hashes[str(path)]=hashlib.sha256(raw).hexdigest()
    data,bindings=model_cache.load(path,source_hash)
    if prepared:
        assert all(hashlib.sha256((prep/'belege'/name).read_bytes()).hexdigest()==h for name,h in bindings.items())
    else:
        assert bindings==manifest
    return data

print('Loading fixed source, force, inverse snapshots.',flush=True)
s=native(results/'lauf/QUELLEN_NATIVE.json.gz',manifest['ganzkern.py'])
f=native(results/'lauf/KRAFT_UND_LOESUNG_NATIVE.json.gz',manifest['ganzkern.py'])
p=native(prep/'PREPARED_CORE.json.gz',manifest['vorbereiten.py'],prepared=True)

pp=results/'lauf/VERWENDETE_PRIMITIVE_NATIVE.json.gz'
raw=pp.read_bytes();source_hashes[str(pp)]=hashlib.sha256(raw).hexdigest()
body=json.loads(gzip.decompress(raw));del raw
assert body['source_sha256']==manifest['ganzkern.py'] and body['inputs']==manifest
assert hashlib.sha256(body['payload'].encode()).hexdigest()==body['payload_sha256']
packed=dict(json.loads(body['payload'])['mapping']);del body
assert packed['degree']==1100
entries={}
for end,logs,values in packed['entries']:
    # Only moments already used by the original carrier computation are needed.
    if not logs or (end in ('zero','one') and logs in (['one'],['minus_one'])):
        entries[(end,tuple(logs))]=model_cache.unpack(values)
del packed
used=set()

@lru_cache(None)
def sequence(left,right,logs):
    for key in ((left,logs),(right,logs)):
        if key not in entries:raise RuntimeError('MISSING_SAVED_PRIMITIVE: '+repr(key))
        used.add(key)
    return [b-a for a,b in zip(entries[(left,logs)],entries[(right,logs)],strict=True)]

def contract(parts,left,right):
    total=arb(0)
    for tag,poly in parts.items():
        vals=sequence(left,right,(tag,) if tag else ())
        assert len(poly)<=len(vals)
        total+=sum((c*vals[i]for i,c in enumerate(poly)),arb(0))
    return total

def read(name):
    raw=(prep/'belege'/name).read_bytes()
    source_hashes[name]=hashlib.sha256(raw).hexdigest()
    while raw[:2]==b'\x1f\x8b':raw=gzip.decompress(raw)
    return json.loads(raw)

print('Recombining 191 carrier moments from cached primitives only.',flush=True)
a8=3*arb(2).log()/2;d=q('19/10');leg=legs(383)
carrier=arb_poly([(a8/2)**i/arb.fac_ui(i)if i%2==0 else 0 for i in range(161)])
assert q('3e7')*2/arb.fac_ui(160)*(a8/2).sqrt()<q('1e-275')
old=read('a8_model_full.json.gz');assert old['Gamma_degree']==160
cs=list(map(q,old['Gamma_polynomial_coefficients']))
Am=arb_mat([[box(v)/10**100 for v in row]for row in old['parities']['even']['A']])
m0=mellin(0,a8); roots=s['roots'];rows=[];hull_counts={'new':0,'old':0,'intersection':0}
channels=((2,2),(3,3),(4,2),(5,5),(7,7),(8,2))
for i,n in enumerate(range(2,384,2)):
    factor=(arb(2*n+1)/(2*a8)).sqrt()
    row=[arb(0)]*(n+1);row[0]=-factor*mellin(n,a8)/m0;row[n]=factor
    phi=leg[n]*factor+row[0]
    harmonic=sum((arb(1)/j for j in range(1,n+1)),arb(0))
    smooth=leg[n]*(factor*harmonic)+phi*(-(2*arb.pi()*a8).log()-arb.const_euler())
    smooth-=kernel(phi,row,a8,cs,0)
    field={None:smooth,'one':phi*q('-1/2'),'minus_one':phi*q('-1/2')}
    qm=contract({tag:poly*carrier for tag,poly in field.items()},'zero','one')
    for cell in s['cell_moments']:
        left,right=cell['left'],cell['right'];center=(roots[left]+roots[right])/2
        prime=arb_poly([])
        for value,prime_base in channels:
            shift=arb(value).log()/a8
            for sign in (-1,1):
                at=center+sign*shift
                assert -1<at<1 or at<-1 or at>1
                if -1<at<1:
                    prime-=phi(arb_poly([sign*shift,1]))*(arb(prime_base).log()/arb(value).sqrt())
        qm+=contract({None:prime*carrier},left,right)
    new=pad(a8*qm,q('1e-275'))
    # Every other original raw moment and its error remains untouched.
    previous=f['raw_QPhi'][i,1]
    assert previous.overlaps(new)
    if previous.contains(new):hull_counts['new']+=1
    elif new.contains(previous):new=previous;hull_counts['old']+=1
    else:new=previous.intersection(new);hull_counts['intersection']+=1
    rows.append([f['raw_QPhi'][i,0],new,f['raw_QPhi'][i,2]])
    if i%48==0:print('Carrier row',i+1,'of 191',flush=True)

raw=arb_mat(rows);c=s['lowq'];Nq=2*(s['square_q']-s['mc'][1]**2/s['mu'])
Hq=Nq+s['gamma']*s['eh'][1]**2-(c.transpose()*c)[0,0]
H12=2*(s['cross_raw']-s['mc'][0]*s['mc'][1]/s['mu'])+s['gamma']*s['eh'][0]*s['eh'][1]-(s['low12'].transpose()*c)[0,0]
coef=(-2*s['mc'][1]-s['gamma']*s['me']*s['eh'][1])/s['mu']
Bh=arb_mat([[2*raw[i,0]+coef*raw[i,1]+s['gamma']*s['eh'][1]*(2/a8).sqrt()*raw[i,2]]for i in range(191)])-Am.transpose()*c
vq=p['C'].transpose()*(c-Bh/d);v1=p['v12_preconditioned']
zq=p['L_inverse']*vq;z1=p['solution12_preconditioned']

# Same complete physical Gamma160, Bphys/B0 and source prices as native review.
eps=gamma_error(160,q('21/20'));eRaw=2*a8*eps*s['gamma'].sqrt();eLow=8*a8*eps*s['gamma']
eB=q(read('MODEL_COUPLING_CORE.json')['physical_coupling_error_upper'])
bridge=p['C_norm']*(eRaw*(Nq.sqrt()+s['gamma']*abs(s['eh'][1]))+eLow*norm(c)+eB*Hq.sqrt())/d
source=(p['C_norm']+p['B0_C_norm']/d)*s['gamma'].sqrt()*sum(s['source_errors'][1].values(),arb(0)).upper()
eq=(bridge+source).upper();e1=p['v12_error'].upper();t=p['inverse_norm_cap'].upper()
e12=norm(z1)*eq+norm(zq)*e1+t*e1*eq+f['errors']['high12'].upper()
e22=2*norm(zq)*eq+t*eq**2+f['errors']['high22'].upper()
model12=H12/d+(v1.transpose()*zq)[0,0];model22=Hq/d+(vq.transpose()*zq)[0,0]
X12=pad(model12,e12.upper());X22=pad(model22,e22.upper())
final={'X11':p['scalars']['X11'],'X12':enc(X12),'X22':enc(X22),'k':'13619/125000','d':'19/10',
       'new_source_passes':0,'new_integrations':0,'new_primitive_generations':0,'new_inversions':0}
(out/'SHARP_X_INTERVALS.json').write_text(json.dumps(final,indent=2)+'\n')

def rad_l1(A):return sum((A[i,j].rad()for i in range(A.nrows())for j in range(A.ncols())),arb(0))
summary={'status':'SAVED_CARRIER_RECOMBINATION_COMPLETE','precision_bits':3328,'flint_version':flint.__version__,
  'new_integrations':0,'new_primitive_generations':0,'new_inversions':0,
  'saved_primitive_keys_used':[[a,list(b)]for a,b in sorted(used)],
  'carrier_price_per_field':'1e-275','carrier_norm_cap':'3e7',
  'carrier_cap_scope':'Derived from physical QPhi field norm and Gamma160 bridge; not inferred by shrinking old balls.',
  'old_and_new_valid_carrier_intervals_intersected':True,'selected_hull_counts':hull_counts,
  'q_solution_radius_l1':enc(rad_l1(zq)),'q_force_radius_l1':enc(rad_l1(vq)),
  'old_q_solution_radius_l1':enc(rad_l1(f['solutionq_preconditioned'])),
  'new_X12':enc(X12),'new_X22':enc(X22),'model12_radius':enc(model12.rad()),'model22_radius':enc(model22.rad()),
  'low12_full_physical_price':enc(e12),'low22_full_physical_price':enc(e22),
  'new_low_error':enc(eq),'old_low_error':enc(e1),'hashes':source_hashes}
(out/'CARRIER_RECOMBINATION_RESULT.json').write_text(json.dumps(summary,indent=2)+'\n')
model_cache.save(out/'SHARP_FORCE_SOLUTION_NATIVE.json.gz',{'raw_QPhi':raw,'vq_preconditioned':vq,'solutionq_preconditioned':zq,
                 'model12':model12,'model22':model22,'X12':X12,'X22':X22,'errors':{'low12':e12,'low22':e22}},
                 hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_hashes)
print('Done. New q solution radius:',rad_l1(zq).str(12),'X12:',X12.str(20),'X22:',X22.str(20),flush=True)
