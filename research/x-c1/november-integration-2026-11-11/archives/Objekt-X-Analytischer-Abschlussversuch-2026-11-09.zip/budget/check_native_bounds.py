#!/usr/bin/env python3
"""Read exact dyadic snapshots and bound matrix/solution norms, no flint required.

Usage: python3 check_native_bounds.py PREPARED_CORE.json.gz KRAFT_UND_LOESUNG_NATIVE.json.gz
"""
import gzip,json,hashlib,sys
from fractions import Fraction as Q
from decimal import Decimal,localcontext
from pathlib import Path
from math import ceil

HERE=Path(__file__).resolve().parent
sys.set_int_max_str_digits(100000)
def load(path):
    data=json.loads(gzip.decompress(Path(path).read_bytes()))
    assert hashlib.sha256(data['payload'].encode()).hexdigest()==data['payload_sha256']
    return dict(json.loads(data['payload'])['mapping'])
def radius(x):
    m,e,r,s=x['ball'];return Q(r)*Q(2)**s
def absolute_upper(x):
    m,e,r,s=x['ball'];return abs(Q(m)*Q(2)**e)+Q(r)*Q(2)**s
def display(x,sqrt=False):
    with localcontext() as c:
        c.prec=25;y=Decimal(x.numerator)/Decimal(x.denominator)
        return str(y.sqrt() if sqrt else y)

p=Path(sys.argv[1]);f=Path(sys.argv[2]);prep=load(p);force=load(f)
grid=10**30
caps=[[ceil(absolute_upper(x)*grid)for x in row]for row in prep['L_inverse']['matrix']]
sq=Q(sum(x*x for row in caps for x in row),grid*grid)
assert sq<196
result={'source':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
        'method':'Absolute native ball endpoints rounded up on 1e-30 grid, then exact sum of squares; no inverse recalculated.',
        'grid':str(grid),'squared_upper':str(sq),'strict_Frobenius_upper':'14','proof':True,'new_inversions':0}
(HERE/'INVERSE_NORM_RECOMBINATION.json').write_text(json.dumps(result,indent=2)+'\n')
radii={}
for key in ('solution12_preconditioned','solutionq_preconditioned','v12_preconditioned','vq_preconditioned'):
    rr=[radius(row[0])for row in force[key]['matrix']]
    r1=sum(rr);r2=sum(x*x for x in rr)
    radii[key]={'radius_l1':str(r1),'radius_l1_display':display(r1),
                'radius_square_sum':str(r2),'radius_l2_display':display(r2,sqrt=True),
                'max_radius_display':display(max(rr))}
(HERE/'NATIVE_SOLUTION_RADII.json').write_text(json.dumps(radii,indent=2)+'\n')
print('Frobenius squared upper:',display(sq),'strict norm <14: PASS')
print(json.dumps({k:v['radius_l1_display']for k,v in radii.items()},indent=2))
