#!/usr/bin/env python3
"""Rational budget recombination only. No inversion, moments or integration.

Default: replay the compact, exact input snapshot beside this file.
--input INPUT --output OUTPUT: replay another compact snapshot, e.g. sharp X.
--extract SOURCE_ROOT: extract the snapshot from the two unpacked source packages.
"""
from fractions import Fraction as Q
from decimal import Decimal, localcontext
from pathlib import Path
from itertools import product
from math import lcm
import gzip, hashlib, io, json, sys
from zipfile import ZipFile

sys.set_int_max_str_digits(100000)
HERE = Path(__file__).resolve().parent

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def unwrap(x):
    if isinstance(x, dict) and 'mapping' in x:
        return {k: unwrap(v) for k, v in x['mapping']}
    if isinstance(x, list):
        return [unwrap(v) for v in x]
    return x

def extract(root):
    root = Path(root)
    prep = next(root.glob('Objekt-X-GPT2-*/Objekt-X-GPT2-*/PREPARED_CORE.json.gz'))
    results = root/'Objekt-X-Ganzkern-Einzelpass-und-GPT1-Abnahme-2026-11-05'
    raw = prep.read_bytes()
    body = json.loads(gzip.decompress(raw))
    assert digest(body['payload'].encode()) == body['payload_sha256']
    scalars = unwrap(dict(json.loads(body['payload'])['mapping'])['scalars'])
    xp = results/'GPT1_X_INTERVALLE.json'
    x = json.loads(xp.read_bytes())
    old = prep.parent/'belege/Objekt-X-GPT2-Zweiraumgram-Bestandscheck-2026-11-05.zip'
    with ZipFile(old) as z1:
        with ZipFile(io.BytesIO(z1.read('belege/Objekt-X-GPT2-Projizierte-Restenergie-2026-11-04.zip'))) as z2:
            with ZipFile(io.BytesIO(z2.read('belege/Objekt-X-Rang1-Abschlusskarte-2026-11-04.zip'))) as z3:
                with ZipFile(io.BytesIO(z3.read('rang1/GPT1_VORABTEST.zip'))) as z4:
                    bank_raw = z4.read('eingang/COMMON_BANK_109.json.gz')
                    coeff_raw = z4.read('eingang/FIRST_COLUMN_COORDINATES.json')
                    bank = json.loads(gzip.decompress(bank_raw))
                    coeff = json.loads(coeff_raw)
    t = [Q(row[0]) for row in coeff['Tans109_first_column']]
    assert len(t) == 109 and t[-1] == -1
    den = lcm(*(v.denominator for v in t))
    ti = [int(v*den) for v in t]
    def contract(mat):
        mt = [sum(v*w for v,w in zip(row,ti)) for row in mat]
        return [[str(Q(sum(v*w for v,w in zip(ti,mt)),den*den*int(bank['denominator']))),
                 str(Q(mt[-1],den*int(bank['denominator'])))],
                [str(Q(mt[-1],den*int(bank['denominator']))),
                 str(Q(mat[-1][-1],int(bank['denominator'])))]]
    snapshot = {
        'scope':'Inherited contracts under H1-H4; no independent reproof of source contracts.',
        'source_hashes': {
            str(prep.relative_to(root)):digest(raw),
            str(xp.relative_to(root)):digest(xp.read_bytes()),
            str(old.relative_to(root)):digest(old.read_bytes()),
            'nested/COMMON_BANK_109.json.gz':digest(bank_raw),
            'nested/FIRST_COLUMN_COORDINATES.json':digest(coeff_raw)},
        'k':scalars['k'], 'D':scalars['D'],
        'rank':{k:scalars['rank'][k] for k in ('a','b12','b14','V0')},
        'X':{k:x[k] for k in ('X11','X12','X22')},
        'M_on_t_e':contract(bank['M_model_integer']),
        'E_on_t_e':contract(bank['E_upper_integer']),
        'full_bank_error_contract':bank['contract'],
        'full_bank_dimension':bank['dimension']}
    (HERE/'BUDGET_INPUTS.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    return snapshot

def dec(q, places=22):
    q = Q(q)
    with localcontext() as ctx:
        ctx.prec = places
        return str(Decimal(q.numerator)/Decimal(q.denominator))

def pack(x):
    if isinstance(x,Q):return {'rational':str(x),'decimal_display':dec(x)}
    if isinstance(x,list):return [pack(v) for v in x]
    if isinstance(x,dict):return {k:pack(v) for k,v in x.items()}
    return x

def run(inp):
    k = Q(inp['k'])
    D = [[Q(v) for v in row] for row in inp['D']]
    d = D[0][0]
    e = D[0][1]-k*d
    f = D[1][1]-2*k*D[0][1]+k*k*d
    boxes = [tuple(map(Q,inp['rank'][key])) for key in ('b12','b14','V0')]
    boxes += [tuple(map(Q,inp['X'][key])) for key in ('X11','X12','X22')]
    midpoint = tuple(sum(v)/2 for v in boxes)

    def quantities(p):
        b,c,V,x,y,z=p
        tau=2*b-V-x
        delta=V-b
        bk2=c-k*b
        z2=bk2-y
        A0=[[d-V,e-bk2],[e-bk2,f-z]]
        B3=[[A0[0][0],A0[0][1],delta],
            [A0[1][0],A0[1][1],z2],
            [delta,z2,tau]]
        B=[[A0[0][0]-delta**2/tau,A0[0][1]-delta*z2/tau],
           [A0[0][1]-delta*z2/tau,A0[1][1]-z2**2/tau]]
        det=B[0][0]*B[1][1]-B[0][1]**2
        det3=(d-V)*((f-z)*tau-z2*z2)-(e-bk2)**2*tau+2*(e-bk2)*delta*z2-(f-z)*delta**2
        assert det3==tau*det
        return {'tau':tau,'B3':B3,'B':B,'det_B':det,'det_B3':det3,
                'first_schur_numerator':tau*B[0][0],
                'first_direction_reserve_if_R12_R22_zero':B[0][0]-B[0][1]**2/B[1][1]}

    mid = quantities(midpoint)
    assert mid['tau']>0 and mid['B'][0][0]>0 and mid['det_B']>0
    # det(B3) is separately concave in all six variables on this box.
    # Second derivatives for b,c,V,x,y,z are, respectively:
    # -2*(d*k^2+2*e*k+f-k^2*x-2*k*y-z), -2*(d-x), 0, 0,
    # -2*(d-V), 0. These inequalities are verified exactly below.
    assert d*k*k+2*e*k+f > k*k*boxes[3][1]+2*k*boxes[4][1]+boxes[5][1]
    assert d>boxes[3][1] and d>boxes[2][1] and k>0
    corners=list(product(*boxes))
    corner_values=[quantities(p) for p in corners]
    min3=min(v['det_B3'] for v in corner_values)
    minp=min(v['first_schur_numerator'] for v in corner_values)
    mint=min(v['tau'] for v in corner_values)
    assert minp>0 and mint>0 and min3<0

    # At fixed other inputs det(B3) is affine and strictly decreasing in V.
    def rootV(b,c,x,y,z):
        p0=quantities((b,c,Q(0),x,y,z))['det_B3']
        p1=quantities((b,c,Q(1),x,y,z))['det_B3']
        assert p1-p0<0
        return -p0/(p1-p0)
    b,c,V,x,y,z=midpoint
    root_mid=rootV(b,c,x,y,z)
    other_corners=list(product(*(boxes[:2]+boxes[3:])))
    root_box=min(rootV(*p) for p in other_corners)
    # First pivot remains strictly positive at the determinant threshold.
    assert all(quantities((b,c,root_box,x,y,z))['first_schur_numerator']>0
               for b,c,x,y,z in other_corners)

    # Common 109-bank assignment: Delta M = sign*E, retaining every dependency.
    M=[[Q(v) for v in row]for row in inp['M_on_t_e']]
    E=[[Q(v) for v in row]for row in inp['E_on_t_e']]
    assert E[0][0]>0 and E[1][1]>0 and E[0][0]*E[1][1]>=E[0][1]**2
    assignments=[]
    for sign in (-1,0,1):
        mt=M[0][0]+sign*E[0][0]
        me=M[0][1]+sign*E[0][1]
        ee=M[1][1]+sign*E[1][1]
        p=(me,midpoint[1],-mt,-ee,midpoint[4],midpoint[5])
        a=2*me+mt
        assert all(lo<=v<=hi for v,(lo,hi) in zip(p,boxes))
        assert Q(inp['rank']['a'][0])<=a<=Q(inp['rank']['a'][1])
        qv=quantities(p)
        assert qv['tau']>0 and p[3]>0 and p[3]*p[5]>p[4]**2
        assignments.append({'sign_of_full_E':sign,'b12':p[0],'b14':p[1],
                            'V0':p[2],'a':a,'X11':p[3],'X12':p[4],'X22':p[5],
                            'checks':'Within all exported scalar/X intervals; exact a=2b12-V0; positive X and tau.',
                            **qv})
    assert assignments[0]['det_B']<0 and assignments[2]['det_B']>0

    radius=(boxes[2][1]-boxes[2][0])/2
    return pack({
        'status':'NO_UNIFORM_POSITIVE_BUDGET_CERTIFICATE_FROM_CURRENT_CONTRACTS',
        'new_integrations':0,'new_191_inversions':0,'new_trial_directions':0,
        'physical_positivity':'UNDECIDED; error-contract assignments are not physical witnesses.',
        'D_k':[[d,e],[e,f]],
        'midpoint_diagnostic':mid,
        'dependent_block_box_lower_bounds':{'tau':mint,'first_schur_numerator':minp,'det_B3':min3,
            'qualification':'Exact minimum for the scalar box. This box is a superset of the common-bank contract.'},
        'common_bank_assignments':assignments,
        'V0_threshold_with_other_midpoints_fixed':root_mid,
        'V0_threshold_sufficient_for_all_other_exported_box_inputs':root_box,
        'V0_upper_radius_current':radius,
        'allowed_upper_radius_midpoint':root_mid-midpoint[2],
        'allowed_upper_radius_box':root_box-midpoint[2],
        'fraction_of_current_radius_midpoint':(root_mid-midpoint[2])/radius,
        'fraction_of_current_radius_box':(root_box-midpoint[2])/radius,
        'threshold_scope':'Rhat=0 only. Strict V0 upper bound required. No claim that tightening is achievable.',
        'rest_region_midpoint_only':{
            'conditions':'R symmetric PSD; R22 < B22; R11 < B11 - (B12-R12)^2/(B22-R22).',
            'qualification':'Exact algebra at the stored rational midpoint; not a physical rest certificate.'},
        'critical_existing_uncertainty':'E[t,t] in the common 109-bank error form; DeltaM=-E prevents a positive budget even with X12,X22 fixed at midpoint.',
        'sources':inp['source_hashes']})

if __name__=='__main__':
    outfile=HERE/'BUDGET_RESULT.json'
    if len(sys.argv)==3 and sys.argv[1]=='--extract':
        inp=extract(sys.argv[2])
    elif len(sys.argv)==5 and sys.argv[1]=='--input' and sys.argv[3]=='--output':
        inp=json.loads(Path(sys.argv[2]).read_text());outfile=Path(sys.argv[4])
    else:
        assert len(sys.argv)==1
        inp=json.loads((HERE/'BUDGET_INPUTS.json').read_text())
    result=run(inp)
    outfile.write_text(json.dumps(result,indent=2)+'\n')
    def display(x):
        if isinstance(x,dict) and 'decimal_display' in x:return x['decimal_display']
        if isinstance(x,dict):return {k:display(v) for k,v in x.items()}
        if isinstance(x,list):return [display(v) for v in x]
        return x
    print(json.dumps(display({'status':result['status'],
        'midpoint':{k:v for k,v in result['midpoint_diagnostic'].items() if k not in ('B3',)},
        'counterassignment_det':result['common_bank_assignments'][0]['det_B'],
        'V0_threshold_box':result['V0_threshold_sufficient_for_all_other_exported_box_inputs']}),indent=2))
