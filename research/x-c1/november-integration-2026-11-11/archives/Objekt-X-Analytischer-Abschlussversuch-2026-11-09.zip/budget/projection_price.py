#!/usr/bin/env python3
"""Exact projection coefficient enclosure from one scalar/X contract.

Usage: python3 projection_price.py BUDGET_INPUTS.json [SHARP_X_INTERVALS.json]
Writes FIXED_PROJECTION_PRICE.json beside the optional X file, else beside input.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
from decimal import Decimal,localcontext
import json,sys,hashlib

sys.set_int_max_str_digits(100000)
inp_path=Path(sys.argv[1]);inp=json.loads(inp_path.read_text())
xp=Path(sys.argv[2]) if len(sys.argv)>2 else None
xs=json.loads(xp.read_text()) if xp else inp['X']
rank=inp['rank'];k=Q(inp['k'])
boxes=[tuple(map(Q,rank[key]))for key in ('b12','b14','V0')]
boxes += [tuple(map(Q,xs[key]))for key in ('X11','X12')]
mid=[sum(v)/2 for v in boxes]
def lam(p):
    b,c,V,x,y=p;t=2*b-V-x
    assert t>0
    return ((b-x)/t,(c-k*b-y)/t)
lb=lam(mid)
vals=[lam(p)for p in product(*boxes)]
intervals=[(min(v[i]for v in vals),max(v[i]for v in vals))for i in range(2)]
errors=[max(abs(a-lb[i])for a in intervals[i])for i in range(2)]
tau_hi=Q(rank['a'][1])-Q(xs['X11'][0])
price=tau_hi*sum(x*x for x in errors)
def pack(x):
    if isinstance(x,Q):
        with localcontext() as ctx:
            ctx.prec=24;ds=str(Decimal(x.numerator)/Decimal(x.denominator))
        return {'rational':str(x),'decimal_display':ds}
    if isinstance(x,(tuple,list)):return [pack(a)for a in x]
    if isinstance(x,dict):return {k:pack(v)for k,v in x.items()}
    return x
result=pack({'status':'FIXED_RATIONAL_PROJECTION_WITH_EXACT_OVERPRICE',
    'lambda_bar':lb,'lambda_intervals':intervals,'lambda_errors':errors,'tau_upper':tau_hi,
    'spectral_norm_overprice_upper':price,
    'matrix_bound':'tau*(lambda-lambda_bar)*(lambda-lambda_bar)^T <= spectral_norm_overprice_upper * I2',
    'identity':'Rbar=R+tau*(lambda-lambda_bar)*(lambda-lambda_bar)^T; R<=Rbar',
    'method':'Each ratio is fractional linear in each common variable, so its box extrema occur at vertices. Exact a=2b12-V0 retained.',
    'scope':'Existing K+span(u), no new response direction; superset box of physical scalar data.',
    'new_integrations':0,'new_inversions':0,
    'input_sha256':hashlib.sha256(inp_path.read_bytes()).hexdigest(),
    'X_sha256':hashlib.sha256(xp.read_bytes()).hexdigest()if xp else None})
out=(xp.parent if xp else inp_path.parent)/'FIXED_PROJECTION_PRICE.json'
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ('lambda_errors','tau_upper','spectral_norm_overprice_upper')},indent=2))
