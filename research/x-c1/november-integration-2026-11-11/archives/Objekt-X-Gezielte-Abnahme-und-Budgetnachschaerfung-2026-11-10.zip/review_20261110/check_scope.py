#!/usr/bin/env python3
"""Targeted checks of the 9-Nov package. No moments, integration, or inversion."""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import product
from math import isqrt
from pathlib import Path
import hashlib, json, gzip, sys
sys.set_int_max_str_digits(0)

ROOT=Path(__file__).resolve().parent
P=ROOT/'original_20261109'/'budget'
old=json.loads((P/'BUDGET_INPUTS.json').read_text())
sharp=json.loads((P/'carrier_recombination/SHARP_BUDGET_INPUTS.json').read_text())
def dec(x):
    with localcontext() as c:
        c.prec=30
        return str(Decimal(x.numerator)/Decimal(x.denominator))
def pack(x):
    if isinstance(x,F):return {'rational':str(x),'decimal_display':dec(x)}
    if isinstance(x,list):return [pack(a) for a in x]
    if isinstance(x,dict):return {k:pack(v) for k,v in x.items()}
    return x
def sqlo(lo,hi):return F(0) if lo<=0<=hi else min(lo*lo,hi*hi)
def sqrt_upper(x):
    scale=10**90
    n=isqrt(x.numerator*scale*scale//x.denominator)
    if F(n*n,scale*scale)<x:n+=1
    return F(n,scale)
k=F(sharp['k']);D=[[F(x) for x in row] for row in sharp['D']]
d=D[0][0];e=D[0][1]-k*d;f=D[1][1]-2*k*D[0][1]+k*k*d
M=[[F(x) for x in row]for row in sharp['M_on_t_e']]
E=[[F(x) for x in row]for row in sharp['E_on_t_e']]
assert old['M_on_t_e']==sharp['M_on_t_e'] and old['E_on_t_e']==sharp['E_on_t_e']
assert E[0][0]>0 and E[1][1]>0 and E[0][0]*E[1][1]>E[0][1]**2

def uniform_negative(inp):
    mt=M[0][0]-E[0][0]; b=M[0][1]-E[0][1]; xx=-(M[1][1]-E[1][1])
    V=-mt;a=2*b-V;tau=a-xx;delta=V-b
    assert tau>0
    b11=d-V-delta*delta/tau
    assert b11>0
    cc=list(map(F,inp['rank']['b14'])); yy=list(map(F,inp['X']['X12'])); zz=list(map(F,inp['X']['X22']))
    b12s=[e-(c-k*b)-delta*(c-k*b-y)/tau for c,y in product(cc,yy)]
    b12lo,b12hi=min(b12s),max(b12s)
    z2lo,z2hi=cc[0]-k*b-yy[1],cc[1]-k*b-yy[0]
    b22hi=f-zz[0]-sqlo(z2lo,z2hi)/tau
    upper=b11*b22hi-sqlo(b12lo,b12hi)
    assert upper<0
    assert all(F(inp['rank'][n][0])<=v<=F(inp['rank'][n][1])for n,v in [('a',a),('b12',b),('V0',V)])
    assert F(inp['X']['X11'][0])<=xx<=F(inp['X']['X11'][1])
    assert xx>0 and xx*zz[0]>max(y*y for y in yy)
    return {'scope':'Same Mhat-E assignment; all b14,X12,X22 in this export box. Not a physical realization proof.',
            'joint_checks':'One common full -E assignment; a=2b12-V0, all scalar boxes, X positive throughout the X12/X22 box, and tau positive.',
            'tau':tau,'B11':b11,'B12_interval':[b12lo,b12hi],'B22_upper':b22hi,
            'det_H_uniform_upper':upper,'det_3block_uniform_upper':tau*upper}

# Single conditional target from user, not a new family or an achieved error bound.
# Loewner -E/4<=DeltaM<=E/4 implies these entry bounds on S*DeltaM S.
rad=[E[0][0]/4,sqrt_upper(E[0][0]*E[1][1])/4,E[1][1]/4]
boxes=[[M[0][0]-rad[0],M[0][0]+rad[0]],
       [M[0][1]-rad[1],M[0][1]+rad[1]],
       [M[1][1]-rad[2],M[1][1]+rad[2]],
       list(map(F,sharp['rank']['b14'])),list(map(F,sharp['X']['X12'])),list(map(F,sharp['X']['X22']))]
R11,R22=F('1e-5'),F('0.1')
values=[]
for mt,b,me,c,y,z in product(*boxes):
    V=-mt;xx=-me;tau=2*b-V-xx;delta=V-b;bk=c-k*b;z2=bk-y
    A=d-V-R11;B=e-bk;C=f-z-R22
    pivot=tau*A-delta*delta
    det3=A*(C*tau-z2*z2)-B*B*tau+2*B*delta*z2-C*delta*delta
    assert tau>0 and pivot>0 and det3>0
    values.append((tau,pivot,det3))
conditional={'assumptions':'hypothetical -E/4<=DeltaM<=E/4; Rhat=diag(1e-5,0.1); sharp X intervals; original b14 interval',
             'certified_reachable':False,'PSD_proof':'3x3 affine symmetric block positive at all 64 box vertices; convexity preserves positivity in the box.',
             'vertices':len(values),'tau_lower':min(x[0]for x in values),
             'first_schur_numerator_lower':min(x[1]for x in values),'det_block_lower':min(x[2]for x in values)}

raw=P/'carrier_recombination/SHARP_FORCE_SOLUTION_NATIVE.json.gz'
body=json.loads(gzip.decompress(raw.read_bytes()))
assert hashlib.sha256(body['payload'].encode()).hexdigest()==body['payload_sha256']
fields=dict(json.loads(body['payload'])['mapping']); rr=[F(row[0]['ball'][2])*F(2)**row[0]['ball'][3]for row in fields['solutionq_preconditioned']['matrix']]
r1=sum(rr);r2=sum(r*r for r in rr)
assert r1<F('1e-80') and r2<F('6e-87')**2
native={'object':'solutionq_preconditioned, arithmetic ball radii only; physical source errors separate',
        'new_L1':r1,'new_L2_squared':r2,'new_L1_strict_upper':'1e-80','new_L2_strict_upper':'6e-87',
        'same_native_file_sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}
result=pack({'status':'PASS_TARGETED_SCOPE_CHECKS','old_boxes_uniform_negative':uniform_negative(old),
             'sharp_boxes_uniform_negative':uniform_negative(sharp),'conditional_user_target':conditional,
             'radius_reconciliation':native,'new_integrations':0,'new_inversions':0,
             'original_input_sha256':hashlib.sha256((P/'BUDGET_INPUTS.json').read_bytes()).hexdigest(),
             'sharp_input_sha256':hashlib.sha256((P/'carrier_recombination/SHARP_BUDGET_INPUTS.json').read_bytes()).hexdigest()})
(ROOT/'SCOPE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({
    'old_det_upper':result['old_boxes_uniform_negative']['det_H_uniform_upper']['decimal_display'],
    'sharp_det_upper':result['sharp_boxes_uniform_negative']['det_H_uniform_upper']['decimal_display'],
    'conditional_target_det3_lower':result['conditional_user_target']['det_block_lower']['decimal_display'],
    'new_L1':dec(r1),'new_L2_squared':dec(r2),'status':result['status']},indent=2))
