#!/usr/bin/env python3
"""Package the completed review and exactly its source bindings."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json,hashlib
ROOT=Path(__file__).resolve().parent.parent
H=ROOT/'review_20261110'
original=ROOT/'Objekt-X-Analytischer-Abschlussversuch-2026-11-09.zip'
expected='bb969c4a364d8c44d1d5ac4d931636e1ca74c4da1fa4a93d198c8a7806424c90'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(original.read_bytes())==expected
with ZipFile(original)as z:
    assert z.testzip() is None
    manifest=json.loads(z.read('MANIFEST.json'))
    print('Original manifest type',type(manifest).__name__)
    if isinstance(manifest,dict) and 'files'in manifest:manifest=manifest['files']
    if isinstance(manifest,dict):
        for p,v in manifest.items():
            expected_file=v['sha256']if isinstance(v,dict)else v
            assert sha(z.read(p))==expected_file,p
    else:
        for item in manifest:
            assert sha(z.read(item['path']))==item['sha256']
    count=len(manifest)
assert count==30
integrity={'original_zip_sha256':expected,'original_bytes':original.stat().st_size,
           'original_crc_ok':True,'original_manifest_hashes_verified':count}
(H/'ORIGINAL_INTEGRITY.json').write_text(json.dumps(integrity,indent=2)+'\n')

inputs=json.loads((H/'gpt2/DIRECT_BLOCK_RESULT.json').read_text())['input_hashes']
for p,h in inputs.items():assert sha((ROOT/p).read_bytes())==h,p
rr=json.loads((H/'REFINED_BUDGET_RESULT.json').read_text())
assert rr['input_sha256']['DIRECT_BLOCK_RESULT.json']==sha((H/'gpt2/DIRECT_BLOCK_RESULT.json').read_bytes())
selected={p:ROOT/p for p in inputs}
base='direction/Objekt-X-GPT2-Richtungsnachweis-Neue-Inversmajorante-2026-11-01/'
for p in [base+'source/common_full_ledger.py',base+'PACKAGE_SHA256.json',base+'INPUT_BINDINGS.json',
          'budget_work/vorabtest/eingang/COMMON_BANK_109.json.gz']:
    selected[p]=ROOT/p
for p in H.rglob('*'):
    if not p.is_file()or'transfer_helpers'in p.parts or'__pycache__'in p.parts:continue
    selected[str(p.relative_to(ROOT))]=p
selected['original/'+original.name]=original
selected['LESEN.txt']=H/'LESEN.txt'
files={arc:sha(p.read_bytes())for arc,p in sorted(selected.items())}
out=ROOT/'Objekt-X-Gezielte-Abnahme-und-Budgetnachschaerfung-2026-11-10.zip'
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=6)as z:
    for arc,p in sorted(selected.items()):z.write(p,arc)
    z.writestr('MANIFEST.json',json.dumps({'files':files},indent=2)+'\n')
with ZipFile(out)as z:
    assert z.testzip()is None
    for p,h in files.items():assert sha(z.read(p))==h,p
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),
                  'manifest_files':len(files),'crc':'PASS','all_hashes':'PASS'},indent=2))
