#!/usr/bin/env python3
"""Reconstruct only the stored direct-pairing interval term, no solves/integrals.

The original 109-source build is NOT imported or executed.
"""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,gzip,hashlib
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'budget_work/python_deps'))
import flint
from flint import arb,arb_mat,fmpq,ctx
assert flint.__version__=='0.9.0'
ctx.prec=1024
BASE=ROOT/'direction/Objekt-X-GPT2-Richtungsnachweis-Neue-Inversmajorante-2026-11-01'
hashes={}
def read(path):
    path=Path(path);raw=path.read_bytes();hashes[str(path.relative_to(ROOT))]=hashlib.sha256(raw).hexdigest()
    while raw[:2]==b'\x1f\x8b':raw=gzip.decompress(raw)
    return json.loads(raw)
def q(x):return arb(fmpq(str(Q(str(x)))))
def matrix(a):return arb_mat([[q(x)for x in row]for row in a])
def box(v):
    lo,hi=map(q,v);return arb((lo+hi)/2,(hi-lo)/2)
def boxes(a):return arb_mat([[box(x)for x in row]for row in a])
def endpoints(x):return [str(x.lower().fmpq()),str(x.upper().fmpq())]
def radius(x):return Q(str(x.rad().fmpq()))
def exactmid(x):return Q(str(x.mid().fmpq()))
def crossfill(A,i,j,X):
    for k in range(X.nrows()):
        for l in range(X.ncols()):A[i+k,j+l]=A[j+l,i+k]=X[k,l]
def block(items,n=109):
    A=arb_mat(n,n)
    for k,X in items:
        for i in range(X.nrows()):
            for j in range(X.ncols()):A[k+i,k+j]=X[i,j]
    return A

ledger=read(BASE/'COMMON_FULL_LEDGER.json')
package=read(BASE/'PACKAGE_SHA256.json')['files']
original_source=read(BASE/'INPUT_BINDINGS.json')
src=read(BASE/'inputs/finite-source/FINITE_MODEL_FUNCTIONALS.json')
rec=read(BASE/'inputs/finite-source/FINITE_RECOMBINATION_DATA.json')
force=read(BASE/'inputs/FORCE_NORM.json')['quantities']
common=read(BASE/'inputs/REFINED_COMMON96.json.gz')['cases'][0]
pairs=read(BASE/'inputs/PAIRS_even.json.gz')
inv=read(BASE/'final-inputs/INVERSE_DATA.json')
kd=read(BASE/'inputs/REFINED_K_MATRIX.json')
direct=read(BASE/'inputs/finite-source/DIRECT12_RESULT.json')
coords=read(ROOT/'budget_work/vorabtest/eingang/FIRST_COLUMN_COORDINATES.json')
tq=[Q(row[0])for row in coords['Tans109_first_column']]
assert len(tq)==109 and tq[-1]==-1
B=matrix(inv['input_basis_B'])
bare=boxes(src['bare_FJ']);barez=boxes(src['bare_z'])
mc=box(force['moment_mc']);mu=box(rec['geometry']['mu8'])
for i in range(4):bare[i,0]+=barez[i,0]
for i in range(92):bare[i+4,0]-=2*box(rec['old_lam92'][i])*mc/mu
k=boxes(direct['dB'])-boxes(src['P0_g'])
D=(boxes(common['D96_lower_model'])+boxes(common['D96_upper_model']))/2
K=B.transpose()*boxes(kd['matrices']['K_computational_interval'])*B
A=block([(0,D),(96,K)])
crossfill(A,0,96,boxes(pairs['bare_F_J_pairs'])*B)
crossfill(A,0,108,bare);crossfill(A,96,108,k)
assert A[108,108].is_zero()
# Matrix products may carry slightly unequal Arb radii in symmetric entries.
# The original ledger symmetrizes its final model; quadratic contractions
# below automatically use that same symmetric part.

# Match the original radius-to-diagonal step at its original precision.
row=[sum((A[i,j].rad()for j in range(109)),arb(0)).upper()for i in range(109)]
rowq=[Q(str(v.fmpq()))for v in row]
t=arb_mat([[q(x)]for x in tq])
Ediag=arb_mat(109,109)
for i,x in enumerate(row):Ediag[i,i]=x
original_replayed=endpoints((t.transpose()*Ediag*t)[0,0])
expected=ledger['prices']['direct_pairing_saved_interval']['witness']
print('Direct replay',float(Q(original_replayed[0])),float(Q(original_replayed[1])),
      'stored',float(Q(expected[0])),float(Q(expected[1])),flush=True)
exact_original_contraction=sum(tq[i]**2*rowq[i]for i in range(109))
print('exact contraction inside old stored interval',Q(expected[0])<=exact_original_contraction<=Q(expected[1]),
      'difference',float(exact_original_contraction-(Q(expected[0])+Q(expected[1]))/2),flush=True)

# Contract primitive symmetric entry errors before any diagonal majorization.
w=tq[:108]
radii=[[radius(A[i,j])for j in range(109)]for i in range(109)]
aD=sum(abs(w[i]*w[j])*radii[i][j]for i in range(108)for j in range(108))
bD=sum(abs(w[i])*radii[i][108]for i in range(108))
oldEtt=sum(tq[i]**2*rowq[i]for i in range(109))
oldEte=-rowq[108];oldEee=rowq[108]
old2=[[oldEtt,oldEte],[oldEte,oldEee]]
snapshot=read(ROOT/'budget_work/BUDGET_INPUTS.json')
bank=read(ROOT/'budget_work/vorabtest/eingang/COMMON_BANK_109.json.gz')
assert bank['original_ledger_sha256']==hashlib.sha256((BASE/'COMMON_FULL_LEDGER.json').read_bytes()).hexdigest()
assert bank['original_source_sha256']==hashlib.sha256((BASE/'source/common_full_ledger.py').read_bytes()).hexdigest()
for rel,h in hashes.items():
    path=ROOT/rel
    if path.is_relative_to(BASE):
        inner=str(path.relative_to(BASE))
        if inner in package:assert package[inner]==h,inner
assert Q(expected[0])<=exact_original_contraction<=Q(expected[1])
totalE=[[Q(x)for x in row]for row in snapshot['E_on_t_e']]
restE=[[totalE[i][j]-old2[i][j]for j in range(2)]for i in range(2)]
assert restE[0][0]>=0 and restE[1][1]>=0 and restE[0][0]*restE[1][1]>=restE[0][1]**2

# Optional rational PSD hull of the same two primitive errors, without E/4.
# |[[-2,1],[1,0]]| = [[3,-1],[-1,1]]/sqrt(2).
c=Q(707106781186547525,10**18);assert 2*c*c>1
new2=[[aD+3*c*bD,-c*bD],[-c*bD,c*bD]]
newE=[[restE[i][j]+new2[i][j]for j in range(2)]for i in range(2)]
assert newE[0][0]>0 and newE[1][1]>0 and newE[0][0]*newE[1][1]>newE[0][1]**2

def show(x):
    from decimal import Decimal,localcontext
    with localcontext()as dc:
        dc.prec=26;return str(Decimal(x.numerator)/Decimal(x.denominator))
def outval(x):
    if isinstance(x,Q):return {'rational':str(x),'decimal_display':show(x)}
    if isinstance(x,list):return [outval(v)for v in x]
    if isinstance(x,dict):return {k:outval(v)for k,v in x.items()}
    return x
result=outval({'status':'DIRECT_PRIMITIVE_BLOCK_RECONSTRUCTED_WITH_OLD_CHARGE_ENCLOSURE_MATCH',
    'precision_bits':1024,'new_integrations':0,'new_inversions':0,'new_q_recombination':0,
    'exact_old_charge_contraction_in_original_recorded_interval':True,'old_recorded_witness_interval':expected,
    'source_and_ledger_hash_bound_to_original_109_bank':True,
    'alpha_abs_upper':aD,'beta_abs_upper':bD,
    'primitive_block':'Delta D_on_(t,e) = [[alpha-2 beta,beta],[beta,0]]',
    'primitive_scalar_transport':'Delta a=alpha, Delta b12=beta, Delta V0=2 beta-alpha, Delta X11=0',
    'old_direct_error_on_t_e':old2,'old_total_error_on_t_e':totalE,
    'unchanged_other_error_on_t_e':restE,
    'new_direct_common_PSD_error_on_t_e':new2,'new_total_common_PSD_error_on_t_e':newE,
    'new_to_old_Ett_ratio':newE[0][0]/totalE[0][0],
    'physical_D_errors_removed':False,
    'scope':'Only the arithmetic direct_pairing_saved_interval is replaced. All physical source, high-Gram, inverse-force, direct_D and direct_K charges remain unchanged.',
    'no_positive_total_R_claim':True,'input_hashes':hashes})
(HERE/'DIRECT_BLOCK_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
minimal={'radii':[[str(x)for x in row]for row in radii],
         'old_row_majorant':list(map(str,rowq)),'t':list(map(str,tq)),
         'total_error_on_t_e':snapshot['E_on_t_e'],
         'old_recorded_witness_interval':expected,
         'source_hashes':hashes}
(HERE/'DIRECT_BLOCK_INPUTS.json').write_text(json.dumps(minimal,separators=(',',':'))+'\n')
def display(x):
    if isinstance(x,dict):return x['decimal_display']if 'decimal_display'in x else{k:display(v)for k,v in x.items()}
    if isinstance(x,list):return [display(v)for v in x]
    return x
print(json.dumps(display({k:result[k]for k in ('alpha_abs_upper','beta_abs_upper','old_direct_error_on_t_e','new_total_common_PSD_error_on_t_e','new_to_old_Ett_ratio')}),indent=2))
