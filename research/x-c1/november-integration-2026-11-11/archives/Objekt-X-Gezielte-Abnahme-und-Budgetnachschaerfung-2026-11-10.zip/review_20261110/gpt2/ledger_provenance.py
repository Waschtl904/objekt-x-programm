#!/usr/bin/env python3
"""Classify the original saved ledger, without rerunning its producer."""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib
H=Path(__file__).resolve().parent;ROOT=H.parents[1]
B=ROOT/'direction/Objekt-X-GPT2-Richtungsnachweis-Neue-Inversmajorante-2026-11-01'
p=B/'COMMON_FULL_LEDGER.json';d=json.loads(p.read_text())
arith={'c_quadrature','Bh_quadrature','g_force_saved_interval','g_force_interval_second_variation','high_Gram_saved_interval','direct_pairing_saved_interval','finite_Arb_arithmetic'}
mixed={'low_source_second_variation'}
rows=[];groups={}
for n,v in d['prices'].items():
 category='arithmetic'if n in arith else 'mixed_physical_arithmetic'if n in mixed else 'physical_or_inherited_model_bridge'
 lo,hi=map(Q,v['witness']);groups[category]=groups.get(category,Q(0))+hi
 rows.append({'name':n,'classification':category,'old_witness_interval':v['witness'],
              'witness_upper_decimal_display':float(hi),
              'Young_majorized':n in d['exact_positive_Young_parameters'],
              'old_Young_parameter':d['exact_positive_Young_parameters'].get(n),
              'individual_tAt_tBt_separately_exported':False,
              'all_three_old_prices':v})
rows.sort(key=lambda r:Q(r['old_witness_interval'][1]),reverse=True)
out={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
     'producer_sha256':hashlib.sha256((B/'source/common_full_ledger.py').read_bytes()).hexdigest(),
     'number_of_charges':len(rows),'number_of_Young_charges':len(d['exact_positive_Young_parameters']),
     'groups_upper':{k:str(v)for k,v in groups.items()},'sum_recorded_witness_upper':str(sum(groups.values())),
     'whole_old_ledger_witness':d['quantities']['whole_physical_ledger_on_witness'],
     'allocation_weight':'t t^T + 100 TF Knew^-1 TF^T + TL Cg^-1 TL^T',
     'Young_rule':'lambda = midpoint(sqrt(tr(Weight B)/tr(Weight A))); charge lambda A + B/lambda',
     'reconstruction_limit':'Saved charge+lambda alone cannot identify t^T A t,t^T B t or lost cross-correlations. Constituent source data must be reconstructed.',
     'rows':rows,'original_bindings':d['bindings']}
(H/'LEDGER_PROVENANCE.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'charges':len(rows),'Young_charges':out['number_of_Young_charges'],
                 'groups':{k:float(v)for k,v in groups.items()}},indent=2))
