#!/usr/bin/env python3
"""Independent Fraction replay of the supplied direct-radius contraction.

No flint, integral, inversion or new kernel computation.
"""
from pathlib import Path
from fractions import Fraction as Q
from decimal import Decimal,localcontext
import json,sys
sys.set_int_max_str_digits(100000)
H=Path(__file__).resolve().parent
d=json.loads((H/'DIRECT_BLOCK_INPUTS.json').read_text())
r=[[Q(x)for x in row]for row in d['radii']]
t=list(map(Q,d['t']));w=t[:108];rows=list(map(Q,d['old_row_majorant']))
assert len(r)==len(t)==109 and t[-1]==-1 and r[108][108]==0
assert all(x>=0 for row in r for x in row)
assert all(rows[i]>=sum(r[i])for i in range(109))
assert all(r[i][108]==r[108][i]for i in range(109))
a=sum(abs(w[i]*w[j])*r[i][j]for i in range(108)for j in range(108))
b=sum(abs(w[i])*r[i][108]for i in range(108))
ed=[[sum(t[i]**2*rows[i]for i in range(109)),-rows[108]],[-rows[108],rows[108]]]
assert Q(d['old_recorded_witness_interval'][0])<=ed[0][0]<=Q(d['old_recorded_witness_interval'][1])
E=[[Q(x)for x in row]for row in d['total_error_on_t_e']]
Er=[[E[i][j]-ed[i][j]for j in range(2)]for i in range(2)]
def psd(A):return A[0][0]>=0 and A[1][1]>=0 and A[0][0]*A[1][1]>=A[0][1]**2
assert psd(Er)
c=Q(707106781186547525,10**18);assert 2*c*c>1
eNew=[[a+3*c*b,-c*b],[-c*b,c*b]]
Enew=[[Er[i][j]+eNew[i][j]for j in range(2)]for i in range(2)]
assert psd(eNew) and psd(Enew)
# Check every alpha,beta vertex against the optional common 2x2 majorant.
for aa in [-a,a]:
 for bb in [-b,b]:
  A=[[aa-2*bb,bb],[bb,Q(0)]]
  for sign in [-1,1]:assert psd([[eNew[i][j]-sign*A[i][j]for j in range(2)]for i in range(2)])
expected=json.loads((H/'DIRECT_BLOCK_RESULT.json').read_text())
assert a==Q(expected['alpha_abs_upper']['rational']) and b==Q(expected['beta_abs_upper']['rational'])
for name,A in [('old_direct_error_on_t_e',ed),('unchanged_other_error_on_t_e',Er),('new_direct_common_PSD_error_on_t_e',eNew),('new_total_common_PSD_error_on_t_e',Enew)]:
 assert A==[[Q(v['rational'])for v in row]for row in expected[name]]
with localcontext()as ctx:
 ctx.prec=20
 def show(x):return str(Decimal(x.numerator)/Decimal(x.denominator))
 print(json.dumps({'status':'EXACT_DIRECT_BLOCK_PASS','alpha_abs_upper':show(a),'beta_abs_upper':show(b),
    'old_total_Ett':show(E[0][0]),'new_total_Ett':show(Enew[0][0]),
    'scope':'New arithmetic-direct error block only; all other source/physical prices retained.'},indent=2))
