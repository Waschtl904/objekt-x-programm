#!/usr/bin/env python3
"""One correlated direct-pairing refinement; no new source evaluations."""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import product
from pathlib import Path
from math import isqrt
import json, hashlib, sys
sys.set_int_max_str_digits(0)
HERE=Path(__file__).resolve().parent
ip=HERE/'original_20261109/budget/carrier_recombination/SHARP_BUDGET_INPUTS.json'
rp=HERE/'gpt2/DIRECT_BLOCK_RESULT.json'
j=json.loads(ip.read_text()); r=json.loads(rp.read_text())
def dec(x):
    with localcontext()as c:
        c.prec=30
        return str(Decimal(x.numerator)/Decimal(x.denominator))
def pack(x):
    if isinstance(x,F):return {'rational':str(x),'decimal_display':dec(x)}
    if isinstance(x,list):return [pack(a)for a in x]
    if isinstance(x,dict):return {k:pack(a)for k,a in x.items()}
    return x
def up(x,places=80):
    scale=10**places
    return F(-((-x.numerator*scale)//x.denominator),scale)
def sqrtup(x):
    scale=10**80
    n=isqrt(x.numerator*scale*scale//x.denominator)
    if F(n*n,scale*scale)<x:n+=1
    return F(n,scale)
E=[[F(v['rational'])for v in row]for row in r['unchanged_other_error_on_t_e']]
M=[[F(v)for v in row]for row in j['M_on_t_e']]
D=[[F(v)for v in row]for row in j['D']]; k=F(j['k'])
d=D[0][0];e=D[0][1]-k*d;f=D[1][1]-2*k*D[0][1]+k*k*d
aa=up(F(r['alpha_abs_upper']['rational']))
bb=up(F(r['beta_abs_upper']['rational']))
# Loewner +-E implies this entry box. It is a conservative superset;
# the common alpha/beta dependence is retained exactly within it.
rtt=up(E[0][0]);rte=sqrtup(E[0][0]*E[1][1]);ree=up(E[1][1])
boxes=[[-aa,aa],[-bb,bb],[-rtt,rtt],[-rte,rte],[-ree,ree],
       list(map(F,j['rank']['b14'])),list(map(F,j['X']['X12'])),list(map(F,j['X']['X22']))]
R1,R2=F('1e-5'),F('0.1')
rows=[]
for alpha,beta,dt,db,de,c,y,z in product(*boxes):
    mt=M[0][0]+alpha-2*beta+dt
    b=M[0][1]+beta+db;me=M[1][1]+de
    V=-mt;xx=-me;tau=2*b-V-xx;delta=V-b;bk=c-k*b;z2=bk-y
    A=d-V;B=e-bk;C=f-z
    def det(A,C):return A*(C*tau-z2*z2)-B*B*tau+2*B*delta*z2-C*delta*delta
    p1=tau*A-delta*delta
    det0=det(A,C);detTarget=det(A-R1,C-R2)
    p23=(C-R2)*tau-z2*z2
    assert tau>0 and p1>0 and det0>0 and p23>0
    rows.append((tau,p1,det0,detTarget,det(A,C-R2)/p23))
limit=min(a[4]for a in rows)
# Directed decimal capacity, derived from the same single affine block.
capacity=F((limit*10**12).__floor__(),10**12)
assert 0<capacity<limit
res=pack({'status':'POSITIVE_BUDGET_FROM_DIRECT_PRIMITIVE_CONTRACTION',
    'scope':'Inherited physical contracts retained; finite affine 3x3 block. No complete physical remainder claimed.',
    'vertices':len(rows),'alpha_abs_upper_used':aa,'beta_abs_upper_used':bb,
    'unchanged_error_entry_radii':[rtt,rte,ree],
    'tau_lower':min(a[0]for a in rows),'first_schur_numerator_lower':min(a[1]for a in rows),
    'zero_remainder_det3_lower':min(a[2]for a in rows),
    'user_target_det3_lower_in_entry_box':min(a[3]for a in rows),
    'user_target_certified_by_this_superset_box':all(a[3]>0 for a in rows),
    'R22_fixed_for_capacity':R2,'R11_vertex_capacity_infimum':limit,
    'strict_directed_R11_capacity':capacity,
    'capacity_statement':'Every PSD Rhat <= diag(strict_directed_R11_capacity, 0.1) is carried uniformly by the refined bank enclosure. This is a budget, not an attained physical remainder bound.',
    'proof':'All 256 vertices of the conservative primitive entry box give a positive affine 3x3 block at R=0. For fixed R22=0.1 its positive (2,3) subblock gives the displayed exact R11 capacity. Convexity extends both certificates to the entire box.',
    'new_integrations':0,'new_inversions':0,'q_reoptimizations':0,
    'input_sha256':{ip.name:hashlib.sha256(ip.read_bytes()).hexdigest(),rp.name:hashlib.sha256(rp.read_bytes()).hexdigest()}})
(HERE/'REFINED_BUDGET_RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({k:(v.get('decimal_display')if isinstance(v,dict)and'decimal_display'in v else v)for k,v in res.items()if k not in ['input_sha256','proof','unchanged_error_entry_radii']},indent=2))
