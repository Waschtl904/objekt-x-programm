"""One 109-source physical error ledger for the frozen new comparison.

Retains the conservative actual-B h/g bridge, adding B-B0 explicitly.
No quadrature, candidate change, or final physical inverse claim here.
"""
from common_core_source_price import *

def main():
    started=time.monotonic();v=build(model_only=True,gamma_reserve=True)
    e=v['e'];C=v['C'];co=v['co'];oc=v['oc'];ga=v['ga'];sub=v['sub']
    gamma=e.w['gamma'];rho=e.w['rho'];s=1-rho;d=q('19/10');d1=q('1.84298')
    n=109
    def cat(AA):return arb_mat([[A[i,j]for A in AA for j in range(A.ncols())]for i in range(AA[0].nrows())])
    def mid(A):return arb_mat([[A[i,j].mid()for j in range(A.ncols())]for i in range(A.nrows())])
    def upper(A):
        A=(A+A.transpose())/2;R=mid(A)
        for i in range(R.nrows()):R[i,i]+=sum((A[i,j].rad()for j in range(R.nrows())),arb(0)).upper()
        return R
    def block(items,size=n):
        A=arb_mat(size,size)
        for k,X in items:
            for i in range(X.nrows()):
                for j in range(X.ncols()):A[k+i,k+j]=X[i,j]
        return A
    def emb(A,k):return block([(k,upper(A))])
    def col(A,j=0):return sub(A,range(A.nrows()),[j])
    def crossfill(A,i,j,X):
        for k in range(X.nrows()):
            for l in range(X.ncols()):A[i+k,j+l]=A[j+l,i+k]=X[k,l]
    def zquad(A,x):return (x.transpose()*A*x)[0,0]
    def norm(A):return trace(A.transpose()*A).upper().sqrt()
    G=WS/'work/common-form-gain-review-2026-11-01/gpt1-original'
    P=WS/'work/stronger-form-inventory-2026-11-01'
    src=read(HERE/'bound-source-inputs/FINITE_MODEL_FUNCTIONALS.json')
    rec=read(HERE/'bound-source-inputs/FINITE_RECOMBINATION_DATA.json')
    force=read(WS/'work/new-block-energy-2026-11-01/inputs/FORCE_NORM.json');fq=force['quantities']
    inv=read(G/'inputs/INVERSE_DATA.json');known=read(G/'inputs/KNOWN_INPUTS.json')
    B=matrix(inv['input_basis_B']);Y=matrix(inv['test_columns_Y']);Cg=matrix(known['metric_C_G']);Cgi=Cg.inv()
    Knew=matrix(inv['K_new']);Ki=Knew.inv();assert pos(Knew)[0]
    Kold=matrix(inv['K_old']);Korder=pos(Knew-Kold)
    proof=read(HERE/'MODEL_COUPLING_CORE.json');Gup=matrix(proof['G0_upper_integer'])/q(proof['G0_upper_denominator'])
    low=read(P/'inputs/LOW_SCHUR_CERTIFICATE.json');HB=matrix(low['HB1_integer'])/q(low['HB1_denominator'])
    LP=C.transpose()*(matrix(low['F1_rational'])+HB/q('1.8219')+(q('7e-40')-q(proof['physical_low_defect_price']))*eye(191)-Gup/d)*C
    assert pos(LP)[0];Li=LP.inv();X=C*Li*C.transpose()
    phi=boxes(src['Phi_g']);ag=boxes(force['force_model'])
    bg=d1*(phi-C.transpose().solve(s.sqrt()*ag))
    cs=cat([boxes(oc['source_c_model']),boxes(ga['old_low_c_model']),e.ell*B,phi])
    bs=cat([boxes(oc['source_Bh_model']),boxes(ga['old_low_Bh_model']),e.By*B,bg])
    rawcs=cs;rawbs=bs
    cs=mid(cs);bs=mid(bs)
    V=C.transpose()*(cs-bs/d);ul=C*Li*V
    vg=(d1/d)*s.sqrt()*mid(ag)+(1-d1/d)*C.transpose()*mid(phi)
    for i in range(191):V[i,108]=vg[i,0]
    ul=C*Li*V
    # The complete high Gram: F/J and h/g use their inherited raw-to-high identities.
    rawF=boxes(src['raw_FJ']);rawHB=boxes(src['raw_hB']);geo={k:box(z)for k,z in rec['geometry'].items()}
    mc=box(fq['moment_mc']);ehg=box(fq['eh']);eg=box(fq['core_source_error']).upper()
    ehplus=cat([e.eh*B,arb_mat([[ehg]])]);ellplus=cat([e.ell*B,phi])
    hrawg=2*(col(rawHB)-mc/geo['mu8']*col(rawHB,1))
    Hraw=block([(0,B.transpose()*e.H*B),(12,arb_mat([[box(fq['projected_core_norm'])**2]]))],13)
    crossfill(Hraw,0,12,hrawg)
    gh=Hraw+gamma*ehplus.transpose()*ehplus-ellplus.transpose()*ellplus
    # h-h has a tighter independently directed high-Gram integral.
    HH=B.transpose()*boxes(e.data['high_Gram'])*B
    for i in range(12):
        for j in range(12):gh[i,j]=HH[i,j]
    gh[12,12]=box(fq['whole_Theta_norm'])**2
    oldlow=boxes(rec['old_low_FJ'])
    ef=geo['scale']*col(rawF,2)-geo['me']/geo['mu8']*col(rawF,1)
    Fg=2*(col(rawF)-mc/geo['mu8']*col(rawF,1))+gamma*ehg*ef-oldlow.transpose()*phi
    HG=block([(0,v['HG']),(108,arb_mat([[gh[12,12]]]))])
    # Restore full old intervals rather than v['HG'] model midpoints.
    hc=boxes(e.data['high_cross_models'])
    for off,A in [(0,boxes(oc['source_h_gram_model'])),(12,boxes(ga['H84_model'])*q('91/50')),(96,HH)]:
        for i in range(A.nrows()):
            for j in range(A.ncols()):HG[off+i,off+j]=A[i,j]
    crossfill(HG,0,12,boxes(ga['complete_source_high_cross_model']))
    crossfill(HG,0,96,sub(hc,range(191,203),range(12))*B)
    crossfill(HG,12,96,sub(hc,range(203,287),range(12))*B)
    crossfill(HG,0,108,Fg);crossfill(HG,96,108,sub(gh,range(12),[12]))
    HGinterval=HG;HG=mid(HG)
    U=HG/d+V.transpose()*Li*V
    bare=boxes(src['bare_FJ']);barez=boxes(src['bare_z'])
    for i in range(4):bare[i,0]+=barez[i,0]
    for i in range(92):bare[i+4,0]-=2*box(rec['old_lam92'][i])*mc/geo['mu8']
    direct=read(HERE/'bound-source-inputs/DIRECT12_RESULT.json')
    k=boxes(direct['dB'])-boxes(src['P0_g'])
    D=(boxes(v['common']['D96_lower_model'])+boxes(v['common']['D96_upper_model']))/2
    kd=read(P/'inputs/REFINED_K_MATRIX.json');K=B.transpose()*boxes(kd['matrices']['K_computational_interval'])*B
    directM=block([(0,D),(96,K)]);crossfill(directM,0,96,boxes(e.data['bare_F_J_pairs'])*B)
    crossfill(directM,0,108,bare);crossfill(directM,96,108,k)
    directInterval=directM;directM=mid(directM)
    M=directM-U;M=(M+M.transpose())/2
    w=read(HERE/'MODEL_COUPLING_RITZ_WITNESS.json');y=matrix(w['shell96_rational']);c=B.solve(matrix(w['outer12_raw_rational']))
    t=arb_mat([[y[i,0]if i<96 else c[i-96,0]if i<108 else -1]for i in range(n)])
    TF=arb_mat([[int(i==j)]for i in range(n)for j in []]) if False else arb_mat(n,12)
    for j in range(12):TF[j,j]=1
    TL=arb_mat([[-Y[i,j]if i<96 else int(i-96==j)if i<108 else 0 for j in range(12)]for i in range(n)])
    # One explicit allocation weight; this only allocates valid Young prices.
    Weight=t*t.transpose()+100*TF*Ki*TF.transpose()+TL*Cgi*TL.transpose()
    E=arb_mat(n,n);prices={};parameters={}
    def charge(name,A):
        nonlocal E
        A=upper(A);E+=A
        prices[name]={'witness':endpoints(zquad(A,t)),
                      'Fo_trace':endpoints(trace(Ki*TF.transpose()*A*TF)),
                      'lift_trace':endpoints(trace(Cgi*TL.transpose()*A*TL))}
    def cross(name,A,B):
        wa=trace(Weight*A);wb=trace(Weight*B)
        assert wa>0 and wb>0,(name,str(wa),str(wb))
        lam=(wb/wa).sqrt().mid();parameters[name]=str(lam.fmpq())
        charge(name,lam*A+B/lam)
    def interval_gram_radius(A):
        R=arb_mat(A.nrows(),A.ncols())
        for i in range(A.nrows()):R[i,i]=sum((A[i,j].rad()for j in range(A.ncols())),arb(0)).upper()
        return R
    ledger=read(G/'inputs/SOURCE_BLOCK_LEDGER_V2.json');EcF=boxes(oc['joint_low_source_error_gram'])
    sharp=boxes(ledger['sharpening']['new_physical_z_source_error_gram'])
    for i in range(4):
        for j in range(4):EcF[i,j]=2*gamma*sharp[i,j]
    EcJ=gamma*box(ga['source_model_error_norm'])**2*eye(84)
    EhF=boxes(oc['joint_high_source_error_gram']);EhJ=box(ga['high_source_error_norm'])**2*eye(84)
    Eplus=2*block([(0,e.eResidual**2*B.transpose()*e.G*B),(12,arb_mat([[eg**2]]))],13)
    Ecplus=gamma*Eplus;Ehplus=gamma*Eplus
    # Current raw h-g integrals and historical h-h integrals use two frozen
    # T midpoints. Both are enclosed around the same physical T. Pay their
    # model difference explicitly, even though it is much smaller than the
    # principal physical h-source error.
    finite_contract=read(HERE/'bound-source-inputs/FINITE_ERROR_CONTRACT.json')
    T_reference_error=2*box(finite_contract['eResidual_components']['frozen_T_Hilbert']).upper()
    Ereference=T_reference_error*box(fq['projected_core_norm']).upper()*block([(0,B.transpose()*e.G*B),(12,eye(1))],13)
    GR96=upper(sub(HGinterval,range(96),range(96)));GRplus=upper(gh)+Ereference
    Eh96=2*block([(0,EhF),(12,EhJ)],96)
    for name,off,Gram,Err in [('old96_high',0,GR96,Eh96),('h_g_high',96,GRplus,Ehplus)]:
        cross(name+'_linear',emb(Gram,off)/d,emb(Err,off)/d);charge(name+'_square',emb(Err,off)/d)
    charge('h_g_frozen_T_reference_bridge',emb(Ereference,96)/d)
    rawplus=2*(upper(Hraw+gamma**2*ehplus.transpose()*ehplus)+Ereference)
    for name,off,num,rawerr,Ec,Eh in [('F',0,12,e.eRawF,EcF,EhF),('J',12,84,e.eRawJ,EcJ,EhJ)]:
        Gram=upper(sub(HG,range(off,off+num),range(off,off+num)))
        cross(name+'_h_g_raw_high',emb(rawerr**2*eye(num),off)/d,emb(rawplus,96)/d)
        cross(name+'_h_g_low_projection',emb(Ec,off)/d,emb(ellplus.transpose()*ellplus,96)/d)
        cross(name+'_h_g_physical',emb(2*(Gram+Eh),off)/d,emb(Ehplus,96)/d)
    Qul=upper(ul.transpose()*ul);QBu=upper(ul.transpose()*Gup*ul);Ev=[]
    for name,off,Ec,Eh in [('F',0,EcF,EhF),('J',12,EcJ,EhJ),('h_g',96,Ecplus,Ehplus)]:
        ce=emb(Ec,off);he=emb(Eh,off)
        cross(name+'_low_source',Qul,ce)
        cross(name+'_high_source_in_B0',QBu/d**2,he)
        Ev.extend([ce,trace(Gup)*he/d**2])
    eb=box(oc['old_coupling_error_norm']).upper()
    # Preserve actual-B bridge for h/g, then add the full B-B0 high-vector price.
    EBactual=2*(e.eRawA**2*rawplus+e.eLowA**2*upper(ellplus.transpose()*ellplus))
    EBnew=2*EBactual+2*eb**2*GRplus
    be=emb(EBnew,96)/d**2;cross('h_g_actual_B_plus_B_minus_B0',Qul,be);Ev.append(be)
    # Numerical low-pairing radii are contracted against the actual response;
    # an interval evaluation of a preconditioned full Gram loses this dependence.
    for name,A,scale in [('c_quadrature',rawcs,arb(1)),('Bh_quadrature',rawbs,1/d)]:
        err=arb_mat(n,n)
        for off,num in [(0,12),(12,84),(96,12)]:
            for j in range(off,off+num):err[j,j]=3*num*sum((A[i,j].rad()**2 for i in range(191)),arb(0))*scale**2
        cross(name,Qul,err);Ev.append(err)
    vg_interval=(d1/d)*s.sqrt()*ag+(1-d1/d)*C.transpose()*phi
    vg_rad=norm(arb_mat([[vg_interval[i,0].rad()]for i in range(191)]))
    zpre=Li*V
    cross('g_force_saved_interval',upper(zpre.transpose()*zpre),emb(arb_mat([[vg_rad**2]]),108))
    # The factor two includes every mixed product between the saved g-force
    # interval and the other physical/numerical low-source perturbations.
    charge('g_force_interval_second_variation',2*emb(arb_mat([[trace(Li)*vg_rad**2]]),108))
    charge('low_source_second_variation',2*len(Ev)*trace(X)*sum(Ev,arb_mat(n,n)))
    charge('high_Gram_saved_interval',interval_gram_radius(HGinterval)/d)
    charge('direct_pairing_saved_interval',interval_gram_radius(directInterval))
    # Direct and bare pairings retain the physical error contracts.
    ED=boxes(read(P/'inputs/DIRECT_D_TRANSPORT.json')['matrices']['D_error_upper']);charge('direct_D',emb(ED,0))
    EK=box(kd['total_uniform_error']).upper()*B.transpose()*boxes(kd['matrices']['G_W'])*B;charge('direct_K',emb(EK,96))
    for name,off,num,er,fsq in [('F',0,12,e.eBareF,q(256)),('J',12,84,e.eBareJ,q('1.000502'))]:
        cross(name+'_bare_h_coordinates',emb(er**2*eye(num),off),emb(2*B.transpose()*(boxes(e.data['H9_Gram'])+e.eResidual**2*e.G)*B,96))
        cross(name+'_bare_h_physical',emb(fsq*eye(num),off),emb(e.eResidual**2*B.transpose()*e.G*B,96))
        # Same already bound whole source, before applying any new response.
        gb=q(32);eg9=2*eg
        eg_bare=(er*(gb+eg9)+fsq.sqrt()*eg9).upper()
        cross(name+'_bare_g',emb(eye(num),off),emb(arb_mat([[eg_bare**2]]),108))
    # The tiny P0-g model transport is separated, not hidden in an interval.
    # A fresh coefficient/norm audit must prove this deliberately generous cap.
    p0g=q('1e-20')
    # Covector error in B coordinates, so metric B^{-T}B^{-1} in raw c coordinates.
    transport=read(HERE/'WHOLE_PHYSICAL_TRANSPORT.json')['quantities']
    assert box(transport['same_g9_norm_cap']).upper()<=gb
    assert box(transport['same_g9_Hilbert_model_error']).upper()<eg9
    assert box(transport['P0_g_B_covector_error_cap_from_inherited_parts']).upper()<p0g
    cross('P0_g_physical_model_transport',emb(eye(12),96),emb(arb_mat([[p0g**2]]),108))
    arithmetic=max(sum((M[i,j].rad()for j in range(n)),arb(0)).upper()for i in range(n))
    assert arithmetic<q('1e-150')
    charge('finite_Arb_arithmetic',q('1e-150')*eye(n));M=mid(M)
    assert all(M[i,j]==M[j,i]for i in range(n)for j in range(n))
    Lmodel=-zquad(M,t);Ew=zquad(E,t).upper()
    rf=-TF.transpose()*M*t;rl=-TL.transpose()*M*t
    efo=trace(Ki*TF.transpose()*E*TF).upper();el=trace(Cgi*TL.transpose()*E*TL).upper()
    fo_model=zquad(Ki,rf).upper().sqrt();lift_model=zquad(Cgi,rl).upper().sqrt()
    fo=fo_model+(efo*Ew).sqrt();lift=lift_model+(el*Ew).sqrt()
    quantities={'model_variational_value':Lmodel,'whole_physical_ledger_on_witness':Ew,
        'variational_upper_before_pending_caps':Lmodel.upper()+Ew,'Fo_error_trace':efo,'lift_error_trace':el,
        'Fo_model_interval_residual_norm':fo_model,'lift_model_interval_residual_norm':lift_model,
        'Fo_residual_norm_before_pending_caps':fo,'lift_residual_norm_before_pending_caps':lift,
        'finite_residual_energy_before_whole_T_and_pending_caps':q('20/19')*(101*fo**2+lift**2),
        'direct_budget_lower':q(known['direct_lower'])}
    out={'status':'FRESH_COMMON_109_SOURCE_LEDGER_PENDING_INTERFACE_AND_SMALL_CAP_AUDIT',
         'quantities':{k:endpoints(z)for k,z in quantities.items()},'display_only':{k:float(z.mid())for k,z in quantities.items()},
         'prices':prices,'exact_positive_Young_parameters':parameters,
         'K_new_minus_K_old_positive':Korder,'new_quadratures':0,'original_answer_changed':False,
         'pending':['written audit of same-model h/g raw-to-high assembly and model-interval covariance',
                    'whole T physical residual and complete directed model norm'],
         'physical_inverse_upper_claimed':False,'bindings':bindings}
    (HERE/'COMMON_FULL_LEDGER.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    for key,z in quantities.items():print(key,float(z.mid()),flush=True)
    print('seconds',time.monotonic()-started,flush=True)

if __name__=='__main__':main()
