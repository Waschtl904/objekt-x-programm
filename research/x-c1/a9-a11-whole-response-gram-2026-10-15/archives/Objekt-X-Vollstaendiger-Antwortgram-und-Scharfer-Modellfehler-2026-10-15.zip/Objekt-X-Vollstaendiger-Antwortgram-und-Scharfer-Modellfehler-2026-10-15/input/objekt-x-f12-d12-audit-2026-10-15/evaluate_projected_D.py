"""Evaluate the exactly moment-projected stored D model with directed intervals.
The correction coefficient is defined by an exact moment integral; its saved
interval encloses that number. Its midpoint is NOT used as an exact projection.
This is an interval for a MODEL, not a pointwise enclosure of the true A9 Phi.
"""
from pathlib import Path
from fractions import Fraction as Q
import argparse,hashlib,json
from independent_check import I,logq,logi,need

def expi(x):
    x=I(x);term=I(1);v=I(1)
    for k in range(1,300):term=term*x/k;v=v+term
    tail=term*x/300/(1-x/301)
    return I(v.low,v.high+tail.high)
def poly(a,x):
    v=I(0)
    for c in reversed(a):v=v*x+Q(c)
    return v

def value(source,budget,parity,index,fraction):
    whole=json.loads((source/'FUNCTIONS12.json').read_bytes())
    b=json.loads(budget.read_bytes());spec=whole['parities'][parity]['functions'][index]['D']
    a=logq(Q(3));t=I(Q(fraction));need(0<t.low and t.high<1,'interior fraction required')
    p=0 if parity=='even' else 1
    exp=expi(a*t/2);m=(exp+(-1)**p/exp)/2
    v=poly(spec['polynomial'],t)+poly(spec['V_multiplier'],t)*(-logi(1-t*t)/2)+Q(spec['moment_multiplier'])*m
    for row in spec['shift_terms']:
        sh=logq(Q(row['channel']))/a
        lo,hi=(I(0),1-sh) if row['translation_sign']==1 else ((I(0) if row['channel'] in (2,3) else sh-1),I(1))
        q=poly(row['polynomial'],t)
        if t.low>lo.high and t.high<hi.low:v=v+q
        elif t.high>=lo.low and t.low<=hi.high:v=v+I(min(Q(0),q.low),max(Q(0),q.high))
    alpha=I(*map(Q,b['parities'][parity]['projected_model_coefficients'][index]['alpha_interval']))
    v=(v-alpha*m)/(2*a).sqrt()
    return {'projected_D_model_value_interval':v.pair(),'projection_definition':'Pi_a D_tilde with the exact old moment projection',
            'pointwise_true_D_enclosure_claimed':False,'whole_true_D_to_projected_model_error_upper':b['parities'][parity]['delta_D']}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--budget',type=Path,required=True)
    p.add_argument('--parity',choices=['even','odd'],required=True);p.add_argument('--index',type=int,choices=range(12),required=True);p.add_argument('--fraction',required=True)
    a=p.parse_args();print(json.dumps(value(a.source,a.budget,a.parity,a.index,a.fraction),indent=2))
