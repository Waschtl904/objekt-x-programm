"""Independent coefficient/whole-function audit, standard library only.

No imports of any source-package modules. Fixed-point directed arithmetic,
Rodrigues coefficients, Euler/Bernoulli kernel coefficients, and a distinct
moment Taylor degree (180). Numerical tests do not replace the analytic proof.
"""
from __future__ import annotations
from fractions import Fraction as Q
from math import comb, factorial, isqrt
from pathlib import Path
import argparse, hashlib, json

DIGITS=300
SCALE=10**DIGITS

def need(ok, text):
    if not ok: raise ValueError(text)
def ceil(a,b): return -((-a)//b)
class I:
    __slots__=('l','u')
    def __init__(self, lo=0, hi=None):
        if isinstance(lo,I) and hi is None: self.l,self.u=lo.l,lo.u; return
        lo=Q(lo);hi=lo if hi is None else Q(hi)
        self.l=lo.numerator*SCALE//lo.denominator
        self.u=ceil(hi.numerator*SCALE,hi.denominator)
        need(self.l<=self.u,'empty interval')
    @classmethod
    def raw(cls,l,u):
        need(l<=u,'empty interval');x=object.__new__(cls);x.l=l;x.u=u;return x
    @property
    def low(self): return Q(self.l,SCALE)
    @property
    def high(self):return Q(self.u,SCALE)
    def __neg__(self):return I.raw(-self.u,-self.l)
    def __add__(self,y):
        y=I(y);return I.raw(self.l+y.l,self.u+y.u)
    __radd__=__add__
    def __sub__(self,y):return self+(-I(y))
    def __rsub__(self,y):return I(y)+(-self)
    def __mul__(self,y):
        y=I(y);v=[self.l*y.l,self.l*y.u,self.u*y.l,self.u*y.u]
        return I.raw(min(v)//SCALE,ceil(max(v),SCALE))
    __rmul__=__mul__
    def __truediv__(self,y):
        y=I(y);need(not y.l<=0<=y.u,'interval zero division')
        v=[Q(a*SCALE,b) for a in (self.l,self.u) for b in (y.l,y.u)]
        return I.raw(min(v).numerator//min(v).denominator,ceil(max(v).numerator,max(v).denominator))
    def __rtruediv__(self,y):return I(y)/self
    def __pow__(self,n):
        need(isinstance(n,int) and n>=0,'power');p=I(1);x=self
        while n:
            if n&1:p=p*x
            x=x*x;n//=2
        return p
    def sqrt(self):
        need(self.l>=0,'sqrt');l=isqrt(self.l*SCALE);u=isqrt(self.u*SCALE)
        return I.raw(l,u+(u*u<self.u*SCALE))
    def pair(self):return [str(self.low),str(self.high)]

def up(x):x=I(x);return max(abs(x.low),abs(x.high))
def inf(x,r):x=I(x);return I(x.low-r,x.high+r)
def logq(x):
    x=Q(x);need(x>0,'log')
    k=0
    while x<1:x*=2;k-=1
    while x>2:x/=2;k+=1
    def reduced(v):
        t=I((v-1)/(v+1));t2=t*t;term=t;s=I(0)
        for j in range(360):s=s+term/(2*j+1);term=term*t2
        rem=2*term/(721*(1-t2))
        return I((2*s).low,(2*s).high+rem.high)
    return reduced(x)+k*reduced(Q(2))
def logi(x):x=I(x);return I(logq(x.low).low,logq(x.high).high)
def pi_interval():
    def atan(x,n):
        t=x;s=Q(0)
        for j in range(n):s+=(-1)**j*t/(2*j+1);t*=x*x
        e=(-1)**n*t/(2*n+1);return I(min(s,s+e),max(s,s+e))
    return 16*atan(Q(1,5),290)-4*atan(Q(1,239),92)
def bernoulli(n):
    # Akiyama-Tanigawa; B1=+1/2, irrelevant for the even coefficients used here.
    a=[];b=[]
    for m in range(n+1):
        a.append(Q(1,m+1))
        for j in range(m,0,-1):a[j-1]=j*(a[j-1]-a[j])
        b.append(a[0])
    return b

def powers(x,n):
    y=[I(1)]
    for _ in range(n):y.append(y[-1]*x)
    return y

def rod(n):
    a=[Q(0)]*(n+1)
    for j in range(n//2+1):a[n-2*j]=Q((-1)**j*factorial(2*n-2*j),2**n*factorial(j)*factorial(n-j)*factorial(n-2*j))
    return a

def add(a,b):return [(a[k] if k<len(a) else I(0))+(b[k] if k<len(b) else I(0)) for k in range(max(len(a),len(b)))]
def mul_scalar(a,s):return [I(v)*s for v in a]
def dot(a,b):return sum((I(x)*y for x,y in zip(a,b)),I(0))
def absolute(a,r=Q(1)):return sum((up(x)*r**j for j,x in enumerate(a)),Q(0))
def shift(poly,s):
    # Horner polynomial composition with (t+s), not a monomial binomial shift.
    out=[I(0)]
    for c in reversed(poly):
        old=out;out=[I(0)]*(len(old)+1)
        for j,x in enumerate(old):out[j]=out[j]+s*x;out[j+1]=out[j+1]+x
        out[0]=out[0]+c
    return out[:len(poly)]
def monomial_integrals(lo,hi,n):
    lp=powers(lo,n+1);hp=powers(hi,n+1)
    return [(hp[j+1]-lp[j+1])/(j+1) for j in range(n+1)]
def log_potential_integral(n,ln2):
    need(n%2==0,'odd product in V moment')
    # H_{2r+2} - H_{r+1}/2 is the sum of odd reciprocals through 2r+1.
    r=n//2
    h2=sum((Q(1,j) for j in range(1,2*r+3)),Q(0))
    h1=sum((Q(1,j) for j in range(1,r+2)),Q(0))
    return (h2-h1/2-ln2)/(n+1)
def log_ratio_moments(R,n):
    """Integrate in w=v-1; derivative of log ratio is -2/(v^2-1).
    Integration by parts with primitive (v^(n+1)-1)/(n+1),
    followed by exact division by (v^2-1), treats v=1 analytically.
    """
    out=[];pr=powers(R,n+1);L=logi((R+1)/(R-1));ln2=logq(Q(2))
    for j in range(n+1):
        # (v^(j+1)-1)/(v-1)=sum_{k=0}^j v^k.
        # Divide that polynomial by v+1, collecting its remainder.
        q=[Q(1)]*(j+1);coeff=[Q(0)]*max(1,j)
        for k in range(j,0,-1):coeff[k-1]=q[k];q[k-1]-=q[k]
        integ=sum((c*(pr[k+1]-1)/(k+1) for k,c in enumerate(coeff)),I(0))
        integ=integ+q[0]*(logi(R+1)-ln2)
        out.append(((pr[j+1]-1)*L+2*integ)/(j+1))
    return out

def kernel_coefficients(M):
    bs=bernoulli(M+2)
    en=[0]*(M+1);en[0]=1
    for n in range(2,M+1,2):en[n]=-sum(comb(n,j)*en[j] for j in range(0,n,2))
    sech=[Q(en[n],factorial(n)) if n%2==0 else Q(0) for n in range(M+1)]
    sinv=[Q(0)]*(M+2)
    for n in range(0,M+2,2):sinv[n]=(2-2**n)*bs[n]/factorial(n)
    g=[(sech[n]+sinv[n+1])/4 for n in range(M+1)]
    D=M+20
    def defect(p,den):
        out=[Q(0)]*(len(p)+len(den)-1)
        for i in range(0,len(p),2):
            for j in range(0,len(den),2):out[i+j]+=p[i]*den[j]
        out[0]-=1;return out
    c=[Q(1,factorial(n)) if n%2==0 else Q(0) for n in range(D+1)]
    s=[Q(1,factorial(n+1)) if n%2==0 else Q(0) for n in range(D+1)]
    dc=defect(sech,c);ds=defect(sinv,s)
    need(all(x==0 for x in dc[:M+1]),'Euler reciprocal identity')
    need(all(x==0 for x in ds[:M+2]),'Bernoulli reciprocal identity')
    r=Q(6,5)
    fc=sum((abs(x)*r**j for j,x in enumerate(dc)),Q(0))
    fs=sum((abs(x)*r**(j-1) for j,x in enumerate(ds) if j),Q(0))
    nc=sum((abs(x)*r**j for j,x in enumerate(sech)),Q(0))
    ns=sum((abs(x)*r**j for j,x in enumerate(sinv)),Q(0))
    tc=r**(D+2)/factorial(D+2)/(1-r*r/((D+3)*(D+4)))
    ts=r**(D+1)/factorial(D+3)/(1-r*r/((D+4)*(D+5)))
    return g,(fc+fs+nc*tc+ns*ts)/4,bs

def actions(P, weights):
    """Full monomial split formula, without a parity-optimised input routine."""
    M=len(weights)-1;N=len(P)-1
    moms=[sum((x/(j+r+1) for j,x in enumerate(P)),I(0)) for r in range(M+1)]
    signm=[sum(((-1)**j*x/(j+r+1) for j,x in enumerate(P)),I(0)) for r in range(M+1)]
    inside=[I(0)]*(M+N+2);outside=[I(0)]*(M+1)
    for k,w in enumerate(weights):
        for l in range(k+1):
            q=w*comb(k,l)
            inside[l]=inside[l]+q*((-1)**l*moms[k-l]+signm[k-l])
            # integral_-1^1 u^(k-l) P(u): original half moments combined with reflection
            outside[l]=outside[l]+q*((-1)**(k-l)*moms[k-l]+signm[k-l])
        if k%2:
            for j,x in enumerate(P):
                if up(x):inside[k+j+1]=inside[k+j+1]+w*x*Q(2*factorial(k)*factorial(j),factorial(k+j+1))
    return inside,outside

def coeff_distance(poly,saved,r=Q(1)):
    need(len(poly)<=len(saved) or all(up(x)==0 for x in poly[len(saved):]),'coefficient length')
    return sum((up((poly[j] if j<len(poly) else I(0))-Q(v))*r**j for j,v in enumerate(saved)),Q(0))
def strict_ldl(a):
    b=[r[:] for r in a];pv=[]
    for k in range(len(b)):
        d=b[k][k];need(d>0,'nonpositive rational pivot');pv.append(str(d))
        for i in range(k+1,len(b)):
            for j in range(i,len(b)):
                v=b[i][j]-b[i][k]*b[j][k]/d;b[i][j]=v;b[j][i]=v
    return pv

def run(src:Path,out:Path):
    data=json.loads((src/'FUNCTIONS12.json').read_bytes());fresh=json.loads((src/'FRESH_A12.json').read_bytes())
    manifest=json.loads((src/'MANIFEST.json').read_bytes())
    for path,digest in manifest.items():need(hashlib.sha256((src/path).read_bytes()).hexdigest()==digest,path)
    print('Independent Euler/Bernoulli kernel and constants ...',flush=True)
    M=320;MT=180
    g,eps,bs=kernel_coefficients(M)
    need(eps==Q(data['kernel_error_exact']),'exact kernel error')
    logs={q:logq(Q(q)) for q in (2,3,5,7,11)};logs[4]=2*logs[2];logs[8]=3*logs[2];logs[9]=2*logs[3]
    a=logs[3];b=logs[11]/2;R=b/a;z=a/2
    pi=pi_interval()
    # Different Euler expansion point/length from the supplied N=256,m=80.
    N=1024;K=100
    eg=I(sum((Q(1,j) for j in range(1,N+1)),Q(0)))-logq(Q(N))-Q(1,2*N)
    for k in range(1,K):eg=eg+bs[2*k]/(2*k*N**(2*k))
    egerr=abs(bs[2*K])/(2*K*N**(2*K));eg=inf(eg,egerr)
    q0=-logi(2*pi*a)-eg
    for name,x in [('q0',q0),('EulerGamma',eg)]:
        lo,hi=map(Q,data[name]);need(lo<=x.low<=x.high<=hi,'independent '+name+' containment')
    ap=powers(a/2,M);weights=[a*ap[k]*g[k] for k in range(M+1)]
    pn=[rod(n) for n in range(26)]
    for n,P in enumerate(pn):
        norm=sum((x*y/Q(i+j+1) for i,x in enumerate(P) for j,y in enumerate(P)),Q(0))
        need(norm==Q(1,2*n+1),'Rodrigues normalisation')
    h=b-a;need((a+b).high<Q(12,5),'whole outer radius')
    need((a*h).high<Q(1,9),'cross rectangle')
    w={q:logs[{4:2,8:2,9:3}.get(q,q)]/I(q).sqrt() for q in (2,3,4,5,7,8,9)}
    sh={q:logs[q]/a for q in w}
    slices=[(2,-1,I(0),I(1)),(2,1,I(0),1-sh[2]),(3,-1,I(0),I(1))]+[(q,-1,sh[q]-1,I(1)) for q in (4,5,7,8)]
    ip=monomial_integrals(I(1),R,M+MT+28);lm=log_ratio_moments(R,MT+25)
    shiftip=[monomial_integrals(l,u,MT+50) for _,_,l,u in slices]
    em=2*Q(3,5)**(MT+1)/factorial(MT+1)
    result={'status':'PASS_INDEPENDENT_WHOLE_FUNCTION_AUDIT', 'arithmetic_digits':DIGITS,
            'kernel_degree':M,'kernel_half_radius':'6/5','exact_kernel_error_matches':True,
            'independent_Euler_N':N,'independent_Euler_terms':K,'moment_Taylor_degree':MT,
            'Rodrigues_norm_checks':26,'EulerGamma':eg.pair(),'q0':q0.pair(),
            'parities':{},'complete_W9_energies_computed':False,'external_review_open':True}
    for p,label in enumerate(('even','odd')):
        print('Independent whole functions:',label,flush=True)
        ma=(a/2+Q(2,3) if p==0 else -a/2+Q(2,3))/a
        mt=(b/2+5/(2*I(11).sqrt()) if p==0 else -b/2+5/(2*I(11).sqrt()))/a
        nu=mt-ma
        mc=[z**k/factorial(k) if k%2==p else I(0) for k in range(MT+1)]
        corem=[sum((v/(n+k+1) for k,v in enumerate(mc)),I(0)) for n in range(M+28)]
        shellm=[sum((v*ip[n+k] for k,v in enumerate(mc)),I(0)) for n in range(M+1)]
        shelllm=[sum((v*lm[n+k] for k,v in enumerate(mc)),I(0)) for n in range(26)]
        # Direct Taylor integration against Rodrigues polynomials, unlike the input's positive Mellin recurrence.
        moments=[inf(dot(P,corem),em*absolute(P)) for P in pn]
        gm=1+sum((I(2*n+1)/(2*p+1)*(moments[n]/moments[p])**2 for n in range(p+2,26,2)),I(0))
        need(gm.high<Q(501,500),'strong Gram bound needed for A12 model price')
        rows=[];models=[];maxd=Q(0);maxf=Q(0)
        for j,n in enumerate(range(p+2,26,2)):
            norm=I(2*n+1).sqrt();ratio=moments[n]/moments[p]
            P=mul_scalar(add(pn[n],mul_scalar(pn[p],-ratio)),norm)
            Hn=sum((Q(1,k) for k in range(1,n+1)),Q(0));Hp=Q(p)
            HP=mul_scalar(add(mul_scalar(pn[n],Hn),mul_scalar(pn[p],-ratio*Hp)),norm)
            gin,gout=actions(P,weights)
            poly=add(add(HP,mul_scalar(P,q0)),mul_scalar(gin,-1))
            terms=[mul_scalar(shift(P,sgn*sh[q]),-w[q]) for q,sgn,*_ in slices]
            Vmoment=sum((x*y*log_potential_integral(i+k,logs[2]) for i,x in enumerate(P) for k,y in enumerate(mc) if i%2==p and k%2==p),I(0))
            im=dot(add(HP,mul_scalar(gin,-1)),corem)+Vmoment
            for term,si in zip(terms,shiftip):
                sm=[sum((v*si[r+k] for k,v in enumerate(mc)),I(0)) for r in range(26)]
                im=im+dot(term,sm)
            momenterr=em*(absolute(HP)+absolute(gin)+absolute(P)+sum(absolute(term) for term in terms))
            kappa=inf(im,momenterr)/ma
            quo=[I(0)]*n
            for l,x in enumerate(P):
                for r in range(l):
                    if r%2==0:quo[l-1-r]=quo[l-1-r]+2*x/(r+1)
            prime=[I(0)]
            for q in w:prime=add(prime,mul_scalar(shift(P,-sh[q]),w[q]))
            fpoly=add(add(mul_scalar(quo,Q(1,2)),mul_scalar(gout,-1)),mul_scalar(prime,-1))
            flog=mul_scalar(P,Q(-1,2));fr=-kappa
            If=dot(fpoly,shellm)+dot(flog,shelllm)+fr*nu
            If=inf(If,em*(absolute(fpoly,Q(11,10))+4*absolute(flog,Q(11,10))))
            fw=fr-If/mt
            saved=data['parities'][label]['functions'][j];ds=saved['D'];fs=saved['F']
            dround=coeff_distance(poly,ds['polynomial'])+coeff_distance(P,ds['V_multiplier'])+2*up(-kappa-Q(ds['moment_multiplier']))
            for term,ss in zip(terms,ds['shift_terms']):dround+=coeff_distance(term,ss['polynomial'])
            fround=2*(coeff_distance(fpoly,fs['polynomial'],Q(11,10))+4*coeff_distance(flog,fs['log_ratio_multiplier'],Q(11,10))+2*up(fw-Q(fs['physical_W_moment_multiplier'])))
            need(dround<=Q(ds['rounding_L2_bound']),'independent D coefficient errors exceed supplied budget')
            need(fround<=Q(fs['physical_rounding_W_norm_bound']),'independent F coefficient errors exceed supplied budget')
            kl,ku=map(Q,saved['kappa_model_interval']);need(kl<=kappa.low<=kappa.high<=ku,'kappa containment')
            # Moment of the STORED rounded D, not the ideal moment-projected model.
            rdpoly=list(map(Q,ds['polynomial']));rdV=list(map(Q,ds['V_multiplier']))
            defect=dot(rdpoly,corem)+Q(ds['moment_multiplier'])*ma
            defect=defect+sum((x*y*log_potential_integral(i+k,logs[2]) for i,x in enumerate(rdV) for k,y in enumerate(mc) if i%2==p and k%2==p),I(0))
            defecterr=em*(absolute(rdpoly)+absolute(rdV))
            for st,si in zip(ds['shift_terms'],shiftip):
                coeff=list(map(Q,st['polynomial']));sm=[sum((v*si[r+k] for k,v in enumerate(mc)),I(0)) for r in range(26)]
                defect=defect+dot(coeff,sm);defecterr+=em*absolute(coeff)
            defect=inf(defect,defecterr)
            rows.append({'degree':n,'independent_D_rounding_bound':str(dround),'independent_F_rounding_bound':str(fround),
                         'kappa_inside_input':True,'stored_D_dimensionless_moment_defect':defect.pair(),
                         'stored_D_moment_defect_excludes_zero':not defect.low<=0<=defect.high})
            models.append((P,poly,terms));maxd=max(maxd,dround);maxf=max(maxf,fround)
            if (j+1)%3==0:print(label,j+1,'/12 independent models',flush=True)
        A=[]
        for Pi,_,_ in models:
            bm=[sum((x/(i+k+1) for i,x in enumerate(Pi)),I(0)) for k in range(M+28)]
            sbm=[[sum((x*si[i+k] for i,x in enumerate(Pi)),I(0)) for k in range(26)] for si in shiftip]
            row=[]
            for Pj,poly,terms in models:
                val=dot(poly,bm)+sum((x*y*log_potential_integral(i+j,logs[2]) for i,x in enumerate(Pi) for j,y in enumerate(Pj) if i%2==p and j%2==p),I(0))
                for term,mb in zip(terms,sbm):val=val+dot(term,mb)
                row.append(val)
            A.append(row)
        supplied=fresh['parities'][label];mid=[[Q(x) for x in r] for r in supplied['midpoint']];rad=Q(supplied['whole_Loewner_radius'])
        rowerr=max(sum((up(A[i][j]-mid[i][j]) for j in range(12)),Q(0)) for i in range(12))
        # The stronger independently certified ||Phi||^2 < 501/500 proves the original 22/5 eps matrix allowance.
        model_A=2*a.high*gm.high*eps
        need(rowerr+model_A<rad,'whole independent matrix enclosure')
        lower=[[v-(rad if i==j else 0) for j,v in enumerate(r)] for i,r in enumerate(mid)]
        pv=strict_ldl(lower);need(pv==supplied['positive_pivots'],'exact pivots differ')
        result['parities'][label]={'source_basis_Gram_upper_interval':gm.pair(),'functions':rows,
            'whole_D_error_upper':str(Q(22,5)*eps+4*maxd),'whole_F_error_upper':str(36*eps+4*maxf),
            'independent_A12_integrals_inside_full_input_enclosure':144,'positive_pivots_match':12,
            'independent_A12_error_upper':str(rowerr+model_A),
            'rounded_D_is_not_exactly_moment_free':any(r['stored_D_moment_defect_excludes_zero'] for r in rows)}
        print(label,': 144 independent full integrals, 12 pivots, moment defects checked',flush=True)
    out.write_text(json.dumps(result,indent=2)+'\n')
    print('PASS independent coefficient/function audit',flush=True)
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();run(args.source,args.output)
