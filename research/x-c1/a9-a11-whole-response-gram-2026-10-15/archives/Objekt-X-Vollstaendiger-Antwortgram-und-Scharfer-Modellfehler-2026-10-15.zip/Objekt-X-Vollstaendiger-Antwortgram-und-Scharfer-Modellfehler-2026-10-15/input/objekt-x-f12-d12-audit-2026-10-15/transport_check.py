"""Freeze a rational response candidate and certify non-W9 error prices.
The remaining weighted D error is explicitly left conditional on its W9
energy bound. No A11 positivity or full residual energy is used/computed.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse,hashlib,json
from independent_check import strict_ldl,need,I

def t(A):return [list(x) for x in zip(*A)]
def mm(A,B):return [[sum((x*y for x,y in zip(a,b)),Q(0)) for b in t(B)] for a in A]
def add(A,B,c=Q(1)):return [[x+c*y for x,y in zip(a,b)] for a,b in zip(A,B)]
def sc(A,c):return [[c*x for x in a] for a in A]
def eye(n):return [[Q(i==j) for j in range(n)] for i in range(n)]
def gram(A,W):return mm(mm(t(A),W),A)
def controls():
    for case in range(8):
        n=5;r=2;x=3
        G=[[Q(2+i) if i==j else Q(1,20) for j in range(n)] for i in range(n)]
        m=[[Q((-1)**i*(i+1))] for i in range(n)]
        den=gram(m,G)[0][0]
        Pi=add(eye(n),sc(mm(m,mm(t(m),G)),1/den),-1)
        need(mm(Pi,Pi)==Pi,'non-Euclidean moment projection')
        need(mm(mm(t(m),G),Pi)==[[0]*n],'moment cancellation')
        need(mm(t(Pi),G)==mm(G,Pi),'metric selfadjoint projection')
        W0=[[Q(3+i) if i==j else Q(1,7) for j in range(n)] for i in range(n)]
        W=mm(mm(t(Pi),W0),Pi)
        def mat(a,b,offset):return [[Q(((i+1)*(j+2)+case+offset)%11-5,13) for j in range(b)] for i in range(a)]
        C=mm(Pi,mat(n,x,0));D=mm(Pi,mat(n,r,1));raw=mat(n,r,2);Dh=mm(Pi,raw)
        F=mat(r,x,3);Fh=add(F,sc(mat(r,x,4),Q(1,100)))
        S=[[Q(1)+Q(case,10),Q(1,7)],[Q(1,7),Q(2)+Q(case,10)]]
        T=mm(S,Fh);R=add(C,mm(D,T),-1);Rh=add(C,mm(Dh,T),-1);E=add(R,Rh,-1)
        need(E==sc(mm(add(D,Dh,-1),T),-1),'residual difference')
        # alpha=1/4: the weighted Young defect is an exact Gram.
        alpha=Q(1,4)
        left=add(add(sc(gram(Rh,W),1+alpha),sc(gram(E,W),1+1/alpha)),gram(R,W),-1)
        right=gram(add(sc(Rh,Q(1,2)),sc(E,2),-1),W)
        need(left==right,'joint weighted energy identity')
        dF=add(F,Fh,-1);theta=Q(1,4)
        cross=add(mm(t(dF),T),mm(t(T),dF))
        left=add(add(sc(gram(T,eye(r)),theta),sc(gram(dF,eye(r)),1/theta)),cross)
        right=gram(add(sc(T,Q(1,2)),sc(dF,2)),eye(r))
        need(left==right,'joint K source-error identity')
        # Orthogonal projection does not increase the ambient Hilbert error.
        d=add(D,raw,-1);pd=mm(Pi,d)
        need(add(gram(d,G),gram(pd,G),-1)==gram(mm(add(eye(n),Pi,-1),d),G),'projection contraction identity')
    return {'nonorthogonal_metric_cases':8,'weighted_residual_Young_identities':8,'source_error_Young_identities':8,'projection_contraction_identities':8}

def run(source,audit,out):
    old=json.loads((source/'inputs/OLD_A9_N12.json').read_bytes())
    fresh=json.loads((source/'FRESH_A12.json').read_bytes());fun=json.loads((source/'FUNCTIONS12.json').read_bytes())
    independent=json.loads(audit.read_bytes())
    result={'status':'PASS_FIXED_RESPONSE_ERROR_BOOKKEEPING',
       'response_definition':'P = Phi_12 S F_hat; S fixed rational, F_hat the stored W-Riesz model',
       'D_model_definition':'D_hat = Pi_a D_tilde; Pi_a the exact old moment-orthogonal projection',
       'S_definition':'arithmetic mean of inherited directed inverse lower/upper matrices; NOT identified with the exact inverse',
       'source_C_norm_upper_inherited':'150','source_F_hat_norm_upper':'151',
       'source_old_N12_sha256':hashlib.sha256((source/'inputs/OLD_A9_N12.json').read_bytes()).hexdigest(),
       'new_joint_W9_energy_computed':False,'new_W9_norm_upper_computed':False,
       'parities':{},'exact_synthetic_controls':controls()}
    for p,c in old['parities'].items():
        S=[[(Q(a)+Q(b))/2 for a,b in zip(u,v)] for u,v in zip(c['inverse_lower_Loewner'],c['inverse_upper_Loewner'])]
        need(S==t(S),'S symmetry');pv=strict_ldl(S)
        normS=sum((S[i][i] for i in range(12)),Q(0));Tnorm=151*normS
        gram_upper=Q(independent['parities'][p]['source_basis_Gram_upper_interval'][1])
        need(gram_upper<Q(1001,1000)**2,'source Phi norm < 1.001')
        dD=Q(fun['parities'][p]['whole_D12_operator_error_upper']);dF=Q(fun['parities'][p]['whole_F12_operator_error_upper'])
        need(150*Q(1001,1000)+dF<151,'F_hat norm')
        dA=Q(fresh['parities'][p]['whole_Loewner_radius'])
        Amid=[[Q(v) for v in r] for r in fresh['parities'][p]['midpoint']]
        invdef=add(eye(12),mm(Amid,S),-1)
        invdefnorm=I(sum((v*v for row in invdef for v in row),Q(0))).sqrt().high+dA*normS
        galerkin_defect=dF+151*invdefnorm
        need(galerkin_defect < (Q(2,10**22) if p=='even' else Q(2,10**24)), 'small but not zero Galerkin defect')
        kerr=2*dF*Tnorm+dA*Tnorm*Tnorm
        r2=dD*dD*Tnorm*Tnorm
        simpleK=Q(11,10**7) if p=='even' else Q(9,10**11)
        simpleR=Q(38,10**45) if p=='even' else Q(30,10**49)
        need(kerr<simpleK,'K simple error');need(r2<simpleR,'residual error factor')
        defects=independent['parities'][p]['functions']
        projections=[]
        mul,muu=map(Q,fun['parities'][p]['old_moment_matrix_mu_over_a'])
        for f in defects:
            lo,hi=map(Q,f['stored_D_dimensionless_moment_defect']);a=[lo/mul,lo/muu,hi/mul,hi/muu]
            projections.append({'degree':f['degree'],'exact_definition':'alpha_j = integral_0^1 m(a*t)*stored_D_bracket_j(t) dt / (mu/a)',
                'alpha_interval':[str(min(a)),str(max(a))],
                'projected_bracket':'stored_D_bracket_j(t) - alpha_j*m(a*t)',
                'rounding_alpha_to_midpoint_is_not_an_exact_projection':True})
        result['parities'][p]={'S_rational':[[str(v) for v in r] for r in S],
            'S_positive_pivots':pv,'S_norm_upper_trace':str(normS),'SF_hat_norm_upper':str(Tnorm),
            'delta_A':str(dA),'delta_D':str(dD),'delta_F':str(dF),
            'true_A12_times_S_minus_identity_norm_upper':str(invdefnorm),
            'true_Phi12_adjoint_residual_norm_upper':str(galerkin_defect),
            'exact_Galerkin_annihilation_claimed':False,
            'whole_K_model_error_upper':str(kerr),'simple_K_error_upper':str(simpleK),
            'relative_background_K_error_upper':str(25*kerr),
            'squared_residual_error_per_unit_W9_norm_upper':str(r2),'simple_squared_residual_error_factor':str(simpleR),
            'projected_model_coefficients':projections}
    out.write_text(json.dumps(result,indent=2)+'\n')
    print('PASS: fixed rational response, exact projection, K-error budgets; W9 energy remains open.')
    return result
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--independent-audit',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();run(a.source,a.independent_audit,a.output)
