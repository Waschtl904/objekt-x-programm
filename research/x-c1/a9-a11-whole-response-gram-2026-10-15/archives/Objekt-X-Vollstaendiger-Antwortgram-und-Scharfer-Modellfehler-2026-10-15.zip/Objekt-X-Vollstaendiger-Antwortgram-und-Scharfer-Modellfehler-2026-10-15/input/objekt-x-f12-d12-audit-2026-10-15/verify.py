"""Fresh full replay of this additive audit; preserves every input byte."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,zipfile

ARCHIVE='Objekt-X-A9-A11-Ganze-Kraftfunktionen-und-D12-2026-10-15.zip'
DIGEST='0a7bda3d2d896801f757c3b658d9ad559529409c64dd489283e656b95710d3d3'
NESTED='931176c9b9f42d66fb4debf76cea46e92c2814f2c01ffbf8c53afc17e78aba7b'

def require(ok,msg):
    if not ok:raise ValueError(msg)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(here,out):
    require(__debug__,'run without -O')
    here=here.resolve();out=out.resolve()
    require(not out.exists() and not out.is_relative_to(here),'new output outside the package required')
    for name,want in json.loads((here/'MANIFEST.json').read_bytes()).items():
        p=(here/name).resolve();require(p.is_relative_to(here),'unsafe manifest path')
        require(sha(p)==want,'changed audit file: '+name)
    archive=here/'originals'/ARCHIVE;require(sha(archive)==DIGEST,'wrong original archive')
    out.mkdir(parents=True);(out/'reports').mkdir()
    with zipfile.ZipFile(archive) as z:
        require(sum(i.file_size for i in z.infolist())<100_000_000,'unexpected archive size')
        for m in z.infolist():
            p=(out/'input'/m.filename).resolve()
            require(p.is_relative_to(out/'input'),'unsafe archive path')
            require(((m.external_attr>>16)&0o170000)!=0o120000,'symlink in archive')
            if m.is_dir():p.mkdir(parents=True,exist_ok=True)
            else:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(m))
    source=out/'input/objekt-x-whole-functions12-2026-10-15'
    require(sha(source/'inputs/incoming_countercheck.zip')==NESTED,'changed predecessor archive')
    def execute(args,name):
        print('Running',name,flush=True)
        with (out/(name+'.log')).open('w') as log:
            subprocess.run([sys.executable,'-u','-B','-X','utf8']+list(map(str,args)),stdout=log,stderr=subprocess.STDOUT,check=True)
    execute([source/'verify.py','--output',out/'original-replay'],'original-replay')
    raw=(out/'original-replay/AUDIT.json').read_bytes()
    require(raw==(here/'reports/ORIGINAL_REPLAY_AUDIT.json').read_bytes(),'original replay receipt differs')
    (out/'reports/ORIGINAL_REPLAY_AUDIT.json').write_bytes(raw)
    execute([here/'independent_check.py','--source',source,'--output',out/'reports/INDEPENDENT_FUNCTIONS.json'],'independent-whole-functions')
    execute([here/'transport_check.py','--source',source,'--independent-audit',out/'reports/INDEPENDENT_FUNCTIONS.json','--output',out/'reports/RESPONSE_ERROR_BUDGET.json'],'error-transport')
    for name in ['INDEPENDENT_FUNCTIONS.json','RESPONSE_ERROR_BUDGET.json']:
        require((out/'reports'/name).read_bytes()==(here/'reports'/name).read_bytes(),'new independent receipt differs: '+name)
    # Reassemble the concise audit from checked data; no copied success receipt.
    ind=json.loads((out/'reports/INDEPENDENT_FUNCTIONS.json').read_bytes())
    data=json.loads((source/'FUNCTIONS12.json').read_bytes())
    counts={'D_polynomial':0,'D_V':0,'D_shifts':0,'F_polynomial':0,'F_log':0}
    for pp in data['parities'].values():
        for row in pp['functions']:
            counts['D_polynomial']+=len(row['D']['polynomial']);counts['D_V']+=len(row['D']['V_multiplier'])
            counts['D_shifts']+=sum(len(t['polynomial']) for t in row['D']['shift_terms'])
            counts['F_polynomial']+=len(row['F']['polynomial']);counts['F_log']+=len(row['F']['log_ratio_multiplier'])
    audit={'status':'PASS_WITH_EXACT_MODEL_MOMENT_PROJECTION_CLARIFICATION','date':'2026-10-15',
        'input_archive_sha256':sha(archive),
        'original_manifest_files_verified':len(json.loads((source/'MANIFEST.json').read_bytes())),
        'original_source_bindings_verified':len(json.loads((source/'SOURCES.json').read_bytes())),
        'three_original_outputs_freshly_rebuilt_and_raw_byte_identical':True,
        'incoming_countercheck_archive_matches_previously_supplied_original':True,
        'older_embedded_counterchecks_rerun_in_this_session':False,
        'independent_arithmetic_source_modules_imported':False,
        'independent_whole_function_columns':48,'independent_coefficient_field_counts':counts,
        'independent_kappa_intervals_inside_input':24,'independent_fresh_A12_integrals':288,
        'independent_positive_A12_pivots':24,
        'rounded_D_columns_with_certified_nonzero_moments':sum(sum(x['stored_D_moment_defect_excludes_zero'] for x in o['functions']) for o in ind['parities'].values()),
        'source_Phi_Gram_below_501_over_500_certified':True,
        'exact_orthogonal_model_projection_supplied':True,'whole_D_error_after_projection_not_increased':True,
        'fixed_rational_response_candidates_generated':2,'additional_response_candidate_positive_pivots':24,
        'direct_K_model_error_paid_for_fixed_candidates':True,'W9_model_error_paid':False,
        'W9_operator_norm_upper_newly_computed':False,'complete_E00_E10_E11_computed':False,
        'complete_compact_gate_computed':False,'new_A9_A11_Schur_closure':False,'new_A11_inverse_majorant':False,
        'large_historical_integrations_rerun':False,'historical_574_pivots_rerun':False,
        'analytic_proof_machine_formalized':False,'external_mathematical_review_open':True,
        'github_modified':False,'original_archives_modified':False}
    raw=(json.dumps(audit,indent=2)+'\n').encode()
    require(raw==(here/'reports/AUDIT.json').read_bytes(),'summary audit differs')
    (out/'reports/AUDIT.json').write_bytes(raw)
    # Exercise the projected model evaluator in both parities.
    for parity in ('even','odd'):
        execute([here/'evaluate_projected_D.py','--source',source,'--budget',out/'reports/RESPONSE_ERROR_BUDGET.json','--parity',parity,'--index','0','--fraction','1/2'],'projected-model-'+parity)
    print('PASS: original outputs and all four audit receipts are byte-identical. Exact moment projection required; W9 energy remains open.',flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    run(Path(__file__).resolve().parent,a.output)
