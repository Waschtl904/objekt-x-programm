"""Independent entry-point probes, configured only after receiving the exact revision.

This file is a reviewer test, not a substitute protection patch.
All test decisions use explicit exceptions, never assert.
"""
from pathlib import Path
import hashlib, json, os, subprocess, sys, tempfile

cfg_path = Path(sys.argv[1]).resolve()
cfg = json.loads(cfg_path.read_bytes())
root = Path(cfg['revision_root']).resolve()
archive = Path(cfg['revision_archive']).resolve()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
if sha(archive) != cfg['revision_sha256']:
    raise RuntimeError('Received revision archive hash mismatch')
entries = cfg['entries']
if not entries:
    raise RuntimeError('Empty entry inventory')
before = {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*')
          if p.is_file() and '__pycache__' not in p.parts}
env = os.environ.copy()
env.pop('PYTHONOPTIMIZE', None)
env.pop('PYTHONPATH', None)
env['PYTHONDONTWRITEBYTECODE'] = '1'
cwd = Path(tempfile.mkdtemp(prefix='guard-empty-cwd-', dir=cfg_path.parent))
modes = [('-O',['-O'],None), ('-OO',['-OO'],None),
         ('PYTHONOPTIMIZE=1',[],'1'), ('PYTHONOPTIMIZE=2',[],'2'),
         ('-S -O',['-S','-O'],None), ('-S -OO',['-S','-OO'],None)]
results = []
for entry in entries:
    rel = entry['path']
    path = (root/rel).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise RuntimeError('Invalid entry: '+rel)
    marker = entry['marker']
    if not marker:
        raise RuntimeError('Expected protection marker missing')
    for label, flags, setting in modes:
        e = env.copy()
        if setting is not None:
            e['PYTHONOPTIMIZE'] = setting
        command = [sys.executable, '-B', *flags, str(path), *entry.get('args',[])]
        r = subprocess.run(command, env=e, cwd=cwd, text=True,
                           capture_output=True, timeout=20)
        combined = r.stdout+'\n'+r.stderr
        ok = (r.returncode == entry.get('exit_code',78) and r.stderr == marker+'\n' and r.stdout == ''
              and not any(t in combined for t in
                  ('ModuleNotFoundError','ImportError','FileNotFoundError'))
              and not any(t in r.stdout for t in cfg.get('success_markers', ['PASS'])))
        results.append({'entry':rel, 'mode':label, 'returncode':r.returncode,
                        'guard_verified':ok, 'stdout':r.stdout, 'stderr':r.stderr})
after = {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*')
         if p.is_file() and '__pycache__' not in p.parts}
out = {'revision_sha256':cfg['revision_sha256'],
       'entry_count':len(entries), 'case_count':len(results),
       'files_unchanged':before==after,
       'empty_working_directory_unchanged':not any(cwd.iterdir()),
       'all_guards_verified':all(x['guard_verified'] for x in results),
       'assert_statements_in_this_harness':0,
       'new_numerical_integrations':0, 'cases':results}
Path(cfg['result_file']).write_bytes((json.dumps(out,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in out.items() if k!='cases'}))
if (not out['files_unchanged'] or not out['all_guards_verified']
        or not out['empty_working_directory_unchanged']):
    raise SystemExit(1)
