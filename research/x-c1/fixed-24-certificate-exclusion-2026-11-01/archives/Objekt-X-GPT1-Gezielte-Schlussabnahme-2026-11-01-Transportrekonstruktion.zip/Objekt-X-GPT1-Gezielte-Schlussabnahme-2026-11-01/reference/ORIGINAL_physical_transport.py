"""Physical error prices for the newly evaluated signed source representation.

These are prices in the HIGH REST. GPT1's complete finite data price is
inherited once. No cW*epsW/cK*epsK/cN*epsN is added to it a second time.
The v error is transported by its jointly signed function bank, not a global
source-operator factor. Its actual function norm is an explicit pending input.
"""
from full_source import *
sys.set_int_max_str_digits(100000)

def main():
 st=time.monotonic();f=fresh_common(core=True);R=f['R']
 capsule=boundary_inputs()
 cc=capsule['common_model'];fw=capsule['finite_weights'];geo=capsule['geometry']
 bank=read('gpt1-data/BANK_ERROR_RESULT.json');err=bank['primitive_errors'];caps=bank['model_caps']
 inv=read('gpt1-review/GPT1_INVERSE_DATA.json');Ki=ratmat(inv['K_old_inverse']);K=ratmat(inv['K_old'])
 D=read('CORE_23.json.gz');RK=mat(D['Ki_factor'])
 delta=q(capsule['aliases']['common']['cases'][0]['delta']);rho=q(capsule['aliases']['common']['cases'][0]['rho'])
 gamma=box(geo['geometry']['gamma']);V=box(geo['Vphys_HS']);a=3*arb(2).log()/2;b=arb(3).log();bo=arb(11).log()/2;h=b-a
 eQC=box(read('gpt1-data/GAMMA_CONTRACTED_HS.json')['contracted_exact_Gamma160_error_HS_upper'])
 eV=gamma.sqrt()*eQC/(delta*(1-rho).sqrt())
 ea_box=hs((mat(cc['a0_intervals'])-mid(mat(cc['a0_intervals'])))*R)
 ev_box=hs(RK.transpose()*(mat(cc['v_intervals'])-mid(mat(cc['v_intervals'])))*R)
 ewf_box=hs((mat(fw['wf'])-f['wf0'])*RK)
 eKi=hs(RK.transpose()*K*(Ki-f['K0'])*f['v0'])
 graph=q(read('gpt1-data/DATA_ERROR_PROGRESS.json')['graph_transport']['whole_raw_action_HS_upper'])
 vop=16*sum((Ki[i,i]for i in range(12)),arb(0)).sqrt()+q(149500000000000)
 ea=q(err['a0_total'])+ea_box+V*graph
 ev=q(err['v'])+ev_box+eKi+vop*graph
 ewf=q(err['old_AF_Ki'])+ewf_box
 av=hs(f['a0']);vv=hs(RK.transpose()*K*f['z']);wf=hs(f['wf0']*RK)
 need(av<4 and vv<3,'same bounded common force banks')
 # Whole Gamma tails: circle radius 3/2 is below the first hyperbolic pole.
 rad=q('3/2');Mc=(1/rad.cos()+1/rad.sin()+1/rad)/4
 need(rad.cos()>0 and rad.sin()>0,'regular Gamma analytic circle')
 e224=Mc*(b/rad)**225/(1-b/rad)
 zmax=(b+bo)/2;e360=Mc*(zmax/rad)**361/(1-zmax/rad)
 SD=f['SD'];SC=f['SC'];basis=read('../high-envelope-2026-10-31/WHOLE_COMPARISON.json')
 dT=box(basis['quantities']['T_common_coefficient_error'])
 eD=q('1.573e-50')*hs(SD)+(box(basis['D_basis_bound']['model_norm_upper'])+q('1.573e-50'))*dT
 eC=2*e360*(b*(bo-b)).sqrt()*hs(SC)
 eshell=eD+eC
 raw=read('RAW_23.json.gz');esq=arb(0)
 for row in raw['rows']:esq+=2*(box(row['hi'])-box(row['lo']))*sum((box(v)**2 for v in row['uniform_errors']),arb(0))
 eraw=esq.sqrt();ecore=eshell+eraw
 # Actual F12 versus the frozen local Y representation, including its lift.
 inp=Inputs();hb=inp.json('half')['blocks'][0]
 actualY=mat(hb['basis_Q_local_coefficients'])*ratmat(hb['half_inverse_centre_rational_Q_coefficients'])
 frozenY=ratmat(inp.json('frozen_Y_even')['Y_local_rational_midpoints'])
 RY=arb_mat([[RK[i+4,j]for j in range(12)]for i in range(8)])
 eFbasis=q('1e12')*hs((actualY-frozenY)*RY)
 eQFwhole=2*b*e224*(q(caps['bare_F_Ki'])+2*eFbasis/q('1e12'))+eFbasis
 egFcore=q(err['old_HF_Ki']) # >= whole core raw error eRF, since sqrt(gamma)>1.
 # Difference between C0 and the exact unchanged rational preconditioner.
 case=inp.json('common')['cases'][0]
 Cexact=arb_mat([[arb(int(x))/int(case['inverse_congruence_denominator'])for x in row]for row in case['inverse_congruence_integer_matrix']])
 eCcoeff=hs(Cexact-f['C0'])
 need(eCcoeff<q('1e-80'),'exact Cpre versus chosen bank midpoint')
 eV+=q('1e15')*eCcoeff
 force=av+wf*vv
 Wmodel=1+q(149500000000001)*vv+(V+eV)*av+2*gamma/delta*(q(caps['q_core'])+graph+ecore)
 eKcross=2*e224*(a*h).sqrt()
 outer=read('OUTER_BANKS.json.gz')
 qshell=[box(x)for x in outer['shell_quantization_L2_by_column']]
 fixed={
  'direct_source_D_C_and_T':eshell,
  'core_source_model_and_new_Taylor':30*gamma/delta*ecore,
  'physical_a_bank_and_its_model_enclosure':30*V*ea,
  'physical_WF_bank_and_its_model_enclosure':30*V*ewf*vv,
  'physical_V_synthesis_and_Cpre':30*eV*force,
  'whole_Q9F_direct_source':eQFwhole*vv,
  'core_Q9F_source':30*gamma/delta*egFcore*vv,
  'whole_cross_kernel_Gamma224_tail':eKcross*Wmodel,
  'core_function_rational_quantization':30*sum((box(x)for x in D['core_function_quantization_L2_by_column'][:23]),arb(0)),
  'complete_outer_bank_quantization':sum(qshell[:23],arb(0))}
 # Additional error in the jointly signed normalized v-response operator.
 exi=eQFwhole+30*(gamma/delta*egFcore+eV*wf+V*ewf)+eKcross*q(149500000000001)
 exi+=30*sum((box(x)for x in D['core_function_quantization_L2_by_column'][23:]),arb(0))+sum(qshell[23:],arb(0))
 vals={'e_a_total':ea,'e_v_total_Ki':ev,'e_WF_total_Ki':ewf,'e_V':eV,
  'a_model':av,'v_model_Ki':vv,'WF_model_Ki_HS':wf,'e_a_stored_box':ea_box,'e_v_stored_box_Ki':ev_box,
  'e_WF_stored_box_Ki':ewf_box,'exact_Ki_vs_midpoint_effective_v_error':eKi,
  'graph_source_error_high_scope':graph,'Gamma224_uniform':e224,'Gamma360_uniform':e360,
  'raw_Taylor_core_L2':eraw,'cross_kernel_error_operator':eKcross,'w_model_whole_upper':Wmodel,
  'joint_v_response_physical_model_difference':exi,'e_QF_whole_Ki':eQFwhole,'e_QF_basis_Ki':eFbasis}
 vals.update(D12_physical_function_price=q('1.573e-50')*hs(SD),
  physical_T_freeze_price=(box(basis['D_basis_bound']['model_norm_upper'])+q('1.573e-50'))*dT,
  C12_whole_Gamma360_price=eC,
  a_bank_physical_only_high_price=30*V*q(err['a0_total']),
  a_bank_stored_enclosure_high_price=30*V*ea_box,
  a_bank_graph_high_price=30*V*V*graph,
  v_bank_physical_Ki_error=q(err['v']))
 out={'status':'PHYSICAL_REST_TRANSPORT_LEDGER_WITH_EXPLICIT_PENDING_FUNCTION_NORMS',
  'fixed_prices':fixed,'values':vals,'model_remainder_norm_upper':None,'model_v_response_norm_upper':None,
  'formula':'r <= (1+1e-80)*(r_model + sum(fixed_prices) + e_v_total_Ki*(Xi_model + Xi_physical_model_error)) + positive_lift_and_Schur_prices',
  'complete_data_price_inherited_once':'0.004356223514',
  'same_input_can_affect_distinct_blocks':'Finite pairings are in e_data; the image of primitive defects under the corrected high map is in r. The three whole bank gradient prices are not added again.',
  'seconds':time.monotonic()-st}
 save('PHYSICAL_REST_TRANSPORT.json',out)
 print('fixed prices',{k:v.str(16)if isinstance(v,arb)else v for k,v in fixed.items()},flush=True)
 print('physical values',{k:v.str(16)for k,v in vals.items()},flush=True)
if __name__=='__main__':main()
